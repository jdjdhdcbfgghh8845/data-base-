# Steam Theme for GameHub OS

## Overview
GameHub OS now features a complete Steam-inspired design theme that replicates the look and feel of Valve's Steam platform.

## Color Palette

### Primary Backgrounds
- **Dark Background** (`#171a21`): Used for header, sidebar, and menu bar
- **Medium Background** (`#1b2838`): Main content area background
- **Light Background** (`#16202d`): Card backgrounds
- **Input Background** (`#316282`): Input fields and text areas
- **Hover Background** (`#2a475e`): Hover state for interactive elements

### Accent Colors
- **Steam Blue** (`#1a9fff`): Primary accent for active states and highlights
- **Light Blue** (`#66c0f4`): Secondary blue accent
- **Steam Green** (`#5c7e10`): Action buttons (Play, Install, etc.)
- **Green Hover** (`#6fa313`): Hover state for green buttons

### Text Colors
- **Primary Text** (`#c7d5e0`): Main text color
- **Secondary Text** (`#8f98a0`): Muted text for labels and hints
- **White Text** (`#ffffff`): High contrast text
- **Green Text** (`#d2efa9`): Text on green buttons

### UI Elements
- **Dark Border** (`#000000`): Borders and separators
- **Scrollbar** (`#3d4450`): Scrollbar handle color
- **Error Red** (`#8b0000`): Error states and close button hover

## Updated Components

### 1. Main Window (`main_window.py`)
- Dark blue-grey background matching Steam's main interface
- Steam-style scrollbars with flat design
- Green gradient buttons for all actions
- Steam blue highlights for focus states

### 2. Sidebar (`sidebar.py`)
- Very dark background (`#171a21`)
- Navigation buttons with Steam blue active state
- Hover effects with dark blue background
- Minimal borders and flat design

### 3. Header Bar (`header.py`)
- Dark header with Steam colors
- Steam-style search input
- Minimalist window controls
- Red hover state for close button

### 4. Game Library (`library_page.py`)
- Game cards with Steam-style backgrounds
- Steam blue hover effect on cards
- Green "Play" buttons matching Steam
- Steam-style context menus

### 5. Centralized Theme (`src/ui/styles/steam_theme.py`)
- Complete stylesheet available via `get_steam_stylesheet()`
- Color palette accessible via `get_steam_colors()`
- Consistent styling for all Qt widgets

## Design Principles

### 1. **Flat Design**
- No rounded corners (border-radius: 0-2px)
- Minimal shadows
- Clean, sharp edges

### 2. **Dark Theme**
- Dark backgrounds throughout
- High contrast text
- Subtle borders

### 3. **Steam Green Actions**
- All primary action buttons use Steam's signature green
- Gradient effect from light to dark green
- Hover states brighten the green

### 4. **Steam Blue Accents**
- Active/selected states use Steam blue
- Focus states highlighted in blue
- Links and interactive elements in blue

### 5. **Minimal Borders**
- 1px black borders for separation
- No decorative borders
- Clean, professional look

## Usage

The theme is automatically applied to all components. For new components, you can:

```python
from src.ui.styles import get_steam_stylesheet, STEAM_COLORS

# Apply to a widget
widget.setStyleSheet(get_steam_stylesheet())

# Use individual colors
widget.setStyleSheet(f"background-color: {STEAM_COLORS['bg_dark']};")
```

## Comparison with Steam

| Element | Steam | GameHub OS |
|---------|-------|------------|
| Background | Dark blue-grey | ✅ Matching |
| Buttons | Green gradient | ✅ Matching |
| Accents | Blue highlights | ✅ Matching |
| Typography | Clean sans-serif | ✅ Matching |
| Borders | Minimal black | ✅ Matching |
| Scrollbars | Flat grey | ✅ Matching |

## Screenshots

The application now features:
- Steam-style dark interface
- Green action buttons
- Blue highlights for active elements
- Flat, professional design
- Consistent color scheme throughout

## Future Enhancements

Potential additions to make the theme even more Steam-like:
- Steam-style notifications
- Achievement popups with Steam design
- Store-like game details page
- Friends list with Steam styling
- Big Picture mode interface
