#!/usr/bin/env python3
"""
GameHub OS - Ultimate Gaming Platform
A cross-platform application for gamers with game library management,
system optimization, achievements, and global chat.
"""

import sys
import os
import asyncio
from pathlib import Path
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt, QThreadPool, QTimer
from PyQt6.QtGui import QIcon, QFont, QFontDatabase
from src.ui.main_window import MainWindow
from src.core.database import DatabaseManager
from src.core.config import Config
from src.core.updater import AutoUpdater
from src.ui.dialogs.update_dialog import UpdateDialog
from src.utils.logger import setup_logger

# Setup logger
logger = setup_logger(__name__)


class GameHubOS:
    """Main application class for GameHub OS"""
    
    def __init__(self):
        self.app = None
        self.main_window = None
        self.config = None
        self.db_manager = None
        self.updater = None
        
    def initialize(self):
        """Initialize application components"""
        logger.info("Initializing GameHub OS...")
        
        # Load configuration
        self.config = Config()
        
        # Initialize database
        self.db_manager = DatabaseManager()
        self.db_manager.initialize()
        
        # Initialize updater
        self.updater = AutoUpdater()
        
        # Setup Qt application
        self.app = QApplication(sys.argv)
        self.app.setApplicationName("GameHub OS")
        self.app.setOrganizationName("GameHub")
        
        # Set application style
        self._setup_style()
        
        # Create main window
        self.main_window = MainWindow(self.config, self.db_manager)
        
        # Check for updates if auto-check is enabled
        if self.config.get('updates.auto_check', True):
            QTimer.singleShot(2000, self.check_for_updates)
        
        logger.info("GameHub OS initialized successfully")
        
    def _setup_style(self):
        """Setup application style and theme"""
        try:
            from qt_material import apply_stylesheet
            
            # Apply material theme
            theme = self.config.get('appearance.theme', 'dark_teal.xml')
            apply_stylesheet(self.app, theme=theme)
            
            # Set additional style adjustments
            extra = {
                'density_scale': '-1',
                'button_shape': 'rounded',
            }
            apply_stylesheet(self.app, theme=theme, extra=extra)
            
        except ImportError:
            logger.warning("qt-material not installed, using default theme")
            self.app.setStyle('Fusion')
    
    def check_for_updates(self):
        """Check for updates on startup"""
        try:
            # Quick check without UI
            has_update, new_version, _ = self.updater.check_for_updates()
            
            if has_update:
                logger.info(f"Update available: {new_version}")
                # Show update dialog
                dialog = UpdateDialog(self.main_window, auto_check=True)
                dialog.exec()
        except Exception as e:
            logger.error(f"Error checking for updates: {e}")
    
    def run(self):
        """Run the application"""
        if not self.main_window:
            raise RuntimeError("Application not initialized. Call initialize() first.")
        
        # Show main window
        self.main_window.show()
        
        # Start event loop
        logger.info("Starting GameHub OS...")
        sys.exit(self.app.exec())


def main():
    """Entry point for the application"""
    try:
        # Enable High DPI support
        QApplication.setHighDpiScaleFactorRoundingPolicy(
            Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
        )
        
        # Create and run application
        gamehub = GameHubOS()
        gamehub.initialize()
        gamehub.run()
        
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
