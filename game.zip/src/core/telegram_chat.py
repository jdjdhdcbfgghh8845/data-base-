"""Telegram Bot integration for global chat"""

import asyncio
import threading
from typing import Optional, Callable, List, Dict
from datetime import datetime
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import Message
import aiohttp
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class TelegramChat:
    """Handle Telegram Bot API for global chat functionality"""
    
    def __init__(self, config, db_manager):
        """Initialize Telegram chat"""
        self.config = config
        self.db_manager = db_manager
        self.bot = None
        self.dispatcher = None
        self.bot_token = config.get('chat.telegram_bot_token')
        self.chat_id = config.get('chat.telegram_chat_id')
        self.username = config.get('chat.username', 'Anonymous')
        self.connected = False
        self.running = False
        self.message_callback = None
        self.loop = None
        self.thread = None
        
    def set_message_callback(self, callback: Callable):
        """Set callback for incoming messages"""
        self.message_callback = callback
        
    async def initialize(self):
        """Initialize bot and dispatcher"""
        if not self.bot_token:
            logger.error("Telegram bot token not configured")
            return False
            
        try:
            self.bot = Bot(token=self.bot_token)
            self.dispatcher = Dispatcher()
            
            # Register message handlers
            self.dispatcher.message.register(self._handle_message)
            
            # Test connection
            bot_info = await self.bot.get_me()
            logger.info(f"Connected to Telegram bot: @{bot_info.username}")
            self.connected = True
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize Telegram bot: {e}")
            self.connected = False
            return False
    
    async def _handle_message(self, message: Message):
        """Handle incoming messages from Telegram"""
        try:
            # Check if message is from the configured chat
            if str(message.chat.id) != str(self.chat_id):
                return
            
            # Ignore own messages
            if message.from_user.username == self.bot.username:
                return
            
            # Create message data
            msg_data = {
                'id': message.message_id,
                'username': message.from_user.username or message.from_user.first_name,
                'text': message.text,
                'timestamp': message.date.isoformat(),
                'user_id': message.from_user.id
            }
            
            # Store message in database
            self._store_message(msg_data)
            
            # Call callback if set
            if self.message_callback:
                self.message_callback(msg_data)
                
        except Exception as e:
            logger.error(f"Error handling Telegram message: {e}")
    
    async def send_message(self, text: str) -> bool:
        """Send message to the global chat"""
        if not self.connected:
            logger.error("Not connected to Telegram")
            return False
            
        if not self.chat_id:
            logger.error("Chat ID not configured. Please set it in Settings.")
            return False
            
        try:
            # Format message with username
            formatted_text = f"[GameHub-{self.username}]: {text}"
            
            # Convert chat_id to int if it's a string
            try:
                chat_id_int = int(self.chat_id)
            except (ValueError, TypeError):
                logger.error(f"Invalid chat_id format: {self.chat_id}")
                return False
            
            # Send message
            message = await self.bot.send_message(
                chat_id=chat_id_int,
                text=formatted_text
            )
            
            # Store sent message
            msg_data = {
                'id': message.message_id,
                'username': self.username,
                'text': text,
                'timestamp': datetime.now().isoformat(),
                'user_id': 'self'
            }
            self._store_message(msg_data, is_sent=True)
            
            logger.info(f"Message sent successfully to chat {chat_id_int}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to send message: {e}")
            logger.error(f"Chat ID: {self.chat_id}, Bot Token: {'*' * 10 if self.bot_token else 'Not set'}")
            return False
    
    def send_message_sync(self, text: str) -> bool:
        """Synchronous wrapper for sending messages"""
        if self.loop and self.loop.is_running():
            future = asyncio.run_coroutine_threadsafe(
                self.send_message(text),
                self.loop
            )
            return future.result(timeout=5)
        return False
    
    async def get_chat_info(self) -> Optional[Dict]:
        """Get information about the configured chat"""
        if not self.connected or not self.chat_id:
            return None
            
        try:
            chat = await self.bot.get_chat(self.chat_id)
            return {
                'id': chat.id,
                'title': chat.title or chat.first_name,
                'type': chat.type,
                'members_count': await self.bot.get_chat_member_count(self.chat_id)
            }
        except Exception as e:
            logger.error(f"Failed to get chat info: {e}")
            return None
    
    async def get_updates(self):
        """Start polling for updates"""
        if not self.connected:
            logger.error("Bot not connected")
            return
            
        logger.info("Starting Telegram bot polling...")
        
        try:
            await self.dispatcher.start_polling(self.bot)
        except Exception as e:
            logger.error(f"Polling error: {e}")
        finally:
            await self.bot.session.close()
    
    def start(self):
        """Start the bot in a separate thread"""
        if self.running:
            logger.warning("Bot already running")
            return
        
        # Stop any existing instance first
        if self.thread and self.thread.is_alive():
            logger.info("Stopping existing bot instance...")
            self.stop()
            
        def run_bot():
            """Run bot in asyncio loop"""
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self.loop)
            
            try:
                # Initialize bot
                if not self.loop.run_until_complete(self.initialize()):
                    logger.error("Failed to initialize bot")
                    return
                
                self.running = True
                
                # Start polling
                try:
                    self.loop.run_until_complete(self.get_updates())
                except (KeyboardInterrupt, RuntimeError):
                    pass
                    
            except Exception as e:
                logger.error(f"Bot thread error: {e}")
            finally:
                self.running = False
                self.connected = False
                
                # Clean up bot session
                if self.bot:
                    try:
                        self.loop.run_until_complete(self.bot.session.close())
                    except:
                        pass
                
                # Close loop
                try:
                    self.loop.close()
                except:
                    pass
        
        self.thread = threading.Thread(target=run_bot, daemon=True)
        self.thread.start()
        logger.info("Telegram bot thread started")
    
    def stop(self):
        """Stop the bot"""
        if not self.running:
            return
            
        logger.info("Stopping Telegram bot...")
        self.running = False
        self.connected = False
        
        # Stop the event loop gracefully
        if self.loop and not self.loop.is_closed():
            try:
                # Schedule stop
                self.loop.call_soon_threadsafe(self.loop.stop)
            except:
                pass
        
        # Wait for thread to finish
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=3)
        
        # Clean up
        self.bot = None
        self.loop = None
        
        logger.info("Telegram bot stopped")
    
    def _store_message(self, message_data: Dict, is_sent: bool = False):
        """Store message in database"""
        try:
            from src.core.database import ChatMessage
            
            session = self.db_manager.get_session()
            
            msg = ChatMessage(
                telegram_message_id=message_data.get('id'),
                username=message_data['username'],
                message=message_data['text'],
                timestamp=datetime.fromisoformat(message_data['timestamp']),
                is_sent=is_sent
            )
            
            session.add(msg)
            session.commit()
            session.close()
            
        except Exception as e:
            logger.error(f"Failed to store message: {e}")
    
    def get_message_history(self, limit: int = 100) -> List[Dict]:
        """Get message history from database"""
        try:
            from src.core.database import ChatMessage
            
            session = self.db_manager.get_session()
            
            messages = session.query(ChatMessage)\
                .order_by(ChatMessage.timestamp.desc())\
                .limit(limit)\
                .all()
            
            history = []
            for msg in reversed(messages):
                history.append({
                    'username': msg.username,
                    'message': msg.message,
                    'timestamp': msg.timestamp.isoformat(),
                    'is_sent': msg.is_sent
                })
            
            session.close()
            return history
            
        except Exception as e:
            logger.error(f"Failed to get message history: {e}")
            return []
    
    def update_username(self, username: str):
        """Update username for chat"""
        self.username = username
        self.config.set('chat.username', username)
        logger.info(f"Username updated to: {username}")
    
    def update_credentials(self, bot_token: str, chat_id: str) -> bool:
        """Update bot credentials"""
        self.bot_token = bot_token
        self.chat_id = chat_id
        
        # Save to config
        self.config.set('chat.telegram_bot_token', bot_token)
        self.config.set('chat.telegram_chat_id', chat_id)
        
        # Restart bot if running
        if self.running:
            self.stop()
            time.sleep(2)
            self.start()
        
        return True
    
    def is_connected(self) -> bool:
        """Check if bot is connected"""
        return self.connected and self.running
    
    async def send_notification(self, title: str, message: str):
        """Send a notification message to the chat"""
        if not self.connected:
            return
            
        try:
            notification_text = f"🔔 *{title}*\n{message}\n\n_From GameHub OS_"
            
            await self.bot.send_message(
                chat_id=self.chat_id,
                text=notification_text,
                parse_mode="Markdown"
            )
            
        except Exception as e:
            logger.error(f"Failed to send notification: {e}")
