"""Database management module using SQLite and SQLAlchemy"""

import os
from pathlib import Path
from datetime import datetime
from sqlalchemy import create_engine, Column, String, Integer, Float, DateTime, Text, Boolean, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, scoped_session
from src.utils.logger import setup_logger

logger = setup_logger(__name__)

Base = declarative_base()


class Game(Base):
    """Game model for storing game information"""
    __tablename__ = 'games'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    path = Column(String(500), nullable=False, unique=True)
    executable = Column(String(500))
    cover_image = Column(Text)
    description = Column(Text)
    total_playtime = Column(Float, default=0.0)  # in hours
    last_played = Column(DateTime)
    added_date = Column(DateTime, default=datetime.utcnow)
    fps_average = Column(Integer, default=0)
    platform = Column(String(50))  # Steam, Epic, Local, etc.
    is_favorite = Column(Boolean, default=False)
    
    # Relationships
    sessions = relationship("GameSession", back_populates="game", cascade="all, delete-orphan")
    achievements = relationship("UserAchievement", back_populates="game")


class GameSession(Base):
    """Track individual gaming sessions"""
    __tablename__ = 'game_sessions'
    
    id = Column(Integer, primary_key=True)
    game_id = Column(Integer, ForeignKey('games.id'))
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime)
    duration = Column(Float, default=0.0)  # in hours
    fps_average = Column(Integer)
    cpu_usage = Column(Float)
    ram_usage = Column(Float)
    
    # Relationship
    game = relationship("Game", back_populates="sessions")


class UserSettings(Base):
    """Store user preferences and settings"""
    __tablename__ = 'user_settings'
    
    id = Column(Integer, primary_key=True)
    key = Column(String(100), unique=True, nullable=False)
    value = Column(Text)
    category = Column(String(50))
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Achievement(Base):
    """Define available achievements"""
    __tablename__ = 'achievements'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False, unique=True)
    description = Column(Text)
    icon = Column(Text)
    points = Column(Integer, default=10)
    category = Column(String(50))  # optimization, gaming, social, etc.
    requirement = Column(Text)  # JSON string with requirements
    
    # Relationship
    user_achievements = relationship("UserAchievement", back_populates="achievement")


class UserAchievement(Base):
    """Track user's unlocked achievements"""
    __tablename__ = 'user_achievements'
    
    id = Column(Integer, primary_key=True)
    achievement_id = Column(Integer, ForeignKey('achievements.id'))
    game_id = Column(Integer, ForeignKey('games.id'), nullable=True)
    unlocked_at = Column(DateTime, default=datetime.utcnow)
    progress = Column(Float, default=0.0)  # 0-100%
    
    # Relationships
    achievement = relationship("Achievement", back_populates="user_achievements")
    game = relationship("Game", back_populates="achievements")


class UserStats(Base):
    """Track user statistics and points"""
    __tablename__ = 'user_stats'
    
    id = Column(Integer, primary_key=True)
    total_points = Column(Integer, default=0)
    total_playtime = Column(Float, default=0.0)
    games_played = Column(Integer, default=0)
    optimizations_run = Column(Integer, default=0)
    achievements_unlocked = Column(Integer, default=0)
    current_level = Column(Integer, default=1)
    experience = Column(Integer, default=0)
    last_active = Column(DateTime, default=datetime.utcnow)


class OptimizationProfile(Base):
    """Store optimization profiles"""
    __tablename__ = 'optimization_profiles'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    settings = Column(Text)  # JSON string with optimization settings
    is_default = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class ChatMessage(Base):
    """Store chat messages locally for offline viewing"""
    __tablename__ = 'chat_messages'
    
    id = Column(Integer, primary_key=True)
    telegram_message_id = Column(Integer)
    username = Column(String(100))
    message = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)
    is_sent = Column(Boolean, default=False)


class DatabaseManager:
    """Manage database connections and operations"""
    
    def __init__(self, db_path=None):
        if db_path is None:
            app_data = Path.home() / '.gamehub_os'
            app_data.mkdir(exist_ok=True)
            db_path = app_data / 'gamehub.db'
        
        self.db_path = db_path
        self.engine = None
        self.Session = None
        
    def initialize(self):
        """Initialize database connection and create tables"""
        try:
            # Create engine
            self.engine = create_engine(
                f'sqlite:///{self.db_path}',
                echo=False,
                pool_size=10,
                max_overflow=20
            )
            
            # Create all tables
            Base.metadata.create_all(self.engine)
            
            # Create session factory
            self.Session = scoped_session(sessionmaker(bind=self.engine))
            
            # Initialize default data
            self._initialize_defaults()
            
            logger.info(f"Database initialized at {self.db_path}")
            
        except Exception as e:
            logger.error(f"Failed to initialize database: {e}")
            raise
    
    def _initialize_defaults(self):
        """Initialize default achievements and settings"""
        session = self.Session()
        try:
            # Check if already initialized
            if session.query(Achievement).count() == 0:
                # Add default achievements
                achievements = [
                    Achievement(
                        name="First Launch",
                        description="Launch GameHub OS for the first time",
                        points=5,
                        category="general"
                    ),
                    Achievement(
                        name="Game Collector",
                        description="Add 10 games to your library",
                        points=20,
                        category="gaming"
                    ),
                    Achievement(
                        name="Optimizer Pro",
                        description="Run system optimization 10 times",
                        points=25,
                        category="optimization"
                    ),
                    Achievement(
                        name="Social Butterfly",
                        description="Send 50 messages in global chat",
                        points=15,
                        category="social"
                    ),
                    Achievement(
                        name="Marathon Gamer",
                        description="Play games for a total of 100 hours",
                        points=50,
                        category="gaming"
                    ),
                ]
                session.add_all(achievements)
                
            # Initialize user stats if not exists
            if session.query(UserStats).count() == 0:
                user_stats = UserStats()
                session.add(user_stats)
            
            session.commit()
            
        except Exception as e:
            session.rollback()
            logger.error(f"Failed to initialize defaults: {e}")
        finally:
            session.close()
    
    def get_session(self):
        """Get a new database session"""
        return self.Session()
    
    def close(self):
        """Close database connections"""
        if self.Session:
            self.Session.remove()
        if self.engine:
            self.engine.dispose()
