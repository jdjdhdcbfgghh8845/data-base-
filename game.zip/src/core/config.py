"""Configuration management module"""

import json
import os
from pathlib import Path
from typing import Any, Dict, Optional
from datetime import datetime
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class Config:
    """Manage application configuration"""
    
    DEFAULT_CONFIG = {
        "appearance": {
            "theme": "dark_teal.xml",
            "font_family": "Segoe UI",
            "font_size": 10,
            "animations_enabled": True,
            "sound_effects": True,
            "background_image": None,
            "transparency": 95,
            "custom_colors": {
                "primary": "#00897B",
                "secondary": "#FF5722",
                "background": "#1E1E1E",
                "text": "#FFFFFF"
            }
        },
        "optimization": {
            "auto_optimize_on_game_launch": True,
            "ram_cleanup_threshold": 80,  # percentage
            "disable_background_apps": True,
            "cpu_priority_boost": True,
            "network_optimization": True,
            "defragmentation_schedule": "weekly",
            "excluded_processes": [
                "explorer.exe",
                "taskmgr.exe",
                "chrome.exe",
                "firefox.exe"
            ],
            "game_mode_profile": {
                "disable_windows_updates": True,
                "disable_notifications": True,
                "disable_defender_scan": False,
                "set_high_performance": True
            }
        },
        "game_library": {
            "scan_directories": [
                "C:\\Program Files\\Steam\\steamapps\\common",
                "C:\\Program Files\\Epic Games",
                "C:\\Program Files (x86)\\Steam\\steamapps\\common",
                "C:\\Games"
            ],
            "auto_scan_on_startup": True,
            "show_fps_overlay": True,
            "track_playtime": True,
            "fetch_metadata": True,
            "platforms": {
                "steam": {"enabled": True, "path": None},
                "epic": {"enabled": True, "path": None},
                "gog": {"enabled": True, "path": None},
                "ubisoft": {"enabled": True, "path": None},
                "origin": {"enabled": True, "path": None}
            }
        },
        "chat": {
            "telegram_bot_token": "",
            "telegram_chat_id": "",
            "username": "",
            "notifications_enabled": True,
            "message_history_limit": 1000,
            "auto_connect": True,
            "show_timestamps": True,
            "notification_sound": True
        },
        "achievements": {
            "show_notifications": True,
            "notification_duration": 5000,  # milliseconds
            "unlock_sound": True,
            "bonus_multiplier": 1.0,
            "auto_claim_rewards": True
        },
        "shortcuts": {
            "toggle_optimization": "Ctrl+O",
            "launch_game": "Ctrl+L",
            "open_chat": "Ctrl+T",
            "quick_scan": "Ctrl+S",
            "toggle_overlay": "Ctrl+Shift+O",
            "take_screenshot": "F12"
        },
        "updates": {
            "auto_check": True,
            "auto_download": False,
            "check_interval": 86400,  # seconds (24 hours)
            "update_channel": "stable"  # stable, beta, dev
        },
        "plugins": {
            "enabled": True,
            "directory": "plugins",
            "auto_load": True,
            "allowed_permissions": ["read", "write", "network"]
        },
        "performance": {
            "hardware_acceleration": True,
            "cache_size": 512,  # MB
            "log_level": "INFO",
            "telemetry": False,
            "crash_reports": True
        }
    }
    
    def __init__(self, config_path: Optional[Path] = None):
        """Initialize configuration manager"""
        if config_path is None:
            app_data = Path.home() / '.gamehub_os'
            app_data.mkdir(exist_ok=True)
            config_path = app_data / 'config.json'
        
        self.config_path = config_path
        self.config = self._load_config()
        
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file or create default"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    loaded_config = json.load(f)
                    # Merge with defaults to ensure all keys exist
                    return self._merge_configs(self.DEFAULT_CONFIG, loaded_config)
            except Exception as e:
                logger.error(f"Failed to load config: {e}")
                return self.DEFAULT_CONFIG.copy()
        else:
            # Create default config file
            self.save()
            return self.DEFAULT_CONFIG.copy()
    
    def _merge_configs(self, default: Dict, loaded: Dict) -> Dict:
        """Recursively merge loaded config with defaults"""
        result = default.copy()
        for key, value in loaded.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge_configs(result[key], value)
            else:
                result[key] = value
        return result
    
    def get(self, key_path: str, default: Any = None) -> Any:
        """Get configuration value using dot notation (e.g., 'appearance.theme')"""
        keys = key_path.split('.')
        value = self.config
        
        try:
            for key in keys:
                value = value[key]
            return value
        except (KeyError, TypeError):
            return default
    
    def set(self, key_path: str, value: Any) -> None:
        """Set configuration value using dot notation"""
        keys = key_path.split('.')
        config = self.config
        
        # Navigate to the parent of the target key
        for key in keys[:-1]:
            if key not in config:
                config[key] = {}
            config = config[key]
        
        # Set the value
        config[keys[-1]] = value
        
        # Auto-save
        self.save()
    
    def save(self) -> bool:
        """Save configuration to file"""
        try:
            # Create backup
            if self.config_path.exists():
                backup_path = self.config_path.with_suffix('.json.bak')
                backup_path.write_bytes(self.config_path.read_bytes())
            
            # Save config
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            
            logger.info("Configuration saved successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to save config: {e}")
            return False
    
    def reset(self, section: Optional[str] = None) -> None:
        """Reset configuration to defaults"""
        if section:
            if section in self.DEFAULT_CONFIG:
                self.config[section] = self.DEFAULT_CONFIG[section].copy()
                logger.info(f"Reset configuration section: {section}")
        else:
            self.config = self.DEFAULT_CONFIG.copy()
            logger.info("Reset all configuration to defaults")
        
        self.save()
    
    def export_config(self, path: Path) -> bool:
        """Export configuration to specified path"""
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            logger.info(f"Configuration exported to {path}")
            return True
        except Exception as e:
            logger.error(f"Failed to export config: {e}")
            return False
    
    def import_config(self, path: Path) -> bool:
        """Import configuration from specified path"""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                imported_config = json.load(f)
                self.config = self._merge_configs(self.DEFAULT_CONFIG, imported_config)
                self.save()
            logger.info(f"Configuration imported from {path}")
            return True
        except Exception as e:
            logger.error(f"Failed to import config: {e}")
            return False
    
    def get_all(self) -> Dict[str, Any]:
        """Get entire configuration dictionary"""
        return self.config.copy()
    
    def validate_telegram_config(self) -> bool:
        """Validate Telegram bot configuration"""
        token = self.get('chat.telegram_bot_token')
        chat_id = self.get('chat.telegram_chat_id')
        return bool(token and chat_id)
