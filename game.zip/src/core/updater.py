"""Auto-updater module for GameHub OS"""

import os
import sys
import json
import shutil
import zipfile
import tempfile
import subprocess
from pathlib import Path
from typing import Optional, Dict, Tuple
import requests
from packaging import version
from datetime import datetime
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class AutoUpdater:
    """Handles automatic updates from GitHub"""
    
    GITHUB_REPO = "jdjdhdcbfgghh8845/data-base-"
    VERSION_URL = f"https://raw.githubusercontent.com/{GITHUB_REPO}/main/version.json"
    RELEASE_URL = f"https://github.com/{GITHUB_REPO}/releases/latest/download/GameHubOS.zip"
    REPO_ZIP_URL = f"https://github.com/{GITHUB_REPO}/archive/refs/heads/main.zip"
    
    def __init__(self, app_path: Optional[Path] = None):
        """Initialize updater"""
        self.app_path = app_path or Path(sys.argv[0]).parent
        self.version_file = self.app_path / "version.json"
        self.backup_dir = self.app_path / ".backup"
        self.temp_dir = Path(tempfile.gettempdir()) / "gamehub_update"
        self.current_version = self._load_local_version()
        
    def _load_local_version(self) -> str:
        """Load current version from local file"""
        try:
            if self.version_file.exists():
                with open(self.version_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get('version', '1.0.0')
            else:
                # Create default version file
                self._save_local_version('1.0.0')
                return '1.0.0'
        except Exception as e:
            logger.error(f"Error loading local version: {e}")
            return '1.0.0'
    
    def _save_local_version(self, version_str: str) -> None:
        """Save version to local file"""
        try:
            version_data = {
                'version': version_str,
                'last_check': datetime.now().isoformat(),
                'app': 'GameHub OS'
            }
            with open(self.version_file, 'w', encoding='utf-8') as f:
                json.dump(version_data, f, indent=2)
            logger.info(f"Saved local version: {version_str}")
        except Exception as e:
            logger.error(f"Error saving local version: {e}")
    
    def check_for_updates(self) -> Tuple[bool, Optional[str], Optional[Dict]]:
        """Check if updates are available"""
        try:
            logger.info("Checking for updates...")
            
            # Fetch remote version
            response = requests.get(self.VERSION_URL, timeout=10)
            response.raise_for_status()
            
            remote_data = response.json()
            remote_version = remote_data.get('version', '1.0.0')
            
            # Compare versions
            current_ver = version.parse(self.current_version)
            remote_ver = version.parse(remote_version)
            
            if remote_ver > current_ver:
                logger.info(f"Update available: {self.current_version} -> {remote_version}")
                return True, remote_version, remote_data
            else:
                logger.info(f"No updates available. Current version: {self.current_version}")
                return False, None, None
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Network error checking for updates: {e}")
            return False, None, None
        except Exception as e:
            logger.error(f"Error checking for updates: {e}")
            return False, None, None
    
    def download_update(self, update_info: Dict) -> Optional[Path]:
        """Download update package"""
        try:
            logger.info("Downloading update...")
            
            # Create temp directory
            self.temp_dir.mkdir(parents=True, exist_ok=True)
            
            # Try to get download URL from update info
            download_url = update_info.get('download_url', self.REPO_ZIP_URL)
            
            # Download file
            response = requests.get(download_url, stream=True, timeout=30)
            response.raise_for_status()
            
            # Save to temp file
            update_file = self.temp_dir / "update.zip"
            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0
            
            with open(update_file, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total_size > 0:
                            progress = (downloaded / total_size) * 100
                            logger.info(f"Download progress: {progress:.1f}%")
            
            logger.info(f"Update downloaded to: {update_file}")
            return update_file
            
        except Exception as e:
            logger.error(f"Error downloading update: {e}")
            return None
    
    def backup_current_version(self) -> bool:
        """Backup current installation"""
        try:
            logger.info("Creating backup of current version...")
            
            # Create backup directory
            self.backup_dir.mkdir(exist_ok=True)
            
            # Backup timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_path = self.backup_dir / f"backup_{self.current_version}_{timestamp}"
            backup_path.mkdir(exist_ok=True)
            
            # Files/directories to backup
            items_to_backup = [
                'src',
                'main.py',
                'requirements.txt',
                'version.json',
                'config.json'
            ]
            
            for item in items_to_backup:
                source = self.app_path / item
                if source.exists():
                    dest = backup_path / item
                    if source.is_dir():
                        shutil.copytree(source, dest, dirs_exist_ok=True)
                    else:
                        shutil.copy2(source, dest)
            
            logger.info(f"Backup created at: {backup_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error creating backup: {e}")
            return False
    
    def install_update(self, update_file: Path, new_version: str) -> bool:
        """Install the downloaded update"""
        try:
            logger.info("Installing update...")
            
            # Create backup first
            if not self.backup_current_version():
                logger.warning("Failed to create backup, continuing anyway...")
            
            # Extract update
            extract_path = self.temp_dir / "extracted"
            extract_path.mkdir(exist_ok=True)
            
            with zipfile.ZipFile(update_file, 'r') as zip_ref:
                zip_ref.extractall(extract_path)
            
            # Find the root of extracted files (might be in a subdirectory)
            extracted_dirs = list(extract_path.iterdir())
            if len(extracted_dirs) == 1 and extracted_dirs[0].is_dir():
                # GitHub-style archive with repo name as root dir
                update_root = extracted_dirs[0]
            else:
                update_root = extract_path
            
            # Copy updated files
            self._copy_update_files(update_root)
            
            # Update version file
            self._save_local_version(new_version)
            
            # Clean up temp files
            shutil.rmtree(self.temp_dir, ignore_errors=True)
            
            logger.info(f"Update installed successfully! New version: {new_version}")
            return True
            
        except Exception as e:
            logger.error(f"Error installing update: {e}")
            self.rollback()
            return False
    
    def _copy_update_files(self, source_dir: Path) -> None:
        """Copy update files to application directory"""
        # Files/directories to update
        update_items = [
            'src',
            'main.py',
            'requirements.txt',
            'README.md'
        ]
        
        for item in update_items:
            source = source_dir / item
            if source.exists():
                dest = self.app_path / item
                
                # Remove old version
                if dest.exists():
                    if dest.is_dir():
                        shutil.rmtree(dest)
                    else:
                        dest.unlink()
                
                # Copy new version
                if source.is_dir():
                    shutil.copytree(source, dest)
                else:
                    shutil.copy2(source, dest)
                    
                logger.info(f"Updated: {item}")
    
    def rollback(self) -> bool:
        """Rollback to previous version from backup"""
        try:
            logger.info("Rolling back to previous version...")
            
            if not self.backup_dir.exists():
                logger.error("No backup directory found")
                return False
            
            # Find latest backup
            backups = sorted(self.backup_dir.iterdir(), key=lambda x: x.stat().st_mtime)
            if not backups:
                logger.error("No backups found")
                return False
            
            latest_backup = backups[-1]
            logger.info(f"Restoring from backup: {latest_backup}")
            
            # Restore files
            for item in latest_backup.iterdir():
                dest = self.app_path / item.name
                
                # Remove current version
                if dest.exists():
                    if dest.is_dir():
                        shutil.rmtree(dest)
                    else:
                        dest.unlink()
                
                # Restore from backup
                if item.is_dir():
                    shutil.copytree(item, dest)
                else:
                    shutil.copy2(item, dest)
            
            logger.info("Rollback completed successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error during rollback: {e}")
            return False
    
    def restart_application(self) -> None:
        """Restart the application after update"""
        try:
            logger.info("Restarting application...")
            
            # Command to restart
            python = sys.executable
            script = str(self.app_path / "main.py")
            
            # Start new instance
            if sys.platform == "win32":
                # Windows
                subprocess.Popen([python, script], 
                               creationflags=subprocess.CREATE_NEW_CONSOLE)
            else:
                # Unix-like
                subprocess.Popen([python, script])
            
            # Exit current instance
            logger.info("Exiting current instance...")
            sys.exit(0)
            
        except Exception as e:
            logger.error(f"Error restarting application: {e}")
    
    def perform_update(self, auto_restart: bool = True) -> bool:
        """Perform complete update process"""
        try:
            # Check for updates
            has_update, new_version, update_info = self.check_for_updates()
            
            if not has_update:
                return False
            
            # Download update
            update_file = self.download_update(update_info or {})
            if not update_file:
                logger.error("Failed to download update")
                return False
            
            # Install update
            if not self.install_update(update_file, new_version):
                logger.error("Failed to install update")
                return False
            
            # Install new dependencies if needed
            self.install_dependencies()
            
            # Restart if requested
            if auto_restart:
                self.restart_application()
            
            return True
            
        except Exception as e:
            logger.error(f"Error performing update: {e}")
            return False
    
    def install_dependencies(self) -> None:
        """Install/update dependencies after update"""
        try:
            requirements_file = self.app_path / "requirements.txt"
            if requirements_file.exists():
                logger.info("Installing updated dependencies...")
                subprocess.run([
                    sys.executable, "-m", "pip", "install", 
                    "-r", str(requirements_file), "--quiet"
                ], check=True)
                logger.info("Dependencies updated")
        except Exception as e:
            logger.error(f"Error updating dependencies: {e}")
    
    def get_changelog(self, update_info: Dict) -> str:
        """Get changelog from update info"""
        changelog = update_info.get('changelog', '')
        if not changelog:
            changelog = update_info.get('description', 'No changelog available')
        return changelog
    
    def schedule_update_check(self, interval_hours: int = 24) -> None:
        """Schedule periodic update checks"""
        import threading
        
        def check_updates_periodic():
            while True:
                time.sleep(interval_hours * 3600)
                has_update, new_version, _ = self.check_for_updates()
                if has_update:
                    logger.info(f"Update available: {new_version}")
                    # Here you could send a notification to the UI
        
        thread = threading.Thread(target=check_updates_periodic, daemon=True)
        thread.start()
        logger.info(f"Scheduled update checks every {interval_hours} hours")
