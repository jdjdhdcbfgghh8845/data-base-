"""System optimization module for performance enhancement"""

import os
import sys
import psutil
import subprocess
import time
import ctypes
from typing import List, Dict, Tuple, Optional
from datetime import datetime
import json
import threading

if sys.platform == "win32":
    import win32process
    import win32api
    import win32con
    import win32security

from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class SystemOptimizer:
    """Optimize system performance for gaming"""
    
    # Processes that should never be killed
    CRITICAL_PROCESSES = [
        'system', 'smss.exe', 'csrss.exe', 'wininit.exe',
        'services.exe', 'lsass.exe', 'winlogon.exe',
        'explorer.exe', 'dwm.exe', 'taskmgr.exe',
        'svchost.exe', 'conhost.exe', 'ctfmon.exe'
    ]
    
    # Common unnecessary background processes
    OPTIONAL_PROCESSES = [
        'searchui.exe', 'cortana.exe', 'skype.exe',
        'teams.exe', 'discord.exe', 'slack.exe',
        'dropbox.exe', 'onedrive.exe', 'googledrivesync.exe',
        'adobeupdater.exe', 'steamwebhelper.exe',
        'epicwebhelper.exe', 'originwebhelperservice.exe'
    ]
    
    # Services that can be temporarily disabled
    OPTIONAL_SERVICES = [
        'WSearch',  # Windows Search
        'SysMain',  # Superfetch
        'DiagTrack',  # Diagnostics Tracking
        'DusmSvc',  # Data Usage
        'TabletInputService',  # Touch Keyboard
        'PrintSpooler',  # Print Spooler (if not printing)
    ]
    
    def __init__(self, config=None):
        """Initialize optimizer"""
        self.config = config
        self.original_state = {}
        self.optimization_active = False
        self.stats = {
            'ram_freed': 0,
            'processes_closed': 0,
            'services_stopped': 0,
            'cpu_priority_changed': 0
        }
        
    def get_system_info(self) -> Dict:
        """Get current system information"""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            # Get network info
            net_io = psutil.net_io_counters()
            
            # Get temperature if available
            temps = {}
            if hasattr(psutil, "sensors_temperatures"):
                temps_data = psutil.sensors_temperatures()
                if temps_data:
                    for name, entries in temps_data.items():
                        temps[name] = entries[0].current if entries else 0
            
            return {
                'cpu': {
                    'percent': cpu_percent,
                    'cores': psutil.cpu_count(),
                    'frequency': psutil.cpu_freq().current if psutil.cpu_freq() else 0
                },
                'memory': {
                    'total': memory.total,
                    'available': memory.available,
                    'percent': memory.percent,
                    'used': memory.used,
                    'free': memory.free
                },
                'disk': {
                    'total': disk.total,
                    'used': disk.used,
                    'free': disk.free,
                    'percent': disk.percent
                },
                'network': {
                    'bytes_sent': net_io.bytes_sent,
                    'bytes_recv': net_io.bytes_recv,
                    'packets_sent': net_io.packets_sent,
                    'packets_recv': net_io.packets_recv
                },
                'temperatures': temps,
                'processes': len(psutil.pids())
            }
        except Exception as e:
            logger.error(f"Error getting system info: {e}")
            return {}
    
    def optimize_for_gaming(self, game_executable: Optional[str] = None) -> Dict:
        """Perform full system optimization for gaming (NO ADMIN REQUIRED)"""
        logger.info("Starting ULTRA gaming optimization (user-mode)...")
        self.optimization_active = True
        self.stats = {
            'ram_freed': 0,
            'processes_closed': 0,
            'services_stopped': 0,
            'cpu_priority_changed': 0
        }
        
        # Save original state
        self._save_system_state()
        
        # ULTRA Optimization steps (NO ADMIN)
        results = {
            'ram_cleanup': self.optimize_ram_nonadmin(),
            'process_management': self.manage_processes_nonadmin(),
            'cpu_priority': self.optimize_cpu_priority_nonadmin(game_executable),
            'cpu_affinity': self.optimize_cpu_affinity(game_executable),
            'network': self.optimize_network_nonadmin(),
            'power_plan': self.set_power_mode_nonadmin(),
            'timer_resolution': self.set_timer_resolution(),
            'user_tweaks': self.apply_user_tweaks(),
            'game_mode': self.enable_game_mode(),
            'visual_effects': self.disable_visual_effects(),
            'background_apps': self.limit_background_apps()
        }
        
        # Calculate total RAM freed
        self.stats['ram_freed'] = results['ram_cleanup'].get('freed_mb', 0)
        
        logger.info(f"ULTRA Optimization complete: {self.stats}")
        return {
            'success': True,
            'stats': self.stats,
            'details': results
        }
    
    def optimize_ram(self) -> Dict:
        """Free up RAM by various methods"""
        logger.info("Optimizing RAM...")
        initial_memory = psutil.virtual_memory()
        
        try:
            if sys.platform == "win32":
                # Empty working sets
                self._empty_working_sets()
                
                # Clear system cache
                self._clear_system_cache()
                
                # Force garbage collection
                import gc
                gc.collect()
                
            # Kill memory-intensive unnecessary processes
            self._kill_memory_hogs()
            
            # Wait for changes to take effect
            time.sleep(2)
            
            final_memory = psutil.virtual_memory()
            freed_mb = (initial_memory.used - final_memory.used) / (1024 * 1024)
            
            return {
                'success': True,
                'initial_used': initial_memory.used,
                'final_used': final_memory.used,
                'freed_mb': max(0, freed_mb),
                'final_percent': final_memory.percent
            }
            
        except Exception as e:
            logger.error(f"RAM optimization error: {e}")
            return {'success': False, 'error': str(e)}
    
    def manage_processes(self) -> Dict:
        """Manage background processes"""
        logger.info("Managing background processes...")
        closed_processes = []
        
        try:
            excluded = []
            if self.config:
                excluded = self.config.get('optimization.excluded_processes', [])
            
            for proc in psutil.process_iter(['pid', 'name', 'memory_percent']):
                try:
                    proc_name = proc.info['name'].lower()
                    
                    # Skip critical and excluded processes
                    if proc_name in self.CRITICAL_PROCESSES or proc_name in excluded:
                        continue
                    
                    # Check if it's an optional process
                    if proc_name in self.OPTIONAL_PROCESSES:
                        # Store original state
                        self.original_state[proc_name] = {
                            'pid': proc.info['pid'],
                            'status': 'running'
                        }
                        
                        # Terminate the process
                        proc.terminate()
                        closed_processes.append(proc_name)
                        self.stats['processes_closed'] += 1
                        
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            return {
                'success': True,
                'closed': closed_processes,
                'count': len(closed_processes)
            }
            
        except Exception as e:
            logger.error(f"Process management error: {e}")
            return {'success': False, 'error': str(e)}
    
    def optimize_cpu_priority(self, game_executable: Optional[str] = None) -> Dict:
        """Optimize CPU priority for gaming"""
        logger.info("Optimizing CPU priority...")
        
        if not game_executable or sys.platform != "win32":
            return {'success': False, 'reason': 'Not applicable'}
        
        try:
            # Find the game process
            game_proc = None
            game_name = os.path.basename(game_executable).lower()
            
            for proc in psutil.process_iter(['pid', 'name']):
                if proc.info['name'].lower() == game_name:
                    game_proc = proc
                    break
            
            if game_proc:
                # Set game to high priority
                handle = win32api.OpenProcess(win32con.PROCESS_ALL_ACCESS, True, game_proc.pid)
                win32process.SetPriorityClass(handle, win32process.HIGH_PRIORITY_CLASS)
                win32api.CloseHandle(handle)
                
                self.stats['cpu_priority_changed'] += 1
                
                # Set other processes to lower priority
                for proc in psutil.process_iter(['pid', 'name']):
                    try:
                        if proc.info['name'].lower() not in self.CRITICAL_PROCESSES:
                            if proc.pid != game_proc.pid:
                                handle = win32api.OpenProcess(win32con.PROCESS_ALL_ACCESS, True, proc.pid)
                                win32process.SetPriorityClass(handle, win32process.BELOW_NORMAL_PRIORITY_CLASS)
                                win32api.CloseHandle(handle)
                    except:
                        continue
                
                return {
                    'success': True,
                    'game_process': game_name,
                    'priority': 'HIGH'
                }
            
            return {'success': False, 'reason': 'Game process not found'}
            
        except Exception as e:
            logger.error(f"CPU priority optimization error: {e}")
            return {'success': False, 'error': str(e)}
    
    def optimize_network(self) -> Dict:
        """Optimize network settings for gaming"""
        logger.info("Optimizing network...")
        
        if sys.platform != "win32":
            return {'success': False, 'reason': 'Only supported on Windows'}
        
        try:
            commands = [
                # Disable network throttling
                'netsh int tcp set global autotuninglevel=normal',
                # Disable Nagle's algorithm
                'netsh int tcp set global timestamps=disabled',
                # Set network profile to private for better performance
                'powershell Set-NetConnectionProfile -InterfaceAlias "*" -NetworkCategory Private',
            ]
            
            results = []
            for cmd in commands:
                try:
                    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                    results.append({
                        'command': cmd.split()[0],
                        'success': result.returncode == 0
                    })
                except:
                    continue
            
            return {
                'success': True,
                'optimizations': results
            }
            
        except Exception as e:
            logger.error(f"Network optimization error: {e}")
            return {'success': False, 'error': str(e)}
    
    def set_high_performance_mode(self) -> Dict:
        """Set Windows to high performance power plan"""
        logger.info("Setting high performance mode...")
        
        if sys.platform != "win32":
            return {'success': False, 'reason': 'Only supported on Windows'}
        
        try:
            # Get current power plan
            result = subprocess.run(
                'powercfg /getactivescheme',
                shell=True, capture_output=True, text=True
            )
            
            # Store original for restoration
            self.original_state['power_plan'] = result.stdout
            
            # Set to high performance
            subprocess.run(
                'powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c',
                shell=True
            )
            
            return {
                'success': True,
                'previous_plan': self.original_state.get('power_plan', 'unknown'),
                'current_plan': 'High Performance'
            }
            
        except Exception as e:
            logger.error(f"Power plan error: {e}")
            return {'success': False, 'error': str(e)}
    
    def manage_services(self, stop: bool = True) -> Dict:
        """Start or stop optional Windows services"""
        logger.info(f"{'Stopping' if stop else 'Starting'} optional services...")
        
        if sys.platform != "win32":
            return {'success': False, 'reason': 'Only supported on Windows'}
        
        managed_services = []
        
        for service in self.OPTIONAL_SERVICES:
            try:
                cmd = f'net {"stop" if stop else "start"} {service}'
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                
                if result.returncode == 0:
                    managed_services.append(service)
                    if stop:
                        self.stats['services_stopped'] += 1
                        
            except:
                continue
        
        return {
            'success': True,
            'action': 'stopped' if stop else 'started',
            'services': managed_services,
            'count': len(managed_services)
        }
    
    def restore_system(self) -> Dict:
        """Restore system to original state"""
        logger.info("Restoring system to original state...")
        
        if not self.optimization_active:
            return {'success': False, 'reason': 'No optimization active'}
        
        try:
            # Restore services
            self.manage_services(stop=False)
            
            # Restore power plan
            if 'power_plan' in self.original_state and sys.platform == "win32":
                # Extract GUID from original power plan output
                import re
                match = re.search(r'([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})',
                                self.original_state['power_plan'])
                if match:
                    subprocess.run(f'powercfg /setactive {match.group(1)}', shell=True)
            
            self.optimization_active = False
            self.original_state = {}
            
            return {'success': True}
            
        except Exception as e:
            logger.error(f"System restore error: {e}")
            return {'success': False, 'error': str(e)}
    
    def _save_system_state(self):
        """Save current system state before optimization"""
        self.original_state['timestamp'] = datetime.now().isoformat()
        self.original_state['memory'] = psutil.virtual_memory()._asdict()
        self.original_state['cpu'] = psutil.cpu_percent()
    
    def _empty_working_sets(self):
        """Empty working sets to free RAM (Windows)"""
        if sys.platform != "win32":
            return
        
        try:
            # This requires admin privileges
            kernel32 = ctypes.windll.kernel32
            for proc in psutil.process_iter(['pid']):
                try:
                    handle = kernel32.OpenProcess(0x1F0FFF, False, proc.pid)
                    if handle:
                        kernel32.SetProcessWorkingSetSize(handle, -1, -1)
                        kernel32.CloseHandle(handle)
                except:
                    continue
        except Exception as e:
            logger.debug(f"Could not empty working sets: {e}")
    
    def _clear_system_cache(self):
        """Clear system file cache"""
        if sys.platform != "win32":
            return
        
        try:
            # Clear DNS cache
            subprocess.run('ipconfig /flushdns', shell=True, capture_output=True)
        except:
            pass
    
    def _kill_memory_hogs(self):
        """Kill processes using excessive memory"""
        threshold = 200  # MB
        
        for proc in psutil.process_iter(['pid', 'name', 'memory_info']):
            try:
                memory_mb = proc.info['memory_info'].rss / (1024 * 1024)
                proc_name = proc.info['name'].lower()
                
                # Skip critical processes
                if proc_name in self.CRITICAL_PROCESSES:
                    continue
                
                # Kill if using too much memory and is optional
                if memory_mb > threshold and proc_name in self.OPTIONAL_PROCESSES:
                    proc.terminate()
                    self.stats['processes_closed'] += 1
                    
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
    
    def optimize_cpu_affinity(self, game_executable: Optional[str] = None) -> Dict:
        """Set CPU affinity for optimal performance - BOOST FPS"""
        logger.info("Optimizing CPU affinity for MAX FPS...")
        
        try:
            cpu_count = psutil.cpu_count(logical=True)
            physical_cores = psutil.cpu_count(logical=False)
            
            # Reserve best physical cores for game
            if cpu_count >= 8:
                # Use physical cores 0-3 for game (avoid hyperthreading)
                game_affinity = [0, 2, 4, 6]  # Physical cores only
                system_affinity = [1, 3, 5, 7]  # Logical cores for system
            elif cpu_count >= 4:
                game_affinity = [0, 1, 2]
                system_affinity = [3]
            else:
                return {'success': False, 'reason': 'Need 4+ cores'}
            
            optimized = []
            
            # If game is specified, boost it
            if game_executable:
                game_name = os.path.basename(game_executable).lower()
                for proc in psutil.process_iter(['pid', 'name']):
                    try:
                        if proc.info['name'].lower() == game_name:
                            proc.cpu_affinity(game_affinity)
                            proc.nice(psutil.HIGH_PRIORITY_CLASS)
                            optimized.append(game_name)
                    except:
                        continue
            
            # Move system processes to other cores
            system_procs = ['explorer.exe', 'dwm.exe', 'csrss.exe']
            for proc in psutil.process_iter(['pid', 'name']):
                try:
                    if proc.info['name'].lower() in system_procs:
                        proc.cpu_affinity(system_affinity)
                except:
                    continue
            
            return {
                'success': True,
                'game_cores': game_affinity,
                'optimized': optimized
            }
            
        except Exception as e:
            logger.error(f"CPU affinity error: {e}")
            return {'success': False, 'error': str(e)}
    
    def optimize_gpu(self) -> Dict:
        """Optimize GPU settings for gaming"""
        logger.info("Optimizing GPU...")
        
        if sys.platform != "win32":
            return {'success': False, 'reason': 'Only supported on Windows'}
        
        try:
            optimizations = []
            
            # NVIDIA optimizations
            nvidia_tweaks = [
                # Set maximum performance mode
                'nvidia-smi -pm 1',
                # Set power limit to maximum
                'nvidia-smi -pl 300',
            ]
            
            for cmd in nvidia_tweaks:
                try:
                    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                    if result.returncode == 0:
                        optimizations.append('NVIDIA: ' + cmd.split()[1])
                except:
                    pass
            
            # Windows Graphics Settings
            registry_tweaks = [
                # Disable GPU scheduling (can reduce latency)
                'reg add "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers" /v HwSchMode /t REG_DWORD /d 2 /f',
            ]
            
            for cmd in registry_tweaks:
                try:
                    subprocess.run(cmd, shell=True, capture_output=True)
                    optimizations.append('Registry tweak applied')
                except:
                    pass
            
            return {
                'success': True,
                'optimizations': optimizations
            }
            
        except Exception as e:
            logger.error(f"GPU optimization error: {e}")
            return {'success': False, 'error': str(e)}
    
    def optimize_disk(self) -> Dict:
        """Optimize disk performance"""
        logger.info("Optimizing disk...")
        
        if sys.platform != "win32":
            return {'success': False, 'reason': 'Only supported on Windows'}
        
        try:
            optimizations = []
            
            # Disable Windows Search indexing for game drives
            subprocess.run('sc config "WSearch" start=disabled', shell=True, capture_output=True)
            optimizations.append('Disabled Windows Search')
            
            # Disable Superfetch/SysMain
            subprocess.run('sc config "SysMain" start=disabled', shell=True, capture_output=True)
            optimizations.append('Disabled SysMain')
            
            # Set disk timeout
            subprocess.run('powercfg -change -disk-timeout-ac 0', shell=True, capture_output=True)
            optimizations.append('Disabled disk timeout')
            
            return {
                'success': True,
                'optimizations': optimizations
            }
            
        except Exception as e:
            logger.error(f"Disk optimization error: {e}")
            return {'success': False, 'error': str(e)}
    
    def apply_windows_tweaks(self) -> Dict:
        """Apply Windows registry tweaks for gaming"""
        logger.info("Applying Windows tweaks...")
        
        if sys.platform != "win32":
            return {'success': False, 'reason': 'Only supported on Windows'}
        
        try:
            tweaks = []
            
            registry_commands = [
                # Disable Game DVR
                'reg add "HKEY_CURRENT_USER\\System\\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 0 /f',
                # Disable Game Bar
                'reg add "HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\GameDVR" /v AppCaptureEnabled /t REG_DWORD /d 0 /f',
                # Disable Nagle\'s Algorithm
                'reg add "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces" /v TcpAckFrequency /t REG_DWORD /d 1 /f',
                'reg add "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces" /v TCPNoDelay /t REG_DWORD /d 1 /f',
                # Disable Windows Update during gaming
                'reg add "HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU" /v NoAutoUpdate /t REG_DWORD /d 1 /f',
                # Reduce mouse/keyboard input delay
                'reg add "HKEY_CURRENT_USER\\Control Panel\\Mouse" /v MouseSpeed /t REG_SZ /d 0 /f',
                'reg add "HKEY_CURRENT_USER\\Control Panel\\Mouse" /v MouseThreshold1 /t REG_SZ /d 0 /f',
                'reg add "HKEY_CURRENT_USER\\Control Panel\\Mouse" /v MouseThreshold2 /t REG_SZ /d 0 /f',
                # Disable transparency effects
                'reg add "HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" /v EnableTransparency /t REG_DWORD /d 0 /f',
                # Disable animations
                'reg add "HKEY_CURRENT_USER\\Control Panel\\Desktop\\WindowMetrics" /v MinAnimate /t REG_SZ /d 0 /f',
            ]
            
            for cmd in registry_commands:
                try:
                    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                    if result.returncode == 0:
                        tweaks.append('Applied')
                except:
                    pass
            
            return {
                'success': True,
                'tweaks_applied': len(tweaks)
            }
            
        except Exception as e:
            logger.error(f"Windows tweaks error: {e}")
            return {'success': False, 'error': str(e)}
    
    def set_timer_resolution(self) -> Dict:
        """Set Windows timer resolution for lower latency"""
        logger.info("Setting timer resolution...")
        
        if sys.platform != "win32":
            return {'success': False, 'reason': 'Only supported on Windows'}
        
        try:
            # Use Windows multimedia timer for 1ms resolution
            import ctypes
            winmm = ctypes.WinDLL('winmm')
            
            # Set to 1ms (lowest possible)
            result = winmm.timeBeginPeriod(1)
            
            if result == 0:  # TIMERR_NOERROR
                return {
                    'success': True,
                    'resolution': '1ms',
                    'note': 'Ultra-low latency timer active'
                }
            else:
                return {'success': False, 'reason': 'Failed to set timer'}
                
        except Exception as e:
            logger.error(f"Timer resolution error: {e}")
            return {'success': False, 'error': str(e)}
    
    def disable_fullscreen_optimization(self) -> Dict:
        """Disable fullscreen optimizations for better performance"""
        logger.info("Disabling fullscreen optimizations...")
        
        if sys.platform != "win32":
            return {'success': False, 'reason': 'Only supported on Windows'}
        
        try:
            # Disable fullscreen optimizations globally
            cmd = 'reg add "HKEY_CURRENT_USER\\System\\GameConfigStore" /v GameDVR_FSEBehaviorMode /t REG_DWORD /d 2 /f'
            result = subprocess.run(cmd, shell=True, capture_output=True)
            
            # Disable DWM (Desktop Window Manager) optimizations
            cmd2 = 'reg add "HKEY_CURRENT_USER\\System\\GameConfigStore" /v GameDVR_DXGIHonorFSEWindowsCompatible /t REG_DWORD /d 1 /f'
            subprocess.run(cmd2, shell=True, capture_output=True)
            
            return {
                'success': True,
                'note': 'Fullscreen optimizations disabled for maximum FPS'
            }
            
        except Exception as e:
            logger.error(f"Fullscreen optimization error: {e}")
            return {'success': False, 'error': str(e)}
    
    def optimize_ram_nonadmin(self) -> Dict:
        """Free up RAM without admin rights - AGGRESSIVE MODE"""
        logger.info("Optimizing RAM (AGGRESSIVE)...")
        initial_memory = psutil.virtual_memory()
        
        try:
            # Force garbage collection multiple times
            import gc
            for _ in range(3):
                gc.collect()
            
            # Kill memory-heavy processes AGGRESSIVELY
            killed = []
            memory_hogs = [
                'chrome.exe', 'firefox.exe', 'msedge.exe', 'opera.exe',
                'teams.exe', 'slack.exe', 'discord.exe', 'spotify.exe',
                'onedrive.exe', 'dropbox.exe', 'googledrivesync.exe',
                'steamwebhelper.exe', 'epicwebhelper.exe',
                'nvidia share.exe', 'nvcontainer.exe',
                'origin.exe', 'uplay.exe', 'battlenet.exe',
                'skype.exe', 'zoom.exe', 'obs64.exe', 'obs32.exe'
            ]
            
            for proc in psutil.process_iter(['pid', 'name', 'memory_info']):
                try:
                    proc_name = proc.info['name'].lower()
                    memory_mb = proc.info['memory_info'].rss / (1024 * 1024)
                    
                    # Kill if in memory hogs list OR using 300MB+
                    if proc_name in memory_hogs or memory_mb > 300:
                        if proc_name not in self.CRITICAL_PROCESSES:
                            try:
                                proc.terminate()
                                killed.append(f"{proc_name} ({int(memory_mb)}MB)")
                                self.stats['processes_closed'] += 1
                                time.sleep(0.05)
                            except:
                                pass
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            # Wait for processes to close
            time.sleep(2)
            
            # Force Windows to free standby memory (user-level trick)
            try:
                # Create large memory allocation and release it
                dummy = bytearray(100 * 1024 * 1024)  # 100MB
                del dummy
                gc.collect()
            except:
                pass
            
            final_memory = psutil.virtual_memory()
            freed_mb = (initial_memory.used - final_memory.used) / (1024 * 1024)
            
            return {
                'success': True,
                'freed_mb': max(0, freed_mb),
                'processes_killed': killed,
                'initial_used': f"{initial_memory.used / (1024**3):.1f}GB",
                'final_used': f"{final_memory.used / (1024**3):.1f}GB"
            }
        except Exception as e:
            logger.error(f"RAM optimization error: {e}")
            return {'success': False, 'error': str(e)}
    
    def manage_processes_nonadmin(self) -> Dict:
        """Manage processes without admin rights"""
        logger.info("Managing processes (user-mode)...")
        closed = []
        
        try:
            for proc in psutil.process_iter(['pid', 'name', 'username']):
                try:
                    proc_name = proc.info['name'].lower()
                    
                    # Only close user's own processes
                    if proc_name in self.OPTIONAL_PROCESSES:
                        if proc_name not in self.CRITICAL_PROCESSES:
                            proc.terminate()
                            closed.append(proc_name)
                            self.stats['processes_closed'] += 1
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            return {'success': True, 'closed': closed}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def optimize_cpu_priority_nonadmin(self, game_executable: Optional[str] = None) -> Dict:
        """Set CPU priority without admin (limited)"""
        logger.info("Optimizing CPU priority (user-mode)...")
        
        if not game_executable:
            return {'success': False, 'reason': 'No game specified'}
        
        try:
            game_name = os.path.basename(game_executable).lower()
            
            for proc in psutil.process_iter(['pid', 'name']):
                try:
                    if proc.info['name'].lower() == game_name:
                        # Set to high priority (doesn't require admin)
                        proc.nice(psutil.HIGH_PRIORITY_CLASS if sys.platform == 'win32' else -10)
                        self.stats['cpu_priority_changed'] += 1
                        return {'success': True, 'priority': 'HIGH'}
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            return {'success': False, 'reason': 'Game not running'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def optimize_network_nonadmin(self) -> Dict:
        """Optimize network without admin - REAL PING REDUCTION"""
        logger.info("Optimizing network for LOW PING...")
        
        try:
            optimizations = []
            
            # 1. Flush DNS cache
            subprocess.run('ipconfig /flushdns', shell=True, capture_output=True)
            optimizations.append('DNS flushed')
            
            # 2. Release and renew IP (can help with routing)
            subprocess.run('ipconfig /release', shell=True, capture_output=True, timeout=5)
            subprocess.run('ipconfig /renew', shell=True, capture_output=True, timeout=10)
            optimizations.append('IP renewed')
            
            # 3. Clear ARP cache
            subprocess.run('arp -d *', shell=True, capture_output=True)
            optimizations.append('ARP cache cleared')
            
            # 4. Reset Winsock
            subprocess.run('netsh winsock reset', shell=True, capture_output=True)
            optimizations.append('Winsock reset')
            
            # 5. Optimize TCP settings (user-level)
            tcp_tweaks = [
                'netsh int tcp set global autotuninglevel=normal',
                'netsh int tcp set global chimney=enabled',
                'netsh int tcp set global dca=enabled',
                'netsh int tcp set global netdma=enabled',
                'netsh int tcp set global ecncapability=enabled',
                'netsh int tcp set global timestamps=disabled',
            ]
            
            for cmd in tcp_tweaks:
                try:
                    subprocess.run(cmd, shell=True, capture_output=True)
                    optimizations.append(cmd.split()[-1])
                except:
                    pass
            
            # 6. Close bandwidth-heavy processes
            bandwidth_hogs = [
                'chrome.exe', 'firefox.exe', 'msedge.exe',
                'teams.exe', 'slack.exe', 'zoom.exe',
                'onedrive.exe', 'dropbox.exe',
                'utorrent.exe', 'bittorrent.exe',
                'steamwebhelper.exe'  # Steam browser
            ]
            
            closed = []
            for proc in psutil.process_iter(['pid', 'name', 'connections']):
                try:
                    proc_name = proc.info['name'].lower()
                    if proc_name in bandwidth_hogs:
                        # Check if it has active network connections
                        if proc.info['connections']:
                            proc.terminate()
                            closed.append(proc_name)
                            time.sleep(0.1)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            if closed:
                optimizations.append(f'Closed {len(closed)} network apps')
            
            return {
                'success': True,
                'optimizations': optimizations,
                'closed_apps': closed
            }
        except Exception as e:
            logger.error(f"Network optimization error: {e}")
            return {'success': False, 'error': str(e)}
    
    def set_power_mode_nonadmin(self) -> Dict:
        """Set power mode without admin"""
        logger.info("Setting power mode (user-mode)...")
        
        try:
            if sys.platform == 'win32':
                # Try to set power plan (may work without admin)
                subprocess.run(
                    'powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c',
                    shell=True, capture_output=True
                )
                return {'success': True, 'mode': 'High Performance'}
            return {'success': False, 'reason': 'Not Windows'}
        except:
            return {'success': False, 'reason': 'Requires admin'}
    
    def apply_user_tweaks(self) -> Dict:
        """Apply user-level registry tweaks - FPS BOOST"""
        logger.info("Applying FPS BOOST tweaks...")
        
        if sys.platform != 'win32':
            return {'success': False}
        
        try:
            tweaks = []
            
            # User-level registry tweaks (HKEY_CURRENT_USER only)
            user_tweaks = [
                # Disable Game DVR (HUGE FPS boost)
                'reg add "HKCU\\System\\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 0 /f',
                'reg add "HKCU\\System\\GameConfigStore" /v GameDVR_FSEBehaviorMode /t REG_DWORD /d 2 /f',
                'reg add "HKCU\\System\\GameConfigStore" /v GameDVR_HonorUserFSEBehaviorMode /t REG_DWORD /d 1 /f',
                'reg add "HKCU\\System\\GameConfigStore" /v GameDVR_DXGIHonorFSEWindowsCompatible /t REG_DWORD /d 1 /f',
                
                # Disable Game Bar
                'reg add "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\GameDVR" /v AppCaptureEnabled /t REG_DWORD /d 0 /f',
                'reg add "HKCU\\SOFTWARE\\Microsoft\\GameBar" /v ShowStartupPanel /t REG_DWORD /d 0 /f',
                'reg add "HKCU\\SOFTWARE\\Microsoft\\GameBar" /v UseNexusForGameBarEnabled /t REG_DWORD /d 0 /f',
                
                # Mouse acceleration off (better aim)
                'reg add "HKCU\\Control Panel\\Mouse" /v MouseSpeed /t REG_SZ /d 0 /f',
                'reg add "HKCU\\Control Panel\\Mouse" /v MouseThreshold1 /t REG_SZ /d 0 /f',
                'reg add "HKCU\\Control Panel\\Mouse" /v MouseThreshold2 /t REG_SZ /d 0 /f',
                'reg add "HKCU\\Control Panel\\Mouse" /v SmoothMouseXCurve /t REG_BINARY /d 0000000000000000C0CC0C0000000000809919000000000040662600000000000033330000000000 /f',
                'reg add "HKCU\\Control Panel\\Mouse" /v SmoothMouseYCurve /t REG_BINARY /d 0000000000000000000038000000000000007000000000000000A800000000000000E00000000000 /f',
                
                # Disable transparency (FPS boost)
                'reg add "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" /v EnableTransparency /t REG_DWORD /d 0 /f',
                
                # Disable animations (FPS boost)
                'reg add "HKCU\\Control Panel\\Desktop\\WindowMetrics" /v MinAnimate /t REG_SZ /d 0 /f',
                'reg add "HKCU\\Control Panel\\Desktop" /v UserPreferencesMask /t REG_BINARY /d 9012038010000000 /f',
                
                # Disable menu show delay
                'reg add "HKCU\\Control Panel\\Desktop" /v MenuShowDelay /t REG_SZ /d 0 /f',
                
                # Keyboard response
                'reg add "HKCU\\Control Panel\\Keyboard" /v KeyboardDelay /t REG_SZ /d 0 /f',
                'reg add "HKCU\\Control Panel\\Keyboard" /v KeyboardSpeed /t REG_SZ /d 31 /f',
                
                # Disable Aero Shake
                'reg add "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" /v DisallowShaking /t REG_DWORD /d 1 /f',
                
                # Disable Windows animations
                'reg add "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 2 /f',
                
                # Disable Cortana
                'reg add "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Search" /v BingSearchEnabled /t REG_DWORD /d 0 /f',
                'reg add "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Search" /v CortanaConsent /t REG_DWORD /d 0 /f',
            ]
            
            for cmd in user_tweaks:
                try:
                    result = subprocess.run(cmd, shell=True, capture_output=True, timeout=2)
                    if result.returncode == 0:
                        tweaks.append('Applied')
                except:
                    pass
            
            return {'success': True, 'tweaks_applied': len(tweaks)}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def enable_game_mode(self) -> Dict:
        """Enable Windows Game Mode"""
        logger.info("Enabling Game Mode...")
        
        if sys.platform != 'win32':
            return {'success': False}
        
        try:
            # Enable Game Mode (user-level)
            cmd = 'reg add "HKCU\\SOFTWARE\\Microsoft\\GameBar" /v AutoGameModeEnabled /t REG_DWORD /d 1 /f'
            subprocess.run(cmd, shell=True, capture_output=True)
            
            return {'success': True, 'note': 'Windows Game Mode enabled'}
        except:
            return {'success': False}
    
    def disable_visual_effects(self) -> Dict:
        """Disable visual effects for performance"""
        logger.info("Disabling visual effects...")
        
        if sys.platform != 'win32':
            return {'success': False}
        
        try:
            effects = []
            
            # Disable visual effects (user-level)
            visual_tweaks = [
                # Disable animations
                'reg add "HKCU\\Control Panel\\Desktop" /v UserPreferencesMask /t REG_BINARY /d 9012038010000000 /f',
                # Disable window shadows
                'reg add "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 2 /f',
                # Smooth scrolling off
                'reg add "HKCU\\Control Panel\\Desktop" /v SmoothScroll /t REG_DWORD /d 0 /f',
            ]
            
            for cmd in visual_tweaks:
                try:
                    subprocess.run(cmd, shell=True, capture_output=True)
                    effects.append('Applied')
                except:
                    pass
            
            return {'success': True, 'effects_disabled': len(effects)}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def limit_background_apps(self) -> Dict:
        """Limit background apps"""
        logger.info("Limiting background apps...")
        
        if sys.platform != 'win32':
            return {'success': False}
        
        try:
            # Disable background apps (user-level)
            cmd = 'reg add "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\BackgroundAccessApplications" /v GlobalUserDisabled /t REG_DWORD /d 1 /f'
            subprocess.run(cmd, shell=True, capture_output=True)
            
            return {'success': True, 'note': 'Background apps limited'}
        except:
            return {'success': False}
    
    def schedule_defragmentation(self) -> Dict:
        """Schedule disk defragmentation"""
        if sys.platform != "win32":
            return {'success': False, 'reason': 'Only supported on Windows'}
        
        try:
            # Schedule defrag for all drives
            result = subprocess.run(
                'schtasks /create /tn "GameHubDefrag" /tr "defrag /C /V" /sc weekly /d SUN /st 02:00',
                shell=True, capture_output=True, text=True
            )
            
            return {
                'success': result.returncode == 0,
                'scheduled': 'Weekly on Sunday at 2:00 AM'
            }
            
        except Exception as e:
            logger.error(f"Defrag scheduling error: {e}")
            return {'success': False, 'error': str(e)}
