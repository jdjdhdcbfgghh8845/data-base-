"""Game scanning and detection module"""

import os
import sys
import json
import re
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from datetime import datetime
import subprocess
import hashlib

if sys.platform == "win32":
    import winreg

from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class GameScanner:
    """Scan and detect installed games on the system"""
    
    # Common game executable patterns
    GAME_PATTERNS = [
        r'.*\.exe$',
        r'.*launcher.*\.exe$',
        r'.*game.*\.exe$',
    ]
    
    # Exclude these common system/tool executables
    EXCLUDE_PATTERNS = [
        r'unins.*\.exe',
        r'setup.*\.exe',
        r'install.*\.exe',
        r'update.*\.exe',
        r'crash.*\.exe',
        r'bug.*\.exe',
        r'redis.*\.exe',
        r'.*helper.*\.exe',
        r'.*service.*\.exe',
        r'.*daemon.*\.exe',
    ]
    
    # Known game launcher paths
    LAUNCHER_PATHS = {
        'steam': {
            'windows': [
                r'C:\Program Files (x86)\Steam',
                r'C:\Program Files\Steam',
            ],
            'linux': ['~/.steam', '~/.local/share/Steam'],
            'mac': ['~/Library/Application Support/Steam']
        },
        'epic': {
            'windows': [r'C:\Program Files\Epic Games'],
            'linux': [],
            'mac': []
        },
        'gog': {
            'windows': [r'C:\Program Files (x86)\GOG Galaxy', r'C:\Program Files\GOG Galaxy'],
            'linux': [],
            'mac': []
        },
        'origin': {
            'windows': [r'C:\Program Files (x86)\Origin', r'C:\Program Files\Origin'],
            'linux': [],
            'mac': []
        },
        'ubisoft': {
            'windows': [r'C:\Program Files (x86)\Ubisoft', r'C:\Program Files\Ubisoft'],
            'linux': [],
            'mac': []
        },
        'battlenet': {
            'windows': [r'C:\Program Files (x86)\Battle.net', r'C:\Program Files\Battle.net'],
            'linux': [],
            'mac': []
        }
    }
    
    def __init__(self, config=None):
        """Initialize game scanner"""
        self.config = config
        self.detected_games = []
        self.platform = self._get_platform()
        
    def _get_platform(self) -> str:
        """Get current platform"""
        if sys.platform.startswith('win'):
            return 'windows'
        elif sys.platform.startswith('linux'):
            return 'linux'
        elif sys.platform == 'darwin':
            return 'mac'
        return 'unknown'
    
    def scan_all(self) -> List[Dict]:
        """Scan for all games on the system"""
        logger.info("Starting comprehensive game scan...")
        self.detected_games = []
        
        # Scan Steam games
        steam_games = self._scan_steam_games()
        self.detected_games.extend(steam_games)
        
        # Scan Epic Games
        epic_games = self._scan_epic_games()
        self.detected_games.extend(epic_games)
        
        # Scan GOG games
        gog_games = self._scan_gog_games()
        self.detected_games.extend(gog_games)
        
        # Scan custom directories
        if self.config:
            custom_dirs = self.config.get('game_library.scan_directories', [])
            for directory in custom_dirs:
                if os.path.exists(directory):
                    custom_games = self._scan_directory(directory)
                    self.detected_games.extend(custom_games)
        
        # Remove duplicates based on path
        seen_paths = set()
        unique_games = []
        for game in self.detected_games:
            game_hash = hashlib.md5(game['path'].encode()).hexdigest()
            if game_hash not in seen_paths:
                seen_paths.add(game_hash)
                unique_games.append(game)
        
        self.detected_games = unique_games
        logger.info(f"Game scan complete. Found {len(self.detected_games)} games")
        return self.detected_games
    
    def _scan_steam_games(self) -> List[Dict]:
        """Scan for Steam games"""
        games = []
        
        if self.platform != 'windows':
            return games
        
        try:
            # Find Steam installation
            steam_path = self._find_steam_path()
            if not steam_path:
                logger.info("Steam not found")
                return games
            
            # Parse Steam library folders
            library_folders = self._get_steam_library_folders(steam_path)
            
            for library in library_folders:
                common_path = Path(library) / 'steamapps' / 'common'
                if common_path.exists():
                    for game_dir in common_path.iterdir():
                        if game_dir.is_dir():
                            # Look for game executable
                            game_info = self._find_game_executable(game_dir)
                            if game_info:
                                game_info['platform'] = 'Steam'
                                games.append(game_info)
            
            logger.info(f"Found {len(games)} Steam games")
            
        except Exception as e:
            logger.error(f"Error scanning Steam games: {e}")
        
        return games
    
    def _scan_epic_games(self) -> List[Dict]:
        """Scan for Epic Games"""
        games = []
        
        if self.platform != 'windows':
            return games
        
        try:
            epic_paths = self.LAUNCHER_PATHS['epic']['windows']
            for epic_path in epic_paths:
                if os.path.exists(epic_path):
                    path = Path(epic_path)
                    for game_dir in path.iterdir():
                        if game_dir.is_dir():
                            game_info = self._find_game_executable(game_dir)
                            if game_info:
                                game_info['platform'] = 'Epic Games'
                                games.append(game_info)
            
            logger.info(f"Found {len(games)} Epic games")
            
        except Exception as e:
            logger.error(f"Error scanning Epic games: {e}")
        
        return games
    
    def _scan_gog_games(self) -> List[Dict]:
        """Scan for GOG games"""
        games = []
        
        if self.platform != 'windows':
            return games
        
        try:
            # Check registry for GOG games
            key_path = r"SOFTWARE\WOW6432Node\GOG.com\Games"
            try:
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path)
                for i in range(winreg.QueryInfoKey(key)[0]):
                    subkey_name = winreg.EnumKey(key, i)
                    subkey = winreg.OpenKey(key, subkey_name)
                    
                    try:
                        game_name = winreg.QueryValueEx(subkey, "GAMENAME")[0]
                        game_path = winreg.QueryValueEx(subkey, "PATH")[0]
                        exe_path = winreg.QueryValueEx(subkey, "EXE")[0]
                        
                        if os.path.exists(game_path):
                            games.append({
                                'name': game_name,
                                'path': game_path,
                                'executable': os.path.join(game_path, exe_path) if exe_path else None,
                                'platform': 'GOG',
                                'description': '',
                                'cover_image': None
                            })
                    except WindowsError:
                        pass
                    finally:
                        winreg.CloseKey(subkey)
                
                winreg.CloseKey(key)
                
            except WindowsError:
                logger.info("GOG registry key not found")
            
            logger.info(f"Found {len(games)} GOG games")
            
        except Exception as e:
            logger.error(f"Error scanning GOG games: {e}")
        
        return games
    
    def _scan_directory(self, directory: str) -> List[Dict]:
        """Scan a specific directory for games"""
        games = []
        
        try:
            path = Path(directory)
            if not path.exists():
                return games
            
            # Look for game directories
            for item in path.iterdir():
                if item.is_dir():
                    game_info = self._find_game_executable(item)
                    if game_info:
                        game_info['platform'] = 'Local'
                        games.append(game_info)
            
        except Exception as e:
            logger.error(f"Error scanning directory {directory}: {e}")
        
        return games
    
    def _find_game_executable(self, game_dir: Path) -> Optional[Dict]:
        """Find the main game executable in a directory"""
        executables = []
        
        # Find all executables
        for exe_path in game_dir.glob('**/*.exe'):
            exe_name = exe_path.name.lower()
            
            # Check if it matches exclude patterns
            if any(re.match(pattern, exe_name) for pattern in self.EXCLUDE_PATTERNS):
                continue
            
            # Score the executable based on likelihood of being the main game exe
            score = 0
            
            # Higher score for root directory
            if exe_path.parent == game_dir:
                score += 10
            
            # Higher score for game-like names
            if 'game' in exe_name or game_dir.name.lower() in exe_name:
                score += 5
            
            # Lower score for subdirectories
            depth = len(exe_path.relative_to(game_dir).parts) - 1
            score -= depth * 2
            
            executables.append((exe_path, score))
        
        if not executables:
            return None
        
        # Sort by score and get the best match
        executables.sort(key=lambda x: x[1], reverse=True)
        best_exe = executables[0][0]
        
        return {
            'name': self._clean_game_name(game_dir.name),
            'path': str(game_dir),
            'executable': str(best_exe),
            'platform': 'Unknown',
            'description': '',
            'cover_image': self._find_cover_image(game_dir)
        }
    
    def _find_steam_path(self) -> Optional[str]:
        """Find Steam installation path"""
        if self.platform != 'windows':
            return None
        
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam")
            steam_path = winreg.QueryValueEx(key, "InstallPath")[0]
            winreg.CloseKey(key)
            return steam_path
        except WindowsError:
            # Try alternative locations
            for path in self.LAUNCHER_PATHS['steam']['windows']:
                if os.path.exists(path):
                    return path
        
        return None
    
    def _get_steam_library_folders(self, steam_path: str) -> List[str]:
        """Get all Steam library folders"""
        libraries = [steam_path]
        
        try:
            # Parse libraryfolders.vdf
            vdf_path = Path(steam_path) / 'steamapps' / 'libraryfolders.vdf'
            if vdf_path.exists():
                with open(vdf_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    # Simple regex to find paths
                    paths = re.findall(r'"path"\s+"([^"]+)"', content)
                    libraries.extend(paths)
        except Exception as e:
            logger.error(f"Error parsing Steam library folders: {e}")
        
        return libraries
    
    def _clean_game_name(self, name: str) -> str:
        """Clean up game name"""
        # Remove common suffixes
        name = re.sub(r'[_-]', ' ', name)
        name = re.sub(r'\s+', ' ', name)
        name = name.strip()
        
        # Title case
        return name.title()
    
    def _find_cover_image(self, game_dir: Path) -> Optional[str]:
        """Find cover image for the game"""
        image_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.ico']
        image_names = ['cover', 'icon', 'logo', 'banner', 'header']
        
        # Look for common image names
        for name in image_names:
            for ext in image_extensions:
                image_path = game_dir / f"{name}{ext}"
                if image_path.exists():
                    return str(image_path)
        
        # Look for any image in root
        for ext in image_extensions:
            images = list(game_dir.glob(f"*{ext}"))
            if images:
                return str(images[0])
        
        return None
    
    def add_game_manually(self, name: str, path: str, executable: str) -> Dict:
        """Manually add a game"""
        game_info = {
            'name': name,
            'path': path,
            'executable': executable,
            'platform': 'Manual',
            'description': '',
            'cover_image': self._find_cover_image(Path(path)) if os.path.exists(path) else None
        }
        
        self.detected_games.append(game_info)
        logger.info(f"Manually added game: {name}")
        
        return game_info
