"""Achievements and rewards system"""

import json
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timedelta
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class AchievementSystem:
    """Manage achievements, points, and rewards"""
    
    # Achievement definitions
    ACHIEVEMENTS = {
        # General achievements
        'first_launch': {
            'name': 'Welcome to GameHub!',
            'description': 'Launch GameHub OS for the first time',
            'points': 10,
            'category': 'general',
            'icon': '🎮',
            'requirement': {'type': 'launch_count', 'value': 1}
        },
        'daily_user': {
            'name': 'Daily Gamer',
            'description': 'Use GameHub OS for 7 consecutive days',
            'points': 25,
            'category': 'general',
            'icon': '📅',
            'requirement': {'type': 'consecutive_days', 'value': 7}
        },
        
        # Gaming achievements
        'game_collector_10': {
            'name': 'Game Collector',
            'description': 'Add 10 games to your library',
            'points': 20,
            'category': 'gaming',
            'icon': '📚',
            'requirement': {'type': 'games_count', 'value': 10}
        },
        'game_collector_50': {
            'name': 'Game Hoarder',
            'description': 'Add 50 games to your library',
            'points': 50,
            'category': 'gaming',
            'icon': '🏆',
            'requirement': {'type': 'games_count', 'value': 50}
        },
        'marathon_10': {
            'name': 'Gaming Session',
            'description': 'Play games for a total of 10 hours',
            'points': 15,
            'category': 'gaming',
            'icon': '⏱️',
            'requirement': {'type': 'playtime_hours', 'value': 10}
        },
        'marathon_100': {
            'name': 'Marathon Gamer',
            'description': 'Play games for a total of 100 hours',
            'points': 100,
            'category': 'gaming',
            'icon': '🎯',
            'requirement': {'type': 'playtime_hours', 'value': 100}
        },
        'high_fps': {
            'name': 'Smooth Operator',
            'description': 'Achieve average 60+ FPS in 5 gaming sessions',
            'points': 30,
            'category': 'gaming',
            'icon': '🚀',
            'requirement': {'type': 'high_fps_sessions', 'value': 5}
        },
        
        # Optimization achievements
        'optimizer_first': {
            'name': 'System Optimizer',
            'description': 'Run system optimization for the first time',
            'points': 15,
            'category': 'optimization',
            'icon': '⚡',
            'requirement': {'type': 'optimization_count', 'value': 1}
        },
        'optimizer_pro': {
            'name': 'Optimization Pro',
            'description': 'Run system optimization 25 times',
            'points': 40,
            'category': 'optimization',
            'icon': '💪',
            'requirement': {'type': 'optimization_count', 'value': 25}
        },
        'ram_cleaner': {
            'name': 'Memory Master',
            'description': 'Free up 5GB of RAM total',
            'points': 35,
            'category': 'optimization',
            'icon': '🧹',
            'requirement': {'type': 'ram_freed_gb', 'value': 5}
        },
        
        # Social achievements
        'first_message': {
            'name': 'Hello World!',
            'description': 'Send your first message in global chat',
            'points': 10,
            'category': 'social',
            'icon': '💬',
            'requirement': {'type': 'messages_sent', 'value': 1}
        },
        'social_butterfly': {
            'name': 'Social Butterfly',
            'description': 'Send 100 messages in global chat',
            'points': 30,
            'category': 'social',
            'icon': '🦋',
            'requirement': {'type': 'messages_sent', 'value': 100}
        },
        'chat_addict': {
            'name': 'Chat Master',
            'description': 'Send 500 messages in global chat',
            'points': 60,
            'category': 'social',
            'icon': '👑',
            'requirement': {'type': 'messages_sent', 'value': 500}
        },
        
        # Customization achievements
        'theme_changer': {
            'name': 'Style Master',
            'description': 'Change theme 5 times',
            'points': 15,
            'category': 'customization',
            'icon': '🎨',
            'requirement': {'type': 'theme_changes', 'value': 5}
        },
        'shortcut_master': {
            'name': 'Keyboard Ninja',
            'description': 'Use keyboard shortcuts 50 times',
            'points': 25,
            'category': 'customization',
            'icon': '⌨️',
            'requirement': {'type': 'shortcuts_used', 'value': 50}
        }
    }
    
    # Rewards that can be unlocked with points
    REWARDS = {
        'speed_boost': {
            'name': 'Speed Boost',
            'description': '2x faster optimization process',
            'cost': 50,
            'type': 'optimization',
            'icon': '⚡'
        },
        'theme_pack_neon': {
            'name': 'Neon Theme Pack',
            'description': 'Unlock 5 neon themes',
            'cost': 30,
            'type': 'theme',
            'icon': '🌈'
        },
        'theme_pack_minimal': {
            'name': 'Minimal Theme Pack',
            'description': 'Unlock 5 minimalist themes',
            'cost': 30,
            'type': 'theme',
            'icon': '⬜'
        },
        'ui_effects': {
            'name': 'UI Effects Pack',
            'description': 'Unlock advanced UI animations and effects',
            'cost': 40,
            'type': 'ui',
            'icon': '✨'
        },
        'auto_optimizer': {
            'name': 'Auto Optimizer',
            'description': 'Automatically optimize when launching games',
            'cost': 60,
            'type': 'optimization',
            'icon': '🤖'
        },
        'priority_boost': {
            'name': 'Priority Boost',
            'description': 'Enhanced CPU priority management',
            'cost': 45,
            'type': 'optimization',
            'icon': '🚀'
        },
        'chat_emojis': {
            'name': 'Premium Emojis',
            'description': 'Unlock 50+ premium emojis for chat',
            'cost': 20,
            'type': 'social',
            'icon': '😎'
        },
        'profile_badge_gold': {
            'name': 'Gold Badge',
            'description': 'Display a gold badge in chat',
            'cost': 100,
            'type': 'social',
            'icon': '🥇'
        }
    }
    
    # Level progression
    LEVELS = {
        1: {'required_xp': 0, 'title': 'Novice Gamer'},
        2: {'required_xp': 100, 'title': 'Casual Gamer'},
        3: {'required_xp': 250, 'title': 'Regular Gamer'},
        4: {'required_xp': 500, 'title': 'Dedicated Gamer'},
        5: {'required_xp': 1000, 'title': 'Hardcore Gamer'},
        6: {'required_xp': 2000, 'title': 'Pro Gamer'},
        7: {'required_xp': 3500, 'title': 'Elite Gamer'},
        8: {'required_xp': 5000, 'title': 'Master Gamer'},
        9: {'required_xp': 7500, 'title': 'Legendary Gamer'},
        10: {'required_xp': 10000, 'title': 'GameHub Champion'}
    }
    
    def __init__(self, db_manager):
        """Initialize achievement system"""
        self.db_manager = db_manager
        self.unlocked_rewards = []
        self.active_bonuses = {}
        
    def check_achievement(self, achievement_id: str, current_value: float) -> Tuple[bool, Optional[Dict]]:
        """Check if an achievement has been unlocked"""
        if achievement_id not in self.ACHIEVEMENTS:
            return False, None
        
        achievement = self.ACHIEVEMENTS[achievement_id]
        requirement = achievement['requirement']
        
        # Check if already unlocked
        if self._is_achievement_unlocked(achievement_id):
            return False, None
        
        # Check if requirement is met
        if current_value >= requirement['value']:
            # Unlock achievement
            self._unlock_achievement(achievement_id)
            return True, achievement
        
        return False, None
    
    def check_all_achievements(self, stats: Dict) -> List[Dict]:
        """Check all achievements against current stats"""
        unlocked = []
        
        # Map stats to achievement requirements
        checks = {
            'launch_count': ['first_launch'],
            'consecutive_days': ['daily_user'],
            'games_count': ['game_collector_10', 'game_collector_50'],
            'playtime_hours': ['marathon_10', 'marathon_100'],
            'high_fps_sessions': ['high_fps'],
            'optimization_count': ['optimizer_first', 'optimizer_pro'],
            'ram_freed_gb': ['ram_cleaner'],
            'messages_sent': ['first_message', 'social_butterfly', 'chat_addict'],
            'theme_changes': ['theme_changer'],
            'shortcuts_used': ['shortcut_master']
        }
        
        for stat_type, achievement_ids in checks.items():
            if stat_type in stats:
                for achievement_id in achievement_ids:
                    is_unlocked, achievement = self.check_achievement(
                        achievement_id, 
                        stats[stat_type]
                    )
                    if is_unlocked:
                        unlocked.append(achievement)
        
        return unlocked
    
    def _is_achievement_unlocked(self, achievement_id: str) -> bool:
        """Check if achievement is already unlocked"""
        try:
            from src.core.database import Achievement, UserAchievement
            
            session = self.db_manager.get_session()
            
            achievement = session.query(Achievement).filter_by(
                name=achievement_id
            ).first()
            
            if not achievement:
                return False
            
            user_achievement = session.query(UserAchievement).filter_by(
                achievement_id=achievement.id
            ).first()
            
            session.close()
            
            return user_achievement is not None
            
        except Exception as e:
            logger.error(f"Error checking achievement status: {e}")
            return False
    
    def _unlock_achievement(self, achievement_id: str):
        """Unlock an achievement and award points"""
        try:
            from src.core.database import Achievement, UserAchievement, UserStats
            
            session = self.db_manager.get_session()
            
            # Get or create achievement record
            achievement = session.query(Achievement).filter_by(
                name=achievement_id
            ).first()
            
            if not achievement:
                achievement_data = self.ACHIEVEMENTS[achievement_id]
                achievement = Achievement(
                    name=achievement_id,
                    description=achievement_data['description'],
                    icon=achievement_data['icon'],
                    points=achievement_data['points'],
                    category=achievement_data['category'],
                    requirement=json.dumps(achievement_data['requirement'])
                )
                session.add(achievement)
                session.flush()
            
            # Create user achievement record
            user_achievement = UserAchievement(
                achievement_id=achievement.id,
                progress=100.0
            )
            session.add(user_achievement)
            
            # Update user stats
            user_stats = session.query(UserStats).first()
            if user_stats:
                user_stats.total_points += achievement.points
                user_stats.achievements_unlocked += 1
                user_stats.experience += achievement.points * 10
                
                # Check for level up
                self._check_level_up(user_stats)
            
            session.commit()
            session.close()
            
            logger.info(f"Achievement unlocked: {achievement_id}")
            
        except Exception as e:
            logger.error(f"Error unlocking achievement: {e}")
    
    def _check_level_up(self, user_stats):
        """Check if user has leveled up"""
        current_level = user_stats.current_level
        current_xp = user_stats.experience
        
        # Find new level
        new_level = current_level
        for level, data in self.LEVELS.items():
            if current_xp >= data['required_xp']:
                new_level = level
            else:
                break
        
        if new_level > current_level:
            user_stats.current_level = new_level
            logger.info(f"Level up! Now level {new_level}: {self.LEVELS[new_level]['title']}")
    
    def purchase_reward(self, reward_id: str) -> Tuple[bool, str]:
        """Purchase a reward with points"""
        if reward_id not in self.REWARDS:
            return False, "Invalid reward"
        
        reward = self.REWARDS[reward_id]
        
        try:
            from src.core.database import UserStats
            
            session = self.db_manager.get_session()
            user_stats = session.query(UserStats).first()
            
            if not user_stats:
                session.close()
                return False, "User stats not found"
            
            # Check if enough points
            if user_stats.total_points < reward['cost']:
                session.close()
                return False, f"Not enough points. Need {reward['cost']}, have {user_stats.total_points}"
            
            # Deduct points
            user_stats.total_points -= reward['cost']
            session.commit()
            session.close()
            
            # Activate reward
            self._activate_reward(reward_id)
            
            return True, f"Successfully purchased {reward['name']}"
            
        except Exception as e:
            logger.error(f"Error purchasing reward: {e}")
            return False, str(e)
    
    def _activate_reward(self, reward_id: str):
        """Activate a purchased reward"""
        if reward_id not in self.unlocked_rewards:
            self.unlocked_rewards.append(reward_id)
        
        reward = self.REWARDS[reward_id]
        
        # Apply reward effects
        if reward['type'] == 'optimization':
            self.active_bonuses[reward_id] = {
                'type': reward['type'],
                'effect': reward_id,
                'activated_at': datetime.now()
            }
        
        logger.info(f"Reward activated: {reward['name']}")
    
    def get_user_stats(self) -> Dict:
        """Get current user statistics"""
        try:
            from src.core.database import UserStats, UserAchievement
            
            session = self.db_manager.get_session()
            
            user_stats = session.query(UserStats).first()
            if not user_stats:
                return {}
            
            achievement_count = session.query(UserAchievement).count()
            
            stats = {
                'level': user_stats.current_level,
                'level_title': self.LEVELS[user_stats.current_level]['title'],
                'experience': user_stats.experience,
                'next_level_xp': self._get_next_level_xp(user_stats.current_level),
                'total_points': user_stats.total_points,
                'achievements_unlocked': achievement_count,
                'total_achievements': len(self.ACHIEVEMENTS),
                'total_playtime': user_stats.total_playtime,
                'games_played': user_stats.games_played,
                'optimizations_run': user_stats.optimizations_run
            }
            
            session.close()
            return stats
            
        except Exception as e:
            logger.error(f"Error getting user stats: {e}")
            return {}
    
    def _get_next_level_xp(self, current_level: int) -> int:
        """Get XP required for next level"""
        next_level = current_level + 1
        if next_level in self.LEVELS:
            return self.LEVELS[next_level]['required_xp']
        return 999999  # Max level reached
    
    def get_achievements_list(self) -> List[Dict]:
        """Get list of all achievements with unlock status"""
        achievements = []
        
        for aid, data in self.ACHIEVEMENTS.items():
            achievement = {
                'id': aid,
                'name': data['name'],
                'description': data['description'],
                'points': data['points'],
                'category': data['category'],
                'icon': data['icon'],
                'unlocked': self._is_achievement_unlocked(aid),
                'progress': self._get_achievement_progress(aid)
            }
            achievements.append(achievement)
        
        return achievements
    
    def _get_achievement_progress(self, achievement_id: str) -> float:
        """Get progress towards an achievement"""
        # This would need to be implemented based on actual tracking
        # For now, return 0 if not unlocked
        if self._is_achievement_unlocked(achievement_id):
            return 100.0
        return 0.0
    
    def get_available_rewards(self) -> List[Dict]:
        """Get list of available rewards"""
        rewards = []
        
        for rid, data in self.REWARDS.items():
            reward = {
                'id': rid,
                'name': data['name'],
                'description': data['description'],
                'cost': data['cost'],
                'type': data['type'],
                'icon': data['icon'],
                'unlocked': rid in self.unlocked_rewards
            }
            rewards.append(reward)
        
        return rewards
    
    def has_bonus(self, bonus_type: str) -> bool:
        """Check if a specific bonus is active"""
        for bonus_id, bonus in self.active_bonuses.items():
            if bonus['effect'] == bonus_type:
                return True
        return False
