"""Logging configuration for GameHub OS"""

import logging
import sys
from pathlib import Path
from datetime import datetime
import colorlog


def setup_logger(name: str = None) -> logging.Logger:
    """Setup and configure logger with colors and file output"""
    
    # Create logs directory
    log_dir = Path.home() / '.gamehub_os' / 'logs'
    log_dir.mkdir(parents=True, exist_ok=True)
    
    # Log file with date
    log_file = log_dir / f"gamehub_{datetime.now().strftime('%Y%m%d')}.log"
    
    # Get or create logger
    logger = logging.getLogger(name or 'GameHubOS')
    
    # Only configure if not already configured
    if not logger.handlers:
        logger.setLevel(logging.DEBUG)
        
        # Console handler with colors
        console_handler = colorlog.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        
        console_format = colorlog.ColoredFormatter(
            '%(log_color)s%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%H:%M:%S',
            log_colors={
                'DEBUG': 'cyan',
                'INFO': 'green',
                'WARNING': 'yellow',
                'ERROR': 'red',
                'CRITICAL': 'red,bg_white',
            }
        )
        console_handler.setFormatter(console_format)
        
        # File handler
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        
        file_format = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_format)
        
        # Add handlers
        logger.addHandler(console_handler)
        logger.addHandler(file_handler)
        
        # Prevent propagation to root logger
        logger.propagate = False
    
    return logger


def get_log_file() -> Path:
    """Get current log file path"""
    log_dir = Path.home() / '.gamehub_os' / 'logs'
    return log_dir / f"gamehub_{datetime.now().strftime('%Y%m%d')}.log"


def clean_old_logs(days: int = 30):
    """Clean log files older than specified days"""
    log_dir = Path.home() / '.gamehub_os' / 'logs'
    if not log_dir.exists():
        return
    
    cutoff_date = datetime.now().timestamp() - (days * 24 * 60 * 60)
    
    for log_file in log_dir.glob('gamehub_*.log'):
        if log_file.stat().st_mtime < cutoff_date:
            try:
                log_file.unlink()
            except:
                pass
