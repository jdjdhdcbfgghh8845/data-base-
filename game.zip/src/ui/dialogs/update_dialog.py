"""Update dialog for showing available updates"""

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QTextEdit, QProgressBar, QGroupBox, QCheckBox
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtGui import QFont, QPixmap
from typing import Dict, Optional
from src.core.updater import AutoUpdater
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class UpdateThread(QThread):
    """Thread for downloading and installing updates"""
    
    progress = pyqtSignal(int)
    status = pyqtSignal(str)
    finished_update = pyqtSignal(bool)
    
    def __init__(self, updater: AutoUpdater):
        super().__init__()
        self.updater = updater
        
    def run(self):
        """Run update process"""
        try:
            self.status.emit("Checking for updates...")
            has_update, new_version, update_info = self.updater.check_for_updates()
            
            if not has_update:
                self.status.emit("No updates available")
                self.finished_update.emit(False)
                return
            
            self.status.emit(f"Downloading version {new_version}...")
            self.progress.emit(20)
            
            update_file = self.updater.download_update(update_info or {})
            if not update_file:
                self.status.emit("Download failed")
                self.finished_update.emit(False)
                return
            
            self.progress.emit(60)
            self.status.emit("Creating backup...")
            
            self.updater.backup_current_version()
            self.progress.emit(80)
            
            self.status.emit("Installing update...")
            success = self.updater.install_update(update_file, new_version)
            
            self.progress.emit(100)
            
            if success:
                self.status.emit("Update installed successfully!")
            else:
                self.status.emit("Installation failed")
                
            self.finished_update.emit(success)
            
        except Exception as e:
            logger.error(f"Update thread error: {e}")
            self.status.emit(f"Error: {str(e)}")
            self.finished_update.emit(False)


class UpdateDialog(QDialog):
    """Dialog for managing application updates"""
    
    restart_requested = pyqtSignal()
    
    def __init__(self, parent=None, auto_check: bool = False):
        super().__init__(parent)
        self.updater = AutoUpdater()
        self.update_info = None
        self.new_version = None
        self.auto_check = auto_check
        self.setup_ui()
        
        if auto_check:
            QTimer.singleShot(100, self.check_updates)
    
    def setup_ui(self):
        """Setup update dialog UI"""
        self.setWindowTitle("🔄 GameHub OS Update")
        self.setFixedSize(600, 500)
        self.setModal(True)
        
        # Main layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Header
        header_layout = QHBoxLayout()
        
        # Icon
        icon_label = QLabel("🔄")
        icon_label.setStyleSheet("""
            QLabel {
                font-size: 48px;
                color: #00897B;
            }
        """)
        header_layout.addWidget(icon_label)
        
        # Title and version
        title_layout = QVBoxLayout()
        
        self.title_label = QLabel("Update Center")
        self.title_label.setStyleSheet("""
            QLabel {
                color: #ffffff;
                font-size: 20px;
                font-weight: bold;
            }
        """)
        title_layout.addWidget(self.title_label)
        
        self.version_label = QLabel(f"Current version: {self.updater.current_version}")
        self.version_label.setStyleSheet("""
            QLabel {
                color: #b0b0b0;
                font-size: 14px;
            }
        """)
        title_layout.addWidget(self.version_label)
        
        header_layout.addLayout(title_layout)
        header_layout.addStretch()
        
        layout.addLayout(header_layout)
        
        # Update info group
        info_group = QGroupBox("Update Information")
        info_group.setStyleSheet("""
            QGroupBox {
                color: #ffffff;
                font-size: 14px;
                font-weight: bold;
                border: 1px solid #333333;
                border-radius: 10px;
                margin-top: 10px;
                padding-top: 10px;
            }
        """)
        
        info_layout = QVBoxLayout(info_group)
        
        self.update_status_label = QLabel("Click 'Check for Updates' to begin")
        self.update_status_label.setStyleSheet("""
            QLabel {
                color: #b0b0b0;
                font-size: 13px;
                font-weight: normal;
            }
        """)
        info_layout.addWidget(self.update_status_label)
        
        self.new_version_label = QLabel("")
        self.new_version_label.setStyleSheet("""
            QLabel {
                color: #00897B;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        info_layout.addWidget(self.new_version_label)
        
        layout.addWidget(info_group)
        
        # Changelog
        changelog_group = QGroupBox("Changelog")
        changelog_group.setStyleSheet("""
            QGroupBox {
                color: #ffffff;
                font-size: 14px;
                font-weight: bold;
                border: 1px solid #333333;
                border-radius: 10px;
                margin-top: 10px;
                padding-top: 10px;
            }
        """)
        
        changelog_layout = QVBoxLayout(changelog_group)
        
        self.changelog_text = QTextEdit()
        self.changelog_text.setReadOnly(True)
        self.changelog_text.setMaximumHeight(150)
        self.changelog_text.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e;
                color: #b0b0b0;
                border: none;
                font-size: 12px;
            }
        """)
        self.changelog_text.setPlainText("No updates checked yet")
        changelog_layout.addWidget(self.changelog_text)
        
        layout.addWidget(changelog_group)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background-color: #333333;
                border: none;
                border-radius: 5px;
                text-align: center;
                color: white;
                height: 25px;
            }
            QProgressBar::chunk {
                background-color: #00897B;
                border-radius: 5px;
            }
        """)
        layout.addWidget(self.progress_bar)
        
        # Status message
        self.status_message = QLabel("")
        self.status_message.setStyleSheet("""
            QLabel {
                color: #b0b0b0;
                font-size: 12px;
            }
        """)
        layout.addWidget(self.status_message)
        
        # Settings
        settings_layout = QHBoxLayout()
        
        self.auto_check_checkbox = QCheckBox("Automatically check for updates on startup")
        self.auto_check_checkbox.setStyleSheet("""
            QCheckBox {
                color: #b0b0b0;
                font-size: 12px;
            }
        """)
        settings_layout.addWidget(self.auto_check_checkbox)
        
        settings_layout.addStretch()
        layout.addLayout(settings_layout)
        
        layout.addStretch()
        
        # Buttons
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        
        self.check_button = QPushButton("🔍 Check for Updates")
        self.check_button.clicked.connect(self.check_updates)
        self.check_button.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 10px 20px;
                font-weight: bold;
                min-width: 150px;
            }
            QPushButton:hover {
                background-color: #42A5F5;
            }
            QPushButton:disabled {
                background-color: #555555;
                color: #888888;
            }
        """)
        button_layout.addWidget(self.check_button)
        
        self.install_button = QPushButton("📥 Install Update")
        self.install_button.clicked.connect(self.install_update)
        self.install_button.setEnabled(False)
        self.install_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 10px 20px;
                font-weight: bold;
                min-width: 150px;
            }
            QPushButton:hover:enabled {
                background-color: #66BB6A;
            }
            QPushButton:disabled {
                background-color: #555555;
                color: #888888;
            }
        """)
        button_layout.addWidget(self.install_button)
        
        self.close_button = QPushButton("Close")
        self.close_button.clicked.connect(self.close)
        self.close_button.setStyleSheet("""
            QPushButton {
                background-color: #555555;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 10px 20px;
                font-weight: bold;
                min-width: 100px;
            }
            QPushButton:hover {
                background-color: #666666;
            }
        """)
        button_layout.addWidget(self.close_button)
        
        layout.addLayout(button_layout)
        
        # Apply dark theme
        self.setStyleSheet("""
            QDialog {
                background-color: #2a2a2a;
            }
        """)
    
    def check_updates(self):
        """Check for available updates"""
        self.check_button.setEnabled(False)
        self.install_button.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)  # Indeterminate
        
        self.status_message.setText("Checking for updates...")
        
        # Check updates
        has_update, new_version, update_info = self.updater.check_for_updates()
        
        self.progress_bar.setVisible(False)
        self.check_button.setEnabled(True)
        
        if has_update:
            self.new_version = new_version
            self.update_info = update_info
            
            self.update_status_label.setText("🎉 A new update is available!")
            self.new_version_label.setText(f"New version: {new_version}")
            
            # Show changelog
            changelog = self.updater.get_changelog(update_info or {})
            self.changelog_text.setPlainText(changelog)
            
            self.install_button.setEnabled(True)
            self.status_message.setText("Ready to install update")
            
            # Show notification if auto-checking
            if self.auto_check:
                from PyQt6.QtWidgets import QMessageBox
                reply = QMessageBox.question(
                    self,
                    "Update Available",
                    f"Version {new_version} is available!\n\nWould you like to install it now?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                )
                if reply == QMessageBox.StandardButton.Yes:
                    self.install_update()
        else:
            self.update_status_label.setText("✓ You have the latest version")
            self.new_version_label.setText("")
            self.changelog_text.setPlainText("No updates available at this time.")
            self.status_message.setText("Application is up to date")
            
            if self.auto_check:
                # Auto close if no updates
                QTimer.singleShot(2000, self.accept)
    
    def install_update(self):
        """Install the available update"""
        self.check_button.setEnabled(False)
        self.install_button.setEnabled(False)
        self.close_button.setEnabled(False)
        
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        
        # Create update thread
        self.update_thread = UpdateThread(self.updater)
        self.update_thread.progress.connect(self.progress_bar.setValue)
        self.update_thread.status.connect(self.status_message.setText)
        self.update_thread.finished_update.connect(self.on_update_finished)
        self.update_thread.start()
    
    def on_update_finished(self, success: bool):
        """Handle update completion"""
        self.close_button.setEnabled(True)
        
        if success:
            from PyQt6.QtWidgets import QMessageBox
            
            reply = QMessageBox.question(
                self,
                "Update Complete",
                "Update installed successfully!\n\nThe application needs to restart to apply changes.\n\nRestart now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            
            if reply == QMessageBox.StandardButton.Yes:
                self.restart_requested.emit()
                self.updater.restart_application()
            else:
                self.accept()
        else:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.critical(
                self,
                "Update Failed",
                "Failed to install update.\n\nPlease try again later or download manually from GitHub."
            )
            self.check_button.setEnabled(True)
    
    def get_auto_check_enabled(self) -> bool:
        """Get auto-check setting"""
        return self.auto_check_checkbox.isChecked()
