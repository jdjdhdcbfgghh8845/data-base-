"""Sidebar navigation widget"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QPushButton, QLabel, QFrame,
    QGraphicsDropShadowEffect
)
from PyQt6.QtCore import Qt, pyqtSignal, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import QIcon, QPixmap, QPainter, QBrush, QColor, QFont


class SidebarButton(QPushButton):
    """Custom sidebar button with hover effects"""
    
    def __init__(self, text: str, icon_path: str = None, parent=None):
        super().__init__(text, parent)
        self.setObjectName("sidebar_button")
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        
        # Set size
        self.setMinimumHeight(50)
        self.setMaximumHeight(50)
        
        # Style - MODERN DESIGN
        self.setStyleSheet("""
            QPushButton#sidebar_button {
                background-color: transparent;
                color: #b0b0b0;
                text-align: left;
                padding: 15px 25px;
                border: none;
                border-left: 3px solid transparent;
                font-size: 15px;
                font-weight: 600;
                border-radius: 0px;
            }
            
            QPushButton#sidebar_button:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 rgba(0, 212, 255, 0.15), stop:1 transparent);
                color: #00d4ff;
                border-left: 3px solid rgba(0, 212, 255, 0.5);
            }
            
            QPushButton#sidebar_button:checked {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 rgba(0, 212, 255, 0.25), stop:1 transparent);
                color: #00d4ff;
                border-left: 3px solid #00d4ff;
                font-weight: bold;
            }
        """)


class Sidebar(QWidget):
    """Application sidebar for navigation"""
    
    # Signal emitted when page changes
    page_changed = pyqtSignal(int)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_index = 0
        self.setup_ui()
        
    def setup_ui(self):
        """Setup sidebar UI"""
        self.setObjectName("sidebar")
        self.setFixedWidth(250)
        
        # Main layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Logo/Title section - MODERN DESIGN
        logo_widget = QWidget()
        logo_widget.setFixedHeight(100)
        logo_widget.setStyleSheet("""
            QWidget {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #0f3460, stop:1 #16213e);
                border-bottom: 3px solid #00d4ff;
            }
        """)
        
        logo_layout = QVBoxLayout(logo_widget)
        logo_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo_layout.setContentsMargins(10, 15, 10, 15)
        
        # Title
        title = QLabel("🎮 GameHub OS")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("""
            QLabel {
                color: #00d4ff;
                font-size: 26px;
                font-weight: bold;
                padding: 5px;
            }
        """)
        logo_layout.addWidget(title)
        
        # Subtitle
        subtitle = QLabel("Ultimate Gaming Platform")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet("""
            QLabel {
                color: #90caf9;
                font-size: 11px;
                font-weight: 500;
            }
        """)
        logo_layout.addWidget(subtitle)
        
        layout.addWidget(logo_widget)
        
        # Navigation buttons
        self.nav_buttons = []
        
        # Create navigation items
        nav_items = [
            ("🎮 Game Library", 0),
            ("⚡ Optimization", 1),
            ("⚙️ Settings", 2),
            ("🏆 Achievements", 3),
            ("💬 Global Chat", 4)
        ]
        
        for text, index in nav_items:
            button = SidebarButton(text)
            button.clicked.connect(lambda checked, idx=index: self.change_page(idx))
            self.nav_buttons.append(button)
            layout.addWidget(button)
        
        # Set first button as active
        self.nav_buttons[0].setChecked(True)
        
        # Spacer
        layout.addStretch()
        
        # User profile section - MODERN DESIGN
        profile_widget = QWidget()
        profile_widget.setFixedHeight(90)
        profile_widget.setStyleSheet("""
            QWidget {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #16213e, stop:1 #0f3460);
                border-top: 3px solid #00d4ff;
            }
        """)
        
        profile_layout = QVBoxLayout(profile_widget)
        profile_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        profile_layout.setContentsMargins(10, 10, 10, 10)
        
        # User info
        self.user_label = QLabel("⭐ Level 1: Novice")
        self.user_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.user_label.setStyleSheet("""
            QLabel {
                color: #90caf9;
                font-size: 13px;
                font-weight: 600;
            }
        """)
        
        self.points_label = QLabel("🪙 0 Points")
        self.points_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.points_label.setStyleSheet("""
            QLabel {
                color: #ffd700;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        
        profile_layout.addWidget(self.user_label)
        profile_layout.addWidget(self.points_label)
        
        layout.addWidget(profile_widget)
        
        # Apply sidebar style - MODERN DESIGN
        self.setStyleSheet("""
            #sidebar {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #16213e, stop:1 #1a1a2e);
                border-right: 3px solid rgba(0, 212, 255, 0.3);
            }
        """)
        
        # Add shadow effect
        self.add_shadow()
        
    def add_shadow(self):
        """Add shadow effect to sidebar"""
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setXOffset(2)
        shadow.setYOffset(0)
        shadow.setColor(QColor(0, 0, 0, 80))
        self.setGraphicsEffect(shadow)
        
    def change_page(self, index: int):
        """Change the current page"""
        if index == self.current_index:
            return
            
        # Update button states
        for i, button in enumerate(self.nav_buttons):
            button.setChecked(i == index)
        
        self.current_index = index
        self.page_changed.emit(index)
        
    def update_user_info(self, level: int, level_title: str, points: int):
        """Update user information display"""
        self.user_label.setText(f"Level {level}: {level_title}")
        self.points_label.setText(f"🪙 {points} Points")
