"""Sidebar navigation widget"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QPushButton, QLabel, QFrame,
    QGraphicsDropShadowEffect
)
from PyQt6.QtCore import Qt, pyqtSignal, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import QIcon, QPixmap, QPainter, QBrush, QColor, QFont


class SidebarButton(QPushButton):
    """Custom sidebar button with hover effects"""
    
    def __init__(self, text: str, icon_path: str = None, parent=None):
        super().__init__(text, parent)
        self.setObjectName("sidebar_button")
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        
        # Set size
        self.setMinimumHeight(50)
        self.setMaximumHeight(50)
        
        # Style - STEAM DESIGN
        self.setStyleSheet("""
            QPushButton#sidebar_button {
                background-color: transparent;
                color: #8f98a0;
                text-align: left;
                padding: 12px 20px;
                border: none;
                border-left: 3px solid transparent;
                font-size: 14px;
                font-weight: 400;
                border-radius: 0px;
            }
            
            QPushButton#sidebar_button:hover {
                background-color: #2a475e;
                color: #c7d5e0;
                border-left: 3px solid #1a9fff;
            }
            
            QPushButton#sidebar_button:checked {
                background-color: #1a9fff;
                color: #ffffff;
                border-left: 3px solid #66c0f4;
                font-weight: 500;
            }
        """)


class Sidebar(QWidget):
    """Application sidebar for navigation"""
    
    # Signal emitted when page changes
    page_changed = pyqtSignal(int)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_index = 0
        self.setup_ui()
        
    def setup_ui(self):
        """Setup sidebar UI"""
        self.setObjectName("sidebar")
        self.setFixedWidth(250)
        
        # Main layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Logo/Title section - STEAM DESIGN
        logo_widget = QWidget()
        logo_widget.setFixedHeight(100)
        logo_widget.setStyleSheet("""
            QWidget {
                background-color: #171a21;
                border-bottom: 1px solid #000000;
            }
        """)
        
        logo_layout = QVBoxLayout(logo_widget)
        logo_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo_layout.setContentsMargins(10, 15, 10, 15)
        
        # Title
        title = QLabel("🎮 GameHub OS")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("""
            QLabel {
                color: #c7d5e0;
                font-size: 24px;
                font-weight: 600;
                padding: 5px;
            }
        """)
        logo_layout.addWidget(title)
        
        # Subtitle
        subtitle = QLabel("Ultimate Gaming Platform")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet("""
            QLabel {
                color: #66c0f4;
                font-size: 11px;
                font-weight: 400;
            }
        """)
        logo_layout.addWidget(subtitle)
        
        layout.addWidget(logo_widget)
        
        # Navigation buttons
        self.nav_buttons = []
        
        # Create navigation items
        nav_items = [
            ("🎮 Game Library", 0),
            ("⚡ Optimization", 1),
            ("⚙️ Settings", 2),
            ("🏆 Achievements", 3),
            ("💬 Global Chat", 4)
        ]
        
        for text, index in nav_items:
            button = SidebarButton(text)
            button.clicked.connect(lambda checked, idx=index: self.change_page(idx))
            self.nav_buttons.append(button)
            layout.addWidget(button)
        
        # Set first button as active
        self.nav_buttons[0].setChecked(True)
        
        # Spacer
        layout.addStretch()
        
        # User profile section - STEAM DESIGN
        profile_widget = QWidget()
        profile_widget.setFixedHeight(90)
        profile_widget.setStyleSheet("""
            QWidget {
                background-color: #171a21;
                border-top: 1px solid #000000;
            }
        """)
        
        profile_layout = QVBoxLayout(profile_widget)
        profile_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        profile_layout.setContentsMargins(10, 10, 10, 10)
        
        # User info
        self.user_label = QLabel("⭐ Level 1: Novice")
        self.user_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.user_label.setStyleSheet("""
            QLabel {
                color: #66c0f4;
                font-size: 12px;
                font-weight: 500;
            }
        """)
        
        self.points_label = QLabel("🪙 0 Points")
        self.points_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.points_label.setStyleSheet("""
            QLabel {
                color: #b8b6b4;
                font-size: 15px;
                font-weight: 600;
            }
        """)
        
        profile_layout.addWidget(self.user_label)
        profile_layout.addWidget(self.points_label)
        
        layout.addWidget(profile_widget)
        
        # Apply sidebar style - STEAM DESIGN
        self.setStyleSheet("""
            #sidebar {
                background-color: #171a21;
                border-right: 1px solid #000000;
            }
        """)
        
        # Add shadow effect
        self.add_shadow()
        
    def add_shadow(self):
        """Add shadow effect to sidebar"""
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setXOffset(2)
        shadow.setYOffset(0)
        shadow.setColor(QColor(0, 0, 0, 80))
        self.setGraphicsEffect(shadow)
        
    def change_page(self, index: int):
        """Change the current page"""
        if index == self.current_index:
            return
            
        # Update button states
        for i, button in enumerate(self.nav_buttons):
            button.setChecked(i == index)
        
        self.current_index = index
        self.page_changed.emit(index)
        
    def update_user_info(self, level: int, level_title: str, points: int):
        """Update user information display"""
        self.user_label.setText(f"Level {level}: {level_title}")
        self.points_label.setText(f"🪙 {points} Points")
