"""Header bar widget"""

from PyQt6.QtWidgets import (
    QWidget, QHBoxLayout, QPushButton, QLabel, QLineEdit,
    QGraphicsDropShadowEffect
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtGui import QIcon, QColor
from datetime import datetime


class HeaderBar(QWidget):
    """Custom header bar with controls and info"""
    
    # Signals
    minimize_clicked = pyqtSignal()
    maximize_clicked = pyqtSignal()
    close_clicked = pyqtSignal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        self.start_clock()
        
    def setup_ui(self):
        """Setup header UI"""
        self.setObjectName("header_bar")
        self.setFixedHeight(50)
        
        # Main layout
        layout = QHBoxLayout(self)
        layout.setContentsMargins(15, 0, 15, 0)
        layout.setSpacing(15)
        
        # Search bar
        self.search_bar = QLineEdit()
        self.search_bar.setPlaceholderText("🔍 Search games, settings, achievements...")
        self.search_bar.setMaximumWidth(400)
        self.search_bar.setStyleSheet("""
            QLineEdit {
                background-color: #316282;
                border: 1px solid #000000;
                border-radius: 2px;
                padding: 6px 12px;
                color: #c7d5e0;
                font-size: 13px;
            }
            
            QLineEdit:focus {
                background-color: #3d6e8f;
                border: 1px solid #1a9fff;
            }
        """)
        layout.addWidget(self.search_bar)
        
        # Spacer
        layout.addStretch()
        
        # System info
        self.fps_label = QLabel("FPS: --")
        self.fps_label.setStyleSheet("""
            QLabel {
                color: #5c7e10;
                font-size: 11px;
                font-weight: 500;
            }
        """)
        layout.addWidget(self.fps_label)
        
        # Network status
        self.network_label = QLabel("🌐 Online")
        self.network_label.setStyleSheet("""
            QLabel {
                color: #5c7e10;
                font-size: 11px;
            }
        """)
        layout.addWidget(self.network_label)
        
        # Clock
        self.clock_label = QLabel()
        self.clock_label.setStyleSheet("""
            QLabel {
                color: #8f98a0;
                font-size: 12px;
            }
        """)
        layout.addWidget(self.clock_label)
        
        # Window controls
        controls_widget = QWidget()
        controls_layout = QHBoxLayout(controls_widget)
        controls_layout.setContentsMargins(0, 0, 0, 0)
        controls_layout.setSpacing(10)
        
        # Minimize button
        self.min_button = QPushButton("─")
        self.min_button.setObjectName("window_button")
        self.min_button.clicked.connect(self.minimize_clicked.emit)
        self.min_button.setFixedSize(30, 30)
        
        # Maximize button
        self.max_button = QPushButton("□")
        self.max_button.setObjectName("window_button")
        self.max_button.clicked.connect(self.maximize_clicked.emit)
        self.max_button.setFixedSize(30, 30)
        
        # Close button
        self.close_button = QPushButton("✕")
        self.close_button.setObjectName("close_button")
        self.close_button.clicked.connect(self.close_clicked.emit)
        self.close_button.setFixedSize(30, 30)
        
        controls_layout.addWidget(self.min_button)
        controls_layout.addWidget(self.max_button)
        controls_layout.addWidget(self.close_button)
        
        layout.addWidget(controls_widget)
        
        # Apply styles - STEAM DESIGN
        self.setStyleSheet("""
            #header_bar {
                background-color: #171a21;
                border-bottom: 1px solid #000000;
            }
            
            QPushButton#window_button {
                background-color: transparent;
                color: #8f98a0;
                border: none;
                border-radius: 0px;
                font-size: 14px;
                font-weight: 500;
            }
            
            QPushButton#window_button:hover {
                background-color: #2a475e;
                color: #c7d5e0;
            }
            
            QPushButton#close_button {
                background-color: transparent;
                color: #8f98a0;
                border: none;
                border-radius: 0px;
                font-size: 14px;
                font-weight: 500;
            }
            
            QPushButton#close_button:hover {
                background-color: #8b0000;
                color: #ffffff;
            }
        """)
        
    def start_clock(self):
        """Start clock timer"""
        self.clock_timer = QTimer()
        self.clock_timer.timeout.connect(self.update_clock)
        self.clock_timer.start(1000)
        self.update_clock()
        
    def update_clock(self):
        """Update clock display"""
        current_time = datetime.now().strftime("%H:%M:%S")
        self.clock_label.setText(current_time)
        
    def update_fps(self, fps: int):
        """Update FPS display"""
        if fps > 0:
            color = "#5c7e10" if fps >= 60 else "#c7a008" if fps >= 30 else "#8b0000"
            self.fps_label.setText(f"FPS: {fps}")
            self.fps_label.setStyleSheet(f"""
                QLabel {{
                    color: {color};
                    font-size: 11px;
                    font-weight: 500;
                }}
            """)
        else:
            self.fps_label.setText("FPS: --")
            
    def update_network_status(self, is_online: bool):
        """Update network status display"""
        if is_online:
            self.network_label.setText("🌐 Online")
            self.network_label.setStyleSheet("""
                QLabel {
                    color: #5c7e10;
                    font-size: 11px;
                }
            """)
        else:
            self.network_label.setText("🌐 Offline")
            self.network_label.setStyleSheet("""
                QLabel {
                    color: #8b0000;
                    font-size: 11px;
                }
            """)
