"""Header bar widget"""

from PyQt6.QtWidgets import (
    QWidget, QHBoxLayout, QPushButton, QLabel, QLineEdit,
    QGraphicsDropShadowEffect
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtGui import QIcon, QColor
from datetime import datetime


class HeaderBar(QWidget):
    """Custom header bar with controls and info"""
    
    # Signals
    minimize_clicked = pyqtSignal()
    maximize_clicked = pyqtSignal()
    close_clicked = pyqtSignal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        self.start_clock()
        
    def setup_ui(self):
        """Setup header UI"""
        self.setObjectName("header_bar")
        self.setFixedHeight(60)
        
        # Main layout
        layout = QHBoxLayout(self)
        layout.setContentsMargins(20, 0, 20, 0)
        layout.setSpacing(20)
        
        # Search bar
        self.search_bar = QLineEdit()
        self.search_bar.setPlaceholderText("🔍 Search games, settings, achievements...")
        self.search_bar.setMaximumWidth(400)
        self.search_bar.setStyleSheet("""
            QLineEdit {
                background-color: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 20px;
                padding: 8px 15px;
                color: #ffffff;
                font-size: 13px;
            }
            
            QLineEdit:focus {
                background-color: rgba(255, 255, 255, 0.08);
                border: 1px solid #00897B;
            }
        """)
        layout.addWidget(self.search_bar)
        
        # Spacer
        layout.addStretch()
        
        # System info
        self.fps_label = QLabel("FPS: --")
        self.fps_label.setStyleSheet("""
            QLabel {
                color: #00FF00;
                font-size: 12px;
                font-weight: bold;
            }
        """)
        layout.addWidget(self.fps_label)
        
        # Network status
        self.network_label = QLabel("🌐 Online")
        self.network_label.setStyleSheet("""
            QLabel {
                color: #00FF00;
                font-size: 12px;
            }
        """)
        layout.addWidget(self.network_label)
        
        # Clock
        self.clock_label = QLabel()
        self.clock_label.setStyleSheet("""
            QLabel {
                color: #b0b0b0;
                font-size: 13px;
            }
        """)
        layout.addWidget(self.clock_label)
        
        # Window controls
        controls_widget = QWidget()
        controls_layout = QHBoxLayout(controls_widget)
        controls_layout.setContentsMargins(0, 0, 0, 0)
        controls_layout.setSpacing(10)
        
        # Minimize button
        self.min_button = QPushButton("─")
        self.min_button.setObjectName("window_button")
        self.min_button.clicked.connect(self.minimize_clicked.emit)
        self.min_button.setFixedSize(30, 30)
        
        # Maximize button
        self.max_button = QPushButton("□")
        self.max_button.setObjectName("window_button")
        self.max_button.clicked.connect(self.maximize_clicked.emit)
        self.max_button.setFixedSize(30, 30)
        
        # Close button
        self.close_button = QPushButton("✕")
        self.close_button.setObjectName("close_button")
        self.close_button.clicked.connect(self.close_clicked.emit)
        self.close_button.setFixedSize(30, 30)
        
        controls_layout.addWidget(self.min_button)
        controls_layout.addWidget(self.max_button)
        controls_layout.addWidget(self.close_button)
        
        layout.addWidget(controls_widget)
        
        # Apply styles
        self.setStyleSheet("""
            #header_bar {
                background-color: #1e1e1e;
                border-bottom: 1px solid #333333;
            }
            
            QPushButton#window_button {
                background-color: transparent;
                color: #b0b0b0;
                border: none;
                border-radius: 15px;
                font-size: 16px;
                font-weight: bold;
            }
            
            QPushButton#window_button:hover {
                background-color: rgba(255, 255, 255, 0.1);
                color: #ffffff;
            }
            
            QPushButton#close_button {
                background-color: transparent;
                color: #b0b0b0;
                border: none;
                border-radius: 15px;
                font-size: 16px;
                font-weight: bold;
            }
            
            QPushButton#close_button:hover {
                background-color: #FF5252;
                color: #ffffff;
            }
        """)
        
    def start_clock(self):
        """Start clock timer"""
        self.clock_timer = QTimer()
        self.clock_timer.timeout.connect(self.update_clock)
        self.clock_timer.start(1000)
        self.update_clock()
        
    def update_clock(self):
        """Update clock display"""
        current_time = datetime.now().strftime("%H:%M:%S")
        self.clock_label.setText(current_time)
        
    def update_fps(self, fps: int):
        """Update FPS display"""
        if fps > 0:
            color = "#00FF00" if fps >= 60 else "#FFFF00" if fps >= 30 else "#FF0000"
            self.fps_label.setText(f"FPS: {fps}")
            self.fps_label.setStyleSheet(f"""
                QLabel {{
                    color: {color};
                    font-size: 12px;
                    font-weight: bold;
                }}
            """)
        else:
            self.fps_label.setText("FPS: --")
            
    def update_network_status(self, is_online: bool):
        """Update network status display"""
        if is_online:
            self.network_label.setText("🌐 Online")
            self.network_label.setStyleSheet("""
                QLabel {
                    color: #00FF00;
                    font-size: 12px;
                }
            """)
        else:
            self.network_label.setText("🌐 Offline")
            self.network_label.setStyleSheet("""
                QLabel {
                    color: #FF0000;
                    font-size: 12px;
                }
            """)
