"""
Steam-inspired theme stylesheet for GameHub OS
Color palette based on Steam's design language
"""

# Steam Color Palette
STEAM_COLORS = {
    # Primary backgrounds
    'bg_dark': '#171a21',           # Darkest background (header, sidebar)
    'bg_medium': '#1b2838',         # Medium background (main content)
    'bg_light': '#16202d',          # Light background (cards)
    'bg_input': '#316282',          # Input fields background
    'bg_hover': '#2a475e',          # Hover state background
    
    # Accent colors
    'accent_blue': '#1a9fff',       # Primary accent (Steam blue)
    'accent_blue_light': '#66c0f4', # Light blue accent
    'accent_green': '#5c7e10',      # Action buttons (Steam green)
    'accent_green_hover': '#6fa313',# Green hover state
    
    # Text colors
    'text_primary': '#c7d5e0',      # Primary text
    'text_secondary': '#8f98a0',    # Secondary text
    'text_white': '#ffffff',        # Pure white text
    'text_green': '#d2efa9',        # Green button text
    
    # UI elements
    'border_dark': '#000000',       # Dark borders
    'scrollbar': '#3d4450',         # Scrollbar color
    'error_red': '#8b0000',         # Error/close button
}


def get_steam_stylesheet():
    """Returns the complete Steam-inspired stylesheet"""
    return f"""
    /* ============================================
       STEAM THEME STYLESHEET FOR GAMEHUB OS
       ============================================ */
    
    /* Main Window */
    QMainWindow {{
        background-color: {STEAM_COLORS['bg_medium']};
    }}
    
    /* Generic Widgets */
    QWidget {{
        background-color: transparent;
        color: {STEAM_COLORS['text_primary']};
    }}
    
    /* Labels */
    QLabel {{
        color: {STEAM_COLORS['text_primary']};
        font-size: 13px;
    }}
    
    /* Buttons - Steam Green Style */
    QPushButton {{
        background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 {STEAM_COLORS['accent_green']}, stop:1 #4e6b0f);
        color: {STEAM_COLORS['text_green']};
        border: 1px solid rgba(0, 0, 0, 0.4);
        border-radius: 2px;
        padding: 8px 16px;
        font-weight: 500;
        font-size: 13px;
    }}
    
    QPushButton:hover {{
        background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 {STEAM_COLORS['accent_green_hover']}, stop:1 #5c8711);
        color: #e4f7c5;
    }}
    
    QPushButton:pressed {{
        background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 #4e6b0f, stop:1 #3f5a0c);
        color: #c5e28f;
    }}
    
    QPushButton:disabled {{
        background-color: #2a3f5f;
        color: #4c5866;
        border: 1px solid #1a2332;
    }}
    
    /* Input Fields */
    QLineEdit, QTextEdit, QPlainTextEdit {{
        background-color: {STEAM_COLORS['bg_input']};
        border: 1px solid {STEAM_COLORS['border_dark']};
        border-radius: 2px;
        padding: 8px;
        color: {STEAM_COLORS['text_primary']};
        font-size: 13px;
        selection-background-color: {STEAM_COLORS['accent_blue']};
    }}
    
    QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {{
        border: 1px solid {STEAM_COLORS['accent_blue']};
        background-color: #3d6e8f;
    }}
    
    /* ComboBox */
    QComboBox {{
        background-color: {STEAM_COLORS['bg_input']};
        border: 1px solid {STEAM_COLORS['border_dark']};
        border-radius: 2px;
        padding: 8px;
        color: {STEAM_COLORS['text_primary']};
        font-size: 13px;
    }}
    
    QComboBox:focus {{
        border: 1px solid {STEAM_COLORS['accent_blue']};
        background-color: #3d6e8f;
    }}
    
    QComboBox::drop-down {{
        border: none;
        background-color: {STEAM_COLORS['bg_hover']};
        width: 20px;
    }}
    
    QComboBox::down-arrow {{
        image: none;
        border-left: 4px solid transparent;
        border-right: 4px solid transparent;
        border-top: 5px solid {STEAM_COLORS['text_secondary']};
        margin-right: 5px;
    }}
    
    QComboBox QAbstractItemView {{
        background-color: {STEAM_COLORS['bg_medium']};
        color: {STEAM_COLORS['text_primary']};
        border: 1px solid {STEAM_COLORS['border_dark']};
        selection-background-color: {STEAM_COLORS['accent_blue']};
    }}
    
    /* Scrollbars */
    QScrollBar:vertical {{
        background-color: {STEAM_COLORS['bg_medium']};
        width: 14px;
        margin: 0;
        border: none;
    }}
    
    QScrollBar::handle:vertical {{
        background-color: {STEAM_COLORS['scrollbar']};
        border-radius: 0px;
        min-height: 30px;
    }}
    
    QScrollBar::handle:vertical:hover {{
        background-color: #4c5866;
    }}
    
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
        height: 0px;
    }}
    
    QScrollBar:horizontal {{
        background-color: {STEAM_COLORS['bg_medium']};
        height: 14px;
        border: none;
    }}
    
    QScrollBar::handle:horizontal {{
        background-color: {STEAM_COLORS['scrollbar']};
        border-radius: 0px;
        min-width: 30px;
    }}
    
    QScrollBar::handle:horizontal:hover {{
        background-color: #4c5866;
    }}
    
    /* Progress Bar */
    QProgressBar {{
        background-color: {STEAM_COLORS['bg_hover']};
        border: 1px solid {STEAM_COLORS['border_dark']};
        border-radius: 2px;
        text-align: center;
        color: {STEAM_COLORS['text_primary']};
        font-weight: 500;
        height: 18px;
    }}
    
    QProgressBar::chunk {{
        background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 {STEAM_COLORS['accent_green']}, stop:1 #4e6b0f);
        border-radius: 1px;
    }}
    
    /* Menu Bar */
    QMenuBar {{
        background-color: {STEAM_COLORS['bg_dark']};
        color: {STEAM_COLORS['text_primary']};
        border-bottom: 1px solid {STEAM_COLORS['border_dark']};
        padding: 2px;
    }}
    
    QMenuBar::item {{
        background-color: transparent;
        padding: 4px 12px;
    }}
    
    QMenuBar::item:selected {{
        background-color: {STEAM_COLORS['accent_blue']};
    }}
    
    /* Menu */
    QMenu {{
        background-color: {STEAM_COLORS['bg_medium']};
        color: {STEAM_COLORS['text_primary']};
        border: 1px solid {STEAM_COLORS['border_dark']};
    }}
    
    QMenu::item {{
        padding: 6px 24px;
    }}
    
    QMenu::item:selected {{
        background-color: {STEAM_COLORS['accent_blue']};
    }}
    
    /* Tooltips */
    QToolTip {{
        background-color: {STEAM_COLORS['bg_medium']};
        color: {STEAM_COLORS['text_primary']};
        border: 1px solid {STEAM_COLORS['border_dark']};
        border-radius: 2px;
        padding: 6px;
        font-size: 12px;
    }}
    
    /* Group Box */
    QGroupBox {{
        border: 1px solid {STEAM_COLORS['bg_hover']};
        border-radius: 2px;
        margin-top: 10px;
        padding-top: 10px;
        font-weight: 500;
        color: {STEAM_COLORS['text_primary']};
    }}
    
    QGroupBox::title {{
        subcontrol-origin: margin;
        subcontrol-position: top left;
        padding: 0 5px;
        color: {STEAM_COLORS['accent_blue_light']};
    }}
    
    /* Check Box */
    QCheckBox {{
        color: {STEAM_COLORS['text_primary']};
        spacing: 8px;
    }}
    
    QCheckBox::indicator {{
        width: 18px;
        height: 18px;
        border: 1px solid {STEAM_COLORS['border_dark']};
        background-color: {STEAM_COLORS['bg_input']};
        border-radius: 2px;
    }}
    
    QCheckBox::indicator:checked {{
        background-color: {STEAM_COLORS['accent_green']};
        border: 1px solid {STEAM_COLORS['accent_green']};
    }}
    
    QCheckBox::indicator:hover {{
        border: 1px solid {STEAM_COLORS['accent_blue']};
    }}
    
    /* Radio Button */
    QRadioButton {{
        color: {STEAM_COLORS['text_primary']};
        spacing: 8px;
    }}
    
    QRadioButton::indicator {{
        width: 18px;
        height: 18px;
        border: 1px solid {STEAM_COLORS['border_dark']};
        background-color: {STEAM_COLORS['bg_input']};
        border-radius: 9px;
    }}
    
    QRadioButton::indicator:checked {{
        background-color: {STEAM_COLORS['accent_green']};
        border: 1px solid {STEAM_COLORS['accent_green']};
    }}
    
    /* Tab Widget */
    QTabWidget::pane {{
        border: 1px solid {STEAM_COLORS['border_dark']};
        background-color: {STEAM_COLORS['bg_medium']};
    }}
    
    QTabBar::tab {{
        background-color: {STEAM_COLORS['bg_dark']};
        color: {STEAM_COLORS['text_secondary']};
        padding: 8px 16px;
        border: 1px solid {STEAM_COLORS['border_dark']};
        border-bottom: none;
    }}
    
    QTabBar::tab:selected {{
        background-color: {STEAM_COLORS['bg_medium']};
        color: {STEAM_COLORS['text_primary']};
    }}
    
    QTabBar::tab:hover {{
        background-color: {STEAM_COLORS['bg_hover']};
        color: {STEAM_COLORS['text_primary']};
    }}
    
    /* Slider */
    QSlider::groove:horizontal {{
        background: {STEAM_COLORS['bg_hover']};
        height: 6px;
        border-radius: 3px;
    }}
    
    QSlider::handle:horizontal {{
        background: {STEAM_COLORS['accent_blue']};
        width: 16px;
        height: 16px;
        margin: -5px 0;
        border-radius: 8px;
    }}
    
    QSlider::handle:horizontal:hover {{
        background: {STEAM_COLORS['accent_blue_light']};
    }}
    
    /* Spin Box */
    QSpinBox, QDoubleSpinBox {{
        background-color: {STEAM_COLORS['bg_input']};
        border: 1px solid {STEAM_COLORS['border_dark']};
        border-radius: 2px;
        padding: 6px;
        color: {STEAM_COLORS['text_primary']};
    }}
    
    QSpinBox:focus, QDoubleSpinBox:focus {{
        border: 1px solid {STEAM_COLORS['accent_blue']};
    }}
    
    /* List Widget */
    QListWidget {{
        background-color: {STEAM_COLORS['bg_medium']};
        border: 1px solid {STEAM_COLORS['border_dark']};
        color: {STEAM_COLORS['text_primary']};
    }}
    
    QListWidget::item:selected {{
        background-color: {STEAM_COLORS['accent_blue']};
    }}
    
    QListWidget::item:hover {{
        background-color: {STEAM_COLORS['bg_hover']};
    }}
    
    /* Table Widget */
    QTableWidget {{
        background-color: {STEAM_COLORS['bg_medium']};
        border: 1px solid {STEAM_COLORS['border_dark']};
        color: {STEAM_COLORS['text_primary']};
        gridline-color: {STEAM_COLORS['bg_hover']};
    }}
    
    QTableWidget::item:selected {{
        background-color: {STEAM_COLORS['accent_blue']};
    }}
    
    QHeaderView::section {{
        background-color: {STEAM_COLORS['bg_dark']};
        color: {STEAM_COLORS['text_primary']};
        padding: 6px;
        border: 1px solid {STEAM_COLORS['border_dark']};
        font-weight: 500;
    }}
    
    /* Dialog Buttons */
    QDialogButtonBox QPushButton {{
        min-width: 80px;
    }}
    """


def get_steam_colors():
    """Returns the Steam color palette dictionary"""
    return STEAM_COLORS.copy()
