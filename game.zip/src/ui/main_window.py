"""Main window UI for GameHub OS"""

import sys
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QStackedWidget,
    QPushButton, QLabel, QFrame, QSystemTrayIcon, QMenu, QMessageBox,
    QApplication, QGraphicsDropShadowEffect, QMenuBar
)
from PyQt6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, pyqtSignal, QSize
from PyQt6.QtGui import QIcon, QAction, QPixmap, QColor, QFont

from src.ui.pages.library_page import LibraryPage
from src.ui.pages.optimization_page import OptimizationPage
from src.ui.pages.settings_page import SettingsPage
from src.ui.pages.achievements_page import AchievementsPage
from src.ui.pages.chat_page import ChatPage
from src.ui.widgets.sidebar import Sidebar
from src.ui.widgets.header import HeaderBar
from src.core.game_scanner import GameScanner
from src.core.optimizer import SystemOptimizer
from src.core.achievements import AchievementSystem
from src.core.telegram_chat import TelegramChat
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class MainWindow(QMainWindow):
    """Main application window"""
    
    # Signals
    achievement_unlocked = pyqtSignal(dict)
    optimization_complete = pyqtSignal(dict)
    
    def __init__(self, config, db_manager):
        super().__init__()
        self.config = config
        self.db_manager = db_manager
        
        # Initialize components
        self.game_scanner = GameScanner(config)
        self.optimizer = SystemOptimizer(config)
        self.achievement_system = AchievementSystem(db_manager)
        self.telegram_chat = TelegramChat(config, db_manager)
        
        # Setup UI
        self.setup_ui()
        self.setup_menu_bar()
        self.setup_system_tray()
        self.apply_theme()
        
        # Start background services
        self.start_services()
        
    def setup_ui(self):
        """Setup the main UI"""
        self.setWindowTitle("GameHub OS")
        self.setMinimumSize(1200, 700)
        self.resize(1400, 800)
        
        # Set window flags for modern look
        self.setWindowFlags(
            Qt.WindowType.Window |
            Qt.WindowType.CustomizeWindowHint |
            Qt.WindowType.WindowTitleHint |
            Qt.WindowType.WindowCloseButtonHint |
            Qt.WindowType.WindowMinimizeButtonHint |
            Qt.WindowType.WindowMaximizeButtonHint
        )
        
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # Header bar
        self.header = HeaderBar(self)
        main_layout.addWidget(self.header)
        
        # Content area with sidebar
        content_widget = QWidget()
        content_layout = QHBoxLayout(content_widget)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)
        
        # Sidebar
        self.sidebar = Sidebar(self)
        self.sidebar.page_changed.connect(self.change_page)
        content_layout.addWidget(self.sidebar)
        
        # Page stack
        self.page_stack = QStackedWidget()
        self.page_stack.setObjectName("page_stack")
        
        # Create pages
        self.library_page = LibraryPage(self.game_scanner, self.db_manager, self)
        self.optimization_page = OptimizationPage(self.optimizer, self.config, self)
        self.settings_page = SettingsPage(self.config, self)
        self.achievements_page = AchievementsPage(self.achievement_system, self)
        self.chat_page = ChatPage(self.telegram_chat, self.config, self)
        
        # Add pages to stack
        self.page_stack.addWidget(self.library_page)
        self.page_stack.addWidget(self.optimization_page)
        self.page_stack.addWidget(self.settings_page)
        self.page_stack.addWidget(self.achievements_page)
        self.page_stack.addWidget(self.chat_page)
        
        content_layout.addWidget(self.page_stack)
        main_layout.addWidget(content_widget)
        
        # Status bar
        self.setup_status_bar()
        
    def setup_menu_bar(self):
        """Setup menu bar"""
        menubar = self.menuBar()
        menubar.setStyleSheet("""
            QMenuBar {
                background-color: #1e1e1e;
                color: #ffffff;
            }
            QMenuBar::item:selected {
                background-color: #00897B;
            }
            QMenu {
                background-color: #2a2a2a;
                color: #ffffff;
            }
            QMenu::item:selected {
                background-color: #00897B;
            }
        """)
        
        # File menu
        file_menu = menubar.addMenu('&File')
        
        settings_action = QAction('⚙️ Settings', self)
        settings_action.setShortcut('Ctrl+,')
        settings_action.triggered.connect(lambda: self.sidebar.change_page(2))
        file_menu.addAction(settings_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction('Exit', self)
        exit_action.setShortcut('Ctrl+Q')
        exit_action.triggered.connect(self.quit_application)
        file_menu.addAction(exit_action)
        
        # Tools menu
        tools_menu = menubar.addMenu('&Tools')
        
        optimize_action = QAction('⚡ Quick Optimize', self)
        optimize_action.setShortcut('Ctrl+O')
        optimize_action.triggered.connect(self.quick_optimize)
        tools_menu.addAction(optimize_action)
        
        scan_action = QAction('🔄 Scan for Games', self)
        scan_action.setShortcut('Ctrl+S')
        scan_action.triggered.connect(self.library_page.scan_for_games)
        tools_menu.addAction(scan_action)
        
        # Help menu
        help_menu = menubar.addMenu('&Help')
        
        update_action = QAction('🔄 Check for Updates', self)
        update_action.triggered.connect(self.check_for_updates)
        help_menu.addAction(update_action)
        
        help_menu.addSeparator()
        
        about_action = QAction('About GameHub OS', self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
        
    def setup_status_bar(self):
        """Setup status bar"""
        status = self.statusBar()
        status.setObjectName("status_bar")
        
        # System info labels
        self.cpu_label = QLabel("CPU: 0%")
        self.ram_label = QLabel("RAM: 0%")
        self.games_label = QLabel("Games: 0")
        self.points_label = QLabel("Points: 0")
        
        status.addWidget(self.cpu_label)
        status.addWidget(self.ram_label)
        status.addWidget(self.games_label)
        status.addPermanentWidget(self.points_label)
        
        # Update timer
        self.status_timer = QTimer()
        self.status_timer.timeout.connect(self.update_status)
        self.status_timer.start(2000)  # Update every 2 seconds
        
    def setup_system_tray(self):
        """Setup system tray icon"""
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
            
        self.tray_icon = QSystemTrayIcon(self)
        
        # Create tray menu
        tray_menu = QMenu()
        
        show_action = QAction("Show", self)
        show_action.triggered.connect(self.show)
        tray_menu.addAction(show_action)
        
        optimize_action = QAction("Quick Optimize", self)
        optimize_action.triggered.connect(self.quick_optimize)
        tray_menu.addAction(optimize_action)
        
        tray_menu.addSeparator()
        
        quit_action = QAction("Exit", self)
        quit_action.triggered.connect(self.quit_application)
        tray_menu.addAction(quit_action)
        
        self.tray_icon.setContextMenu(tray_menu)
        
        # Set icon (you'll need to add an icon file)
        # self.tray_icon.setIcon(QIcon("assets/icon.png"))
        self.tray_icon.setToolTip("GameHub OS")
        
        # Show tray icon
        self.tray_icon.show()
        
        # Connect double-click to show window
        self.tray_icon.activated.connect(self.tray_icon_activated)
        
    def tray_icon_activated(self, reason):
        """Handle tray icon activation"""
        if reason == QSystemTrayIcon.ActivationReason.DoubleClick:
            self.show()
            self.raise_()
            self.activateWindow()
            
    def change_page(self, index: int):
        """Change the current page"""
        self.page_stack.setCurrentIndex(index)
        logger.info(f"Changed to page {index}")
        
    def update_status(self):
        """Update status bar information"""
        try:
            # Get system info
            import psutil
            cpu_percent = psutil.cpu_percent(interval=0)
            ram_percent = psutil.virtual_memory().percent
            
            self.cpu_label.setText(f"CPU: {cpu_percent:.1f}%")
            self.ram_label.setText(f"RAM: {ram_percent:.1f}%")
            
            # Get game count
            from src.core.database import Game
            session = self.db_manager.get_session()
            game_count = session.query(Game).count()
            session.close()
            self.games_label.setText(f"Games: {game_count}")
            
            # Get user points
            stats = self.achievement_system.get_user_stats()
            points = stats.get('total_points', 0)
            self.points_label.setText(f"Points: {points}")
            
        except Exception as e:
            logger.error(f"Error updating status: {e}")
            
    def quick_optimize(self):
        """Perform quick optimization"""
        logger.info("Starting quick optimization...")
        
        # Run optimization
        result = self.optimizer.optimize_for_gaming()
        
        # Show notification
        if result['success']:
            stats = result['stats']
            message = f"Optimization Complete!\n" \
                     f"RAM Freed: {stats['ram_freed']:.0f} MB\n" \
                     f"Processes Closed: {stats['processes_closed']}\n" \
                     f"Services Stopped: {stats['services_stopped']}"
            
            self.tray_icon.showMessage(
                "GameHub OS",
                message,
                QSystemTrayIcon.MessageIcon.Information,
                3000
            )
            
            # Check for achievements
            self.check_optimization_achievements(stats)
            
    def check_optimization_achievements(self, stats):
        """Check for optimization-related achievements"""
        # Update user stats
        from src.core.database import UserStats
        session = self.db_manager.get_session()
        
        user_stats = session.query(UserStats).first()
        if user_stats:
            user_stats.optimizations_run += 1
            session.commit()
            
            # Check achievements
            achievement_stats = {
                'optimization_count': user_stats.optimizations_run,
                'ram_freed_gb': stats.get('ram_freed', 0) / 1024
            }
            
            unlocked = self.achievement_system.check_all_achievements(achievement_stats)
            
            for achievement in unlocked:
                self.show_achievement_notification(achievement)
                
        session.close()
        
    def show_achievement_notification(self, achievement: dict):
        """Show achievement unlocked notification"""
        title = f"{achievement['icon']} Achievement Unlocked!"
        message = f"{achievement['name']}\n{achievement['description']}\n+{achievement['points']} points"
        
        if self.tray_icon:
            self.tray_icon.showMessage(
                title,
                message,
                QSystemTrayIcon.MessageIcon.Information,
                5000
            )
            
        # Emit signal for UI update
        self.achievement_unlocked.emit(achievement)
        
    def check_for_updates(self):
        """Show update dialog"""
        from src.ui.dialogs.update_dialog import UpdateDialog
        
        dialog = UpdateDialog(self)
        dialog.exec()
        
    def show_about(self):
        """Show about dialog"""
        from src.core.updater import AutoUpdater
        
        updater = AutoUpdater()
        current_version = updater.current_version
        
        QMessageBox.about(
            self,
            "About GameHub OS",
            f"""<h2>🎮 GameHub OS</h2>
            <p><b>Version:</b> {current_version}</p>
            <p><b>Developer:</b> GameHub Team</p>
            <p><b>GitHub:</b> github.com/jdjdhdcbfgghh8845/data-base-</p>
            <br>
            <p>Ultimate gaming platform with system optimization,<br>
            game library management, achievements, and global chat.</p>
            <br>
            <p><b>Built with:</b> Python, PyQt6, SQLAlchemy</p>
            """
        )
        
    def apply_theme(self):
        """Apply custom theme and styling - MODERN DESIGN"""
        self.setStyleSheet("""
            /* Main Window */
            QMainWindow {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #1a1a2e, stop:1 #16213e);
            }
            
            /* Page Stack */
            #page_stack {
                background-color: rgba(26, 26, 46, 0.95);
                border: none;
                border-radius: 15px;
            }
            
            /* Status Bar */
            #status_bar {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #0f3460, stop:1 #16213e);
                color: #ffffff;
                padding: 8px;
                border-top: 2px solid #00d4ff;
            }
            
            #status_bar QLabel {
                margin: 0 15px;
                color: #e0e0e0;
                font-size: 13px;
                font-weight: 500;
            }
            
            /* Scrollbar */
            QScrollBar:vertical {
                background-color: rgba(255, 255, 255, 0.05);
                width: 12px;
                border-radius: 6px;
                margin: 0;
            }
            
            QScrollBar::handle:vertical {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #00d4ff, stop:1 #0096c7);
                border-radius: 6px;
                min-height: 30px;
            }
            
            QScrollBar::handle:vertical:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #00e5ff, stop:1 #00b4d8);
            }
            
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
            
            QScrollBar:horizontal {
                background-color: rgba(255, 255, 255, 0.05);
                height: 12px;
                border-radius: 6px;
            }
            
            QScrollBar::handle:horizontal {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #00d4ff, stop:1 #0096c7);
                border-radius: 6px;
                min-width: 30px;
            }
            
            /* Buttons */
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #00d4ff, stop:1 #0096c7);
                color: white;
                border: none;
                border-radius: 8px;
                padding: 10px 20px;
                font-weight: bold;
                font-size: 14px;
            }
            
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #00e5ff, stop:1 #00b4d8);
            }
            
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #0096c7, stop:1 #006d8f);
            }
            
            QPushButton:disabled {
                background-color: #3a3a3a;
                color: #666666;
            }
            
            /* Input Fields */
            QLineEdit, QTextEdit, QComboBox {
                background-color: rgba(255, 255, 255, 0.08);
                border: 2px solid rgba(0, 212, 255, 0.3);
                border-radius: 8px;
                padding: 10px;
                color: #ffffff;
                font-size: 14px;
            }
            
            QLineEdit:focus, QTextEdit:focus, QComboBox:focus {
                border: 2px solid #00d4ff;
                background-color: rgba(255, 255, 255, 0.12);
            }
            
            /* Labels */
            QLabel {
                color: #e0e0e0;
                font-size: 14px;
            }
            
            /* Progress Bar */
            QProgressBar {
                background-color: rgba(255, 255, 255, 0.1);
                border: none;
                border-radius: 10px;
                text-align: center;
                color: white;
                font-weight: bold;
                height: 20px;
            }
            
            QProgressBar::chunk {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #00d4ff, stop:0.5 #0096c7, stop:1 #00d4ff);
                border-radius: 10px;
            }
            
            /* Tooltips */
            QToolTip {
                background-color: #1a1a2e;
                color: #ffffff;
                border: 2px solid #00d4ff;
                border-radius: 8px;
                padding: 8px;
                font-size: 13px;
            }
        """)
        
    def start_services(self):
        """Start background services"""
        # Start Telegram bot if configured (disabled by default to avoid conflicts)
        # Uncomment to enable:
        # if self.config.validate_telegram_config():
        #     self.telegram_chat.start()
        #     logger.info("Telegram chat service started")
        pass
            
        # Auto-scan for games if enabled
        if self.config.get('game_library.auto_scan_on_startup'):
            QTimer.singleShot(1000, self.auto_scan_games)
            
    def auto_scan_games(self):
        """Automatically scan for games on startup"""
        logger.info("Auto-scanning for games...")
        self.library_page.scan_for_games()
        
    def closeEvent(self, event):
        """Handle window close event"""
        # Create custom message box
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Close GameHub OS")
        msg_box.setText("What would you like to do?")
        msg_box.setIcon(QMessageBox.Icon.Question)
        
        # Add custom buttons
        minimize_btn = msg_box.addButton("Minimize to Tray", QMessageBox.ButtonRole.YesRole)
        quit_btn = msg_box.addButton("Quit Completely", QMessageBox.ButtonRole.NoRole)
        cancel_btn = msg_box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
        
        msg_box.setDefaultButton(minimize_btn)
        msg_box.exec()
        
        clicked = msg_box.clickedButton()
        
        if clicked == minimize_btn:
            # Minimize to tray
            event.ignore()
            self.hide()
            if self.tray_icon:
                self.tray_icon.showMessage(
                    "GameHub OS",
                    "Application minimized to tray. Double-click icon to restore.",
                    QSystemTrayIcon.MessageIcon.Information,
                    2000
                )
        elif clicked == quit_btn:
            # Quit completely
            event.accept()
            self.quit_application()
        else:
            # Cancel - do nothing
            event.ignore()
            
    def quit_application(self):
        """Quit the application completely"""
        logger.info("Shutting down GameHub OS...")
        
        # Stop services gracefully
        try:
            if hasattr(self, 'telegram_chat') and self.telegram_chat.is_connected():
                logger.info("Stopping Telegram chat...")
                self.telegram_chat.stop()
                # Give it time to cleanup
                import time
                time.sleep(0.5)
        except Exception as e:
            logger.error(f"Error stopping Telegram: {e}")
            
        # Restore system if optimization is active
        try:
            if hasattr(self, 'optimizer') and self.optimizer.optimization_active:
                logger.info("Restoring system settings...")
                self.optimizer.restore_system()
        except Exception as e:
            logger.error(f"Error restoring system: {e}")
            
        # Close database
        try:
            if hasattr(self, 'db_manager'):
                logger.info("Closing database...")
                self.db_manager.close()
        except Exception as e:
            logger.error(f"Error closing database: {e}")
        
        logger.info("Shutdown complete. Goodbye!")
        
        # Quit application
        QApplication.quit()
        
        # Force exit
        import sys
        sys.exit(0)
