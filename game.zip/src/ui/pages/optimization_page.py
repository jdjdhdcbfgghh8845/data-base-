"""System Optimization page"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QProgressBar, QGroupBox, QCheckBox, QSlider, QTextEdit,
    QFrame, QGraphicsDropShadowEffect, QListWidget, QListWidgetItem
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import QColor, QFont
import psutil
from datetime import datetime
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class OptimizationThread(QThread):
    """Thread for running optimization"""
    progress = pyqtSignal(int)
    status = pyqtSignal(str)
    finished_optimization = pyqtSignal(dict)
    
    def __init__(self, optimizer, game_exe=None):
        super().__init__()
        self.optimizer = optimizer
        self.game_exe = game_exe
        
    def run(self):
        """Run optimization"""
        self.status.emit("Starting optimization...")
        result = self.optimizer.optimize_for_gaming(self.game_exe)
        self.finished_optimization.emit(result)


class SystemInfoWidget(QFrame):
    """Widget for displaying system information"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        self.start_monitoring()
        
    def setup_ui(self):
        """Setup system info UI"""
        self.setObjectName("system_info")
        self.setFrameStyle(QFrame.Shape.Box)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        
        title = QLabel("📊 System Status")
        title.setStyleSheet("""
            QLabel {
                color: #00897B;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        layout.addWidget(title)
        
        # CPU info
        self.cpu_label = QLabel("CPU Usage: 0%")
        self.cpu_bar = QProgressBar()
        self.cpu_bar.setTextVisible(False)
        self.cpu_bar.setMaximum(100)
        
        # RAM info
        self.ram_label = QLabel("RAM Usage: 0%")
        self.ram_bar = QProgressBar()
        self.ram_bar.setTextVisible(False)
        self.ram_bar.setMaximum(100)
        
        # GPU info (if available)
        self.gpu_label = QLabel("GPU Usage: N/A")
        self.gpu_bar = QProgressBar()
        self.gpu_bar.setTextVisible(False)
        self.gpu_bar.setMaximum(100)
        self.gpu_bar.setEnabled(False)
        
        # Disk info
        self.disk_label = QLabel("Disk Usage: 0%")
        self.disk_bar = QProgressBar()
        self.disk_bar.setTextVisible(False)
        self.disk_bar.setMaximum(100)
        
        # Network info
        self.network_label = QLabel("Network: 0 MB/s")
        
        # Temperature
        self.temp_label = QLabel("Temperature: N/A")
        
        # Add all to layout
        for label, bar in [
            (self.cpu_label, self.cpu_bar),
            (self.ram_label, self.ram_bar),
            (self.gpu_label, self.gpu_bar),
            (self.disk_label, self.disk_bar)
        ]:
            layout.addWidget(label)
            if bar:
                layout.addWidget(bar)
                
        layout.addWidget(self.network_label)
        layout.addWidget(self.temp_label)
        
        # Style
        self.setStyleSheet("""
            #system_info {
                background-color: #2a2a2a;
                border: 1px solid #333333;
                border-radius: 10px;
            }
            QLabel {
                color: #b0b0b0;
                font-size: 13px;
                margin-top: 5px;
            }
            QProgressBar {
                background-color: #333333;
                border: none;
                border-radius: 5px;
                height: 20px;
            }
            QProgressBar::chunk {
                border-radius: 5px;
            }
        """)
        
    def start_monitoring(self):
        """Start system monitoring"""
        self.monitor_timer = QTimer()
        self.monitor_timer.timeout.connect(self.update_info)
        self.monitor_timer.start(1000)
        self.update_info()
        
    def update_info(self):
        """Update system information"""
        try:
            # CPU
            cpu_percent = psutil.cpu_percent(interval=0)
            self.cpu_label.setText(f"CPU Usage: {cpu_percent:.1f}%")
            self.cpu_bar.setValue(int(cpu_percent))
            self.set_bar_color(self.cpu_bar, cpu_percent)
            
            # RAM
            ram = psutil.virtual_memory()
            self.ram_label.setText(f"RAM Usage: {ram.percent:.1f}% ({ram.used / 1024**3:.1f}/{ram.total / 1024**3:.1f} GB)")
            self.ram_bar.setValue(int(ram.percent))
            self.set_bar_color(self.ram_bar, ram.percent)
            
            # Disk
            disk = psutil.disk_usage('/')
            self.disk_label.setText(f"Disk Usage: {disk.percent:.1f}%")
            self.disk_bar.setValue(int(disk.percent))
            self.set_bar_color(self.disk_bar, disk.percent)
            
            # Network
            net_io = psutil.net_io_counters()
            if hasattr(self, 'last_recv'):
                recv_speed = (net_io.bytes_recv - self.last_recv) / 1024 / 1024
                send_speed = (net_io.bytes_sent - self.last_sent) / 1024 / 1024
                self.network_label.setText(f"Network: ↓{recv_speed:.1f} ↑{send_speed:.1f} MB/s")
            self.last_recv = net_io.bytes_recv
            self.last_sent = net_io.bytes_sent
            
            # Temperature (if available)
            if hasattr(psutil, "sensors_temperatures"):
                temps = psutil.sensors_temperatures()
                if temps:
                    for name, entries in temps.items():
                        if entries:
                            temp = entries[0].current
                            self.temp_label.setText(f"Temperature: {temp:.1f}°C")
                            break
                            
        except Exception as e:
            logger.error(f"Error updating system info: {e}")
            
    def set_bar_color(self, bar, value):
        """Set progress bar color based on value"""
        if value < 50:
            color = "#00FF00"  # Green
        elif value < 75:
            color = "#FFFF00"  # Yellow
        else:
            color = "#FF0000"  # Red
            
        bar.setStyleSheet(f"""
            QProgressBar::chunk {{
                background-color: {color};
                border-radius: 5px;
            }}
        """)


class OptimizationPage(QWidget):
    """System optimization page"""
    
    def __init__(self, optimizer, config, parent=None):
        super().__init__(parent)
        self.optimizer = optimizer
        self.config = config
        self.setup_ui()
        
    def setup_ui(self):
        """Setup optimization page UI"""
        # Main layout
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(20)
        
        # Left side - controls
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setSpacing(15)
        
        # Title
        title = QLabel("⚡ System Optimization")
        title.setStyleSheet("""
            QLabel {
                color: #ffffff;
                font-size: 24px;
                font-weight: bold;
            }
        """)
        left_layout.addWidget(title)
        
        # Quick optimize button
        self.optimize_button = QPushButton("🚀 Quick Optimize")
        self.optimize_button.setMinimumHeight(60)
        self.optimize_button.clicked.connect(self.run_optimization)
        self.optimize_button.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #00897B, stop:1 #00A693);
                color: white;
                border: none;
                border-radius: 10px;
                font-size: 18px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #00A693, stop:1 #00BFA5);
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #00695C, stop:1 #00897B);
            }
        """)
        left_layout.addWidget(self.optimize_button)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background-color: #333333;
                border: none;
                border-radius: 5px;
                text-align: center;
                color: white;
                height: 25px;
            }
            QProgressBar::chunk {
                background-color: #00897B;
                border-radius: 5px;
            }
        """)
        left_layout.addWidget(self.progress_bar)
        
        # Status label
        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: #b0b0b0; font-size: 13px;")
        left_layout.addWidget(self.status_label)
        
        # Optimization settings
        settings_group = QGroupBox("Optimization Settings")
        settings_group.setStyleSheet("""
            QGroupBox {
                color: #ffffff;
                font-size: 14px;
                font-weight: bold;
                border: 1px solid #333333;
                border-radius: 10px;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
        """)
        
        settings_layout = QVBoxLayout(settings_group)
        
        # Checkboxes for optimization options
        self.ram_check = QCheckBox("🧹 Free up RAM")
        self.ram_check.setChecked(True)
        
        self.process_check = QCheckBox("🔧 Close unnecessary processes")
        self.process_check.setChecked(True)
        
        self.service_check = QCheckBox("⚙️ Stop optional services")
        self.service_check.setChecked(True)
        
        self.network_check = QCheckBox("🌐 Optimize network settings")
        self.network_check.setChecked(True)
        
        self.power_check = QCheckBox("⚡ Set high performance mode")
        self.power_check.setChecked(True)
        
        self.auto_check = QCheckBox("🤖 Auto-optimize on game launch")
        self.auto_check.setChecked(
            self.config.get('optimization.auto_optimize_on_game_launch', True)
        )
        self.auto_check.toggled.connect(self.toggle_auto_optimize)
        
        for checkbox in [self.ram_check, self.process_check, self.service_check,
                        self.network_check, self.power_check, self.auto_check]:
            checkbox.setStyleSheet("""
                QCheckBox {
                    color: #b0b0b0;
                    font-size: 13px;
                    spacing: 10px;
                }
                QCheckBox::indicator {
                    width: 18px;
                    height: 18px;
                }
                QCheckBox::indicator:checked {
                    background-color: #00897B;
                    border: 2px solid #00897B;
                    border-radius: 3px;
                }
                QCheckBox::indicator:unchecked {
                    background-color: #333333;
                    border: 2px solid #555555;
                    border-radius: 3px;
                }
            """)
            settings_layout.addWidget(checkbox)
            
        left_layout.addWidget(settings_group)
        
        # RAM threshold slider
        threshold_label = QLabel(f"RAM Cleanup Threshold: {self.config.get('optimization.ram_cleanup_threshold', 80)}%")
        threshold_label.setStyleSheet("color: #b0b0b0; font-size: 13px;")
        left_layout.addWidget(threshold_label)
        
        self.ram_slider = QSlider(Qt.Orientation.Horizontal)
        self.ram_slider.setRange(50, 95)
        self.ram_slider.setValue(self.config.get('optimization.ram_cleanup_threshold', 80))
        self.ram_slider.valueChanged.connect(
            lambda v: threshold_label.setText(f"RAM Cleanup Threshold: {v}%")
        )
        self.ram_slider.setStyleSheet("""
            QSlider::groove:horizontal {
                height: 6px;
                background: #333333;
                border-radius: 3px;
            }
            QSlider::handle:horizontal {
                background: #00897B;
                width: 16px;
                height: 16px;
                margin: -5px 0;
                border-radius: 8px;
            }
            QSlider::handle:horizontal:hover {
                background: #00A693;
            }
        """)
        left_layout.addWidget(self.ram_slider)
        
        # Restore button
        self.restore_button = QPushButton("↩️ Restore System")
        self.restore_button.setEnabled(False)
        self.restore_button.clicked.connect(self.restore_system)
        self.restore_button.setStyleSheet("""
            QPushButton {
                background-color: #FF6B6B;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 10px;
                font-weight: bold;
            }
            QPushButton:hover:enabled {
                background-color: #FF5252;
            }
            QPushButton:disabled {
                background-color: #555555;
                color: #888888;
            }
        """)
        left_layout.addWidget(self.restore_button)
        
        left_layout.addStretch()
        
        # Right side - info and logs
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setSpacing(15)
        
        # System info widget
        self.system_info = SystemInfoWidget()
        right_layout.addWidget(self.system_info)
        
        # Optimization log
        log_group = QGroupBox("Optimization Log")
        log_group.setStyleSheet("""
            QGroupBox {
                color: #ffffff;
                font-size: 14px;
                font-weight: bold;
                border: 1px solid #333333;
                border-radius: 10px;
                margin-top: 10px;
                padding-top: 10px;
            }
        """)
        
        log_layout = QVBoxLayout(log_group)
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e;
                color: #b0b0b0;
                border: none;
                font-family: 'Consolas', 'Monaco', monospace;
                font-size: 12px;
            }
        """)
        log_layout.addWidget(self.log_text)
        
        right_layout.addWidget(log_group)
        
        # Add to main layout
        main_layout.addWidget(left_widget, 1)
        main_layout.addWidget(right_widget, 1)
        
    def run_optimization(self):
        """Run system optimization"""
        self.optimize_button.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)  # Indeterminate
        
        self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] Starting optimization...")
        
        # Create and start optimization thread
        self.opt_thread = OptimizationThread(self.optimizer)
        self.opt_thread.status.connect(self.update_status)
        self.opt_thread.finished_optimization.connect(self.on_optimization_complete)
        self.opt_thread.start()
        
    def update_status(self, status: str):
        """Update status label"""
        self.status_label.setText(status)
        self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] {status}")
        
    def on_optimization_complete(self, result: dict):
        """Handle optimization completion"""
        self.optimize_button.setEnabled(True)
        self.progress_bar.setVisible(False)
        self.restore_button.setEnabled(True)
        
        if result.get('success'):
            stats = result.get('stats', {})
            
            self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] Optimization complete!")
            self.log_text.append(f"  - RAM freed: {stats.get('ram_freed', 0):.0f} MB")
            self.log_text.append(f"  - Processes closed: {stats.get('processes_closed', 0)}")
            self.log_text.append(f"  - Services stopped: {stats.get('services_stopped', 0)}")
            
            self.status_label.setText("✅ Optimization successful!")
            
            # Show achievement notification if any
            self.check_achievements(stats)
        else:
            self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] Optimization failed!")
            self.status_label.setText("❌ Optimization failed")
            
    def restore_system(self):
        """Restore system to original state"""
        result = self.optimizer.restore_system()
        
        if result.get('success'):
            self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] System restored to original state")
            self.status_label.setText("✅ System restored")
            self.restore_button.setEnabled(False)
        else:
            self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] Failed to restore system")
            self.status_label.setText("❌ Restore failed")
            
    def toggle_auto_optimize(self, checked: bool):
        """Toggle auto-optimization setting"""
        self.config.set('optimization.auto_optimize_on_game_launch', checked)
        self.log_text.append(
            f"[{datetime.now().strftime('%H:%M:%S')}] Auto-optimization {'enabled' if checked else 'disabled'}"
        )
        
    def check_achievements(self, stats: dict):
        """Check for optimization achievements"""
        # This would integrate with the achievement system
        pass
