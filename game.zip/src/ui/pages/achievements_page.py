"""Achievements page"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QScrollArea, QPushButton,
    QLabel, QProgressBar, QFrame, QGridLayout, QGroupBox,
    QListWidget, QListWidgetItem, QDialog, QDialogButtonBox, QMessageBox
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import QPixmap, QColor, QFont
from typing import List, Dict
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class AchievementCard(QFrame):
    """Card widget for displaying achievement"""
    
    clicked = pyqtSignal(dict)
    
    def __init__(self, achievement_data: dict, parent=None):
        super().__init__(parent)
        self.achievement_data = achievement_data
        self.setup_ui()
        
    def setup_ui(self):
        """Setup achievement card UI"""
        self.setObjectName("achievement_card")
        self.setFixedSize(350, 120)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        
        # Main layout
        layout = QHBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(15)
        
        # Icon
        icon_label = QLabel(self.achievement_data.get('icon', '🏆'))
        icon_label.setStyleSheet("""
            QLabel {
                font-size: 36px;
                background-color: rgba(255, 255, 255, 0.05);
                border-radius: 10px;
                padding: 10px;
            }
        """)
        icon_label.setFixedSize(60, 60)
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(icon_label)
        
        # Info section
        info_layout = QVBoxLayout()
        info_layout.setSpacing(5)
        
        # Name
        name_label = QLabel(self.achievement_data['name'])
        name_label.setStyleSheet("""
            QLabel {
                color: #ffffff;
                font-size: 14px;
                font-weight: bold;
            }
        """)
        info_layout.addWidget(name_label)
        
        # Description
        desc_label = QLabel(self.achievement_data['description'])
        desc_label.setWordWrap(True)
        desc_label.setStyleSheet("""
            QLabel {
                color: #b0b0b0;
                font-size: 12px;
            }
        """)
        info_layout.addWidget(desc_label)
        
        # Progress bar
        if not self.achievement_data.get('unlocked'):
            progress_bar = QProgressBar()
            progress_bar.setValue(int(self.achievement_data.get('progress', 0)))
            progress_bar.setMaximum(100)
            progress_bar.setFixedHeight(8)
            progress_bar.setTextVisible(False)
            progress_bar.setStyleSheet("""
                QProgressBar {
                    background-color: #333333;
                    border: none;
                    border-radius: 4px;
                }
                QProgressBar::chunk {
                    background-color: #00897B;
                    border-radius: 4px;
                }
            """)
            info_layout.addWidget(progress_bar)
        
        layout.addLayout(info_layout, 1)
        
        # Points
        points_label = QLabel(f"+{self.achievement_data['points']}")
        points_label.setStyleSheet("""
            QLabel {
                color: #FFD700;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        layout.addWidget(points_label)
        
        # Style based on unlock status
        if self.achievement_data.get('unlocked'):
            self.setStyleSheet("""
                #achievement_card {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                        stop:0 rgba(0, 137, 123, 0.3),
                        stop:1 rgba(0, 137, 123, 0.1));
                    border: 2px solid #00897B;
                    border-radius: 15px;
                }
                #achievement_card:hover {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                        stop:0 rgba(0, 137, 123, 0.4),
                        stop:1 rgba(0, 137, 123, 0.2));
                }
            """)
        else:
            self.setStyleSheet("""
                #achievement_card {
                    background-color: #2a2a2a;
                    border: 1px solid #333333;
                    border-radius: 15px;
                }
                #achievement_card:hover {
                    background-color: #333333;
                    border: 1px solid #555555;
                }
            """)
            
            # Make it look locked
            self.setEnabled(True)
            icon_label.setStyleSheet(icon_label.styleSheet() + "opacity: 0.5;")
    
    def mousePressEvent(self, event):
        """Handle mouse press"""
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.achievement_data)


class RewardCard(QFrame):
    """Card widget for displaying reward/bonus"""
    
    purchase_clicked = pyqtSignal(dict)
    
    def __init__(self, reward_data: dict, parent=None):
        super().__init__(parent)
        self.reward_data = reward_data
        self.setup_ui()
        
    def setup_ui(self):
        """Setup reward card UI"""
        self.setObjectName("reward_card")
        self.setFixedSize(200, 250)
        
        # Main layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)
        
        # Icon
        icon_label = QLabel(self.reward_data.get('icon', '🎁'))
        icon_label.setStyleSheet("""
            QLabel {
                font-size: 48px;
                background-color: rgba(255, 255, 255, 0.05);
                border-radius: 50%;
                padding: 20px;
            }
        """)
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(icon_label, alignment=Qt.AlignmentFlag.AlignCenter)
        
        # Name
        name_label = QLabel(self.reward_data['name'])
        name_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        name_label.setWordWrap(True)
        name_label.setStyleSheet("""
            QLabel {
                color: #ffffff;
                font-size: 14px;
                font-weight: bold;
            }
        """)
        layout.addWidget(name_label)
        
        # Description
        desc_label = QLabel(self.reward_data['description'])
        desc_label.setWordWrap(True)
        desc_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        desc_label.setStyleSheet("""
            QLabel {
                color: #b0b0b0;
                font-size: 11px;
            }
        """)
        layout.addWidget(desc_label)
        
        layout.addStretch()
        
        # Cost/Status button
        if self.reward_data.get('unlocked'):
            status_button = QPushButton("✓ Unlocked")
            status_button.setEnabled(False)
            status_button.setStyleSheet("""
                QPushButton {
                    background-color: #4CAF50;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    padding: 8px;
                    font-weight: bold;
                }
            """)
        else:
            status_button = QPushButton(f"🪙 {self.reward_data['cost']} Points")
            status_button.clicked.connect(lambda: self.purchase_clicked.emit(self.reward_data))
            status_button.setStyleSheet("""
                QPushButton {
                    background-color: #FFD700;
                    color: #333333;
                    border: none;
                    border-radius: 5px;
                    padding: 8px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #FFC700;
                }
            """)
        
        layout.addWidget(status_button)
        
        # Card style
        self.setStyleSheet("""
            #reward_card {
                background-color: #2a2a2a;
                border: 1px solid #333333;
                border-radius: 15px;
            }
        """)


class AchievementsPage(QWidget):
    """Achievements and rewards page"""
    
    def __init__(self, achievement_system, parent=None):
        super().__init__(parent)
        self.achievement_system = achievement_system
        self.setup_ui()
        self.load_achievements()
        
    def setup_ui(self):
        """Setup achievements page UI"""
        # Main layout
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(20)
        
        # Header
        header_layout = QHBoxLayout()
        
        title = QLabel("🏆 Achievements & Rewards")
        title.setStyleSheet("""
            QLabel {
                color: #ffffff;
                font-size: 24px;
                font-weight: bold;
            }
        """)
        header_layout.addWidget(title)
        
        header_layout.addStretch()
        
        # User stats
        stats_widget = QWidget()
        stats_layout = QHBoxLayout(stats_widget)
        stats_layout.setSpacing(20)
        
        self.level_label = QLabel("Level 1")
        self.level_label.setStyleSheet("""
            QLabel {
                color: #00897B;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        
        self.points_label = QLabel("🪙 0 Points")
        self.points_label.setStyleSheet("""
            QLabel {
                color: #FFD700;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        
        self.achievements_label = QLabel("🏆 0/0")
        self.achievements_label.setStyleSheet("""
            QLabel {
                color: #FF6B6B;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        
        stats_layout.addWidget(self.level_label)
        stats_layout.addWidget(self.points_label)
        stats_layout.addWidget(self.achievements_label)
        
        header_layout.addWidget(stats_widget)
        main_layout.addLayout(header_layout)
        
        # Progress to next level
        level_progress_layout = QVBoxLayout()
        self.level_progress_label = QLabel("Progress to Level 2")
        self.level_progress_label.setStyleSheet("color: #b0b0b0; font-size: 12px;")
        
        self.level_progress_bar = QProgressBar()
        self.level_progress_bar.setFixedHeight(20)
        self.level_progress_bar.setStyleSheet("""
            QProgressBar {
                background-color: #333333;
                border: none;
                border-radius: 10px;
                text-align: center;
                color: white;
            }
            QProgressBar::chunk {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #00897B, stop:1 #00BFA5);
                border-radius: 10px;
            }
        """)
        
        level_progress_layout.addWidget(self.level_progress_label)
        level_progress_layout.addWidget(self.level_progress_bar)
        main_layout.addLayout(level_progress_layout)
        
        # Tab buttons
        tab_layout = QHBoxLayout()
        
        self.achievements_button = QPushButton("Achievements")
        self.achievements_button.setCheckable(True)
        self.achievements_button.setChecked(True)
        self.achievements_button.clicked.connect(lambda: self.switch_tab(0))
        
        self.rewards_button = QPushButton("Rewards Store")
        self.rewards_button.setCheckable(True)
        self.rewards_button.clicked.connect(lambda: self.switch_tab(1))
        
        self.stats_button = QPushButton("Statistics")
        self.stats_button.setCheckable(True)
        self.stats_button.clicked.connect(lambda: self.switch_tab(2))
        
        for button in [self.achievements_button, self.rewards_button, self.stats_button]:
            button.setStyleSheet("""
                QPushButton {
                    background-color: #333333;
                    color: #b0b0b0;
                    border: none;
                    border-radius: 5px;
                    padding: 10px 20px;
                    font-weight: bold;
                }
                QPushButton:checked {
                    background-color: #00897B;
                    color: white;
                }
                QPushButton:hover {
                    background-color: #444444;
                }
            """)
            tab_layout.addWidget(button)
        
        tab_layout.addStretch()
        main_layout.addLayout(tab_layout)
        
        # Content area
        self.content_scroll = QScrollArea()
        self.content_scroll.setWidgetResizable(True)
        self.content_scroll.setStyleSheet("""
            QScrollArea {
                background-color: transparent;
                border: none;
            }
            QScrollBar:vertical {
                background-color: #2a2a2a;
                width: 10px;
                border-radius: 5px;
            }
            QScrollBar::handle:vertical {
                background-color: #555555;
                border-radius: 5px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background-color: #00897B;
            }
        """)
        
        self.content_widget = QWidget()
        self.content_layout = QVBoxLayout(self.content_widget)
        
        self.content_scroll.setWidget(self.content_widget)
        main_layout.addWidget(self.content_scroll)
        
        # Load initial content
        self.show_achievements()
        
    def switch_tab(self, index: int):
        """Switch between tabs"""
        # Update button states
        self.achievements_button.setChecked(index == 0)
        self.rewards_button.setChecked(index == 1)
        self.stats_button.setChecked(index == 2)
        
        # Clear content
        while self.content_layout.count():
            child = self.content_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
        
        # Show appropriate content
        if index == 0:
            self.show_achievements()
        elif index == 1:
            self.show_rewards()
        elif index == 2:
            self.show_statistics()
            
    def show_achievements(self):
        """Display achievements"""
        achievements = self.achievement_system.get_achievements_list()
        
        # Group by category
        categories = {}
        for achievement in achievements:
            category = achievement.get('category', 'general')
            if category not in categories:
                categories[category] = []
            categories[category].append(achievement)
        
        # Display by category
        for category, items in categories.items():
            # Category header
            category_label = QLabel(f"{category.title()} Achievements")
            category_label.setStyleSheet("""
                QLabel {
                    color: #00897B;
                    font-size: 16px;
                    font-weight: bold;
                    margin-top: 10px;
                }
            """)
            self.content_layout.addWidget(category_label)
            
            # Achievement cards
            for achievement in items:
                card = AchievementCard(achievement)
                card.clicked.connect(self.show_achievement_details)
                self.content_layout.addWidget(card)
        
        self.content_layout.addStretch()
        
    def show_rewards(self):
        """Display rewards store"""
        rewards = self.achievement_system.get_available_rewards()
        
        # Create grid layout for rewards
        grid_widget = QWidget()
        grid_layout = QGridLayout(grid_widget)
        grid_layout.setSpacing(20)
        
        row, col = 0, 0
        max_cols = 3
        
        for reward in rewards:
            card = RewardCard(reward)
            card.purchase_clicked.connect(self.purchase_reward)
            grid_layout.addWidget(card, row, col)
            
            col += 1
            if col >= max_cols:
                col = 0
                row += 1
        
        self.content_layout.addWidget(grid_widget)
        self.content_layout.addStretch()
        
    def show_statistics(self):
        """Display user statistics"""
        stats = self.achievement_system.get_user_stats()
        
        # Create stats display
        stats_group = QGroupBox("Player Statistics")
        stats_group.setStyleSheet("""
            QGroupBox {
                color: #ffffff;
                font-size: 16px;
                font-weight: bold;
                border: 1px solid #333333;
                border-radius: 10px;
                margin-top: 10px;
                padding-top: 10px;
            }
        """)
        
        stats_layout = QVBoxLayout(stats_group)
        
        stats_items = [
            ("Current Level", f"Level {stats.get('level', 1)}: {stats.get('level_title', 'Novice')}"),
            ("Total Points", f"{stats.get('total_points', 0)} points"),
            ("Experience", f"{stats.get('experience', 0)} / {stats.get('next_level_xp', 100)} XP"),
            ("Achievements Unlocked", f"{stats.get('achievements_unlocked', 0)} / {stats.get('total_achievements', 0)}"),
            ("Total Playtime", f"{stats.get('total_playtime', 0):.1f} hours"),
            ("Games Played", f"{stats.get('games_played', 0)} games"),
            ("Optimizations Run", f"{stats.get('optimizations_run', 0)} times")
        ]
        
        for label, value in stats_items:
            row_layout = QHBoxLayout()
            
            label_widget = QLabel(label)
            label_widget.setStyleSheet("color: #b0b0b0; font-size: 14px; font-weight: normal;")
            
            value_widget = QLabel(value)
            value_widget.setStyleSheet("color: #ffffff; font-size: 14px; font-weight: bold;")
            
            row_layout.addWidget(label_widget)
            row_layout.addStretch()
            row_layout.addWidget(value_widget)
            
            stats_layout.addLayout(row_layout)
        
        self.content_layout.addWidget(stats_group)
        self.content_layout.addStretch()
        
    def load_achievements(self):
        """Load user achievements and stats"""
        stats = self.achievement_system.get_user_stats()
        
        # Update header labels
        self.level_label.setText(f"Level {stats.get('level', 1)}")
        self.points_label.setText(f"🪙 {stats.get('total_points', 0)} Points")
        self.achievements_label.setText(
            f"🏆 {stats.get('achievements_unlocked', 0)}/{stats.get('total_achievements', 0)}"
        )
        
        # Update level progress
        current_xp = stats.get('experience', 0)
        next_level_xp = stats.get('next_level_xp', 100)
        progress = int((current_xp / next_level_xp) * 100) if next_level_xp > 0 else 0
        
        self.level_progress_label.setText(f"Progress to Level {stats.get('level', 1) + 1}")
        self.level_progress_bar.setValue(progress)
        self.level_progress_bar.setFormat(f"{current_xp}/{next_level_xp} XP")
        
    def show_achievement_details(self, achievement: dict):
        """Show achievement details dialog"""
        dialog = QMessageBox(self)
        dialog.setWindowTitle(achievement['name'])
        
        # Format status
        if achievement.get('unlocked'):
            status = 'Unlocked ✓'
        else:
            progress = achievement.get('progress', 0)
            status = f'Progress: {progress}%'
        
        dialog.setText(f"{achievement['icon']} {achievement['name']}\n\n"
                      f"{achievement['description']}\n\n"
                      f"Points: {achievement['points']}\n"
                      f"Category: {achievement['category'].title()}\n"
                      f"Status: {status}")
        dialog.exec()
        
    def purchase_reward(self, reward: dict):
        """Purchase a reward"""
        reply = QMessageBox.question(
            self, "Purchase Reward",
            f"Purchase {reward['name']} for {reward['cost']} points?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            success, message = self.achievement_system.purchase_reward(reward['id'])
            
            if success:
                QMessageBox.information(self, "Success", message)
                self.load_achievements()
                self.show_rewards()  # Refresh rewards display
            else:
                QMessageBox.warning(self, "Failed", message)
