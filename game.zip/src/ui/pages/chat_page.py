"""Global chat page with Telegram integration"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTextEdit, QLineEdit,
    QPushButton, QLabel, QListWidget, QListWidgetItem,
    QFrame, QMessageBox, QInputDialog
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QDateTime
from PyQt6.QtGui import QTextCursor, QTextCharFormat, QColor, QFont
from datetime import datetime
from typing import Dict
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class ChatMessage(QFrame):
    """Custom chat message widget"""
    
    def __init__(self, message_data: Dict, is_own: bool = False, parent=None):
        super().__init__(parent)
        self.message_data = message_data
        self.is_own = is_own
        self.setup_ui()
        
    def setup_ui(self):
        """Setup message UI"""
        self.setFrameStyle(QFrame.Shape.NoFrame)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 5, 10, 5)
        
        # Header (username and timestamp)
        header_layout = QHBoxLayout()
        
        username = QLabel(self.message_data['username'])
        username.setStyleSheet(f"""
            QLabel {{
                color: {'#00897B' if self.is_own else '#FFD700'};
                font-weight: bold;
                font-size: 13px;
            }}
        """)
        header_layout.addWidget(username)
        
        timestamp = QLabel(self.message_data.get('timestamp', ''))
        timestamp.setStyleSheet("""
            QLabel {
                color: #666666;
                font-size: 11px;
            }
        """)
        header_layout.addWidget(timestamp)
        header_layout.addStretch()
        
        layout.addLayout(header_layout)
        
        # Message text
        message = QLabel(self.message_data['text'])
        message.setWordWrap(True)
        message.setStyleSheet("""
            QLabel {
                color: #ffffff;
                font-size: 14px;
                padding: 8px;
                background-color: rgba(255, 255, 255, 0.05);
                border-radius: 10px;
            }
        """)
        layout.addWidget(message)
        
        # Style based on sender
        if self.is_own:
            self.setStyleSheet("""
                QFrame {
                    background-color: transparent;
                    margin-left: 50px;
                }
            """)
        else:
            self.setStyleSheet("""
                QFrame {
                    background-color: transparent;
                    margin-right: 50px;
                }
            """)


class ChatPage(QWidget):
    """Global chat page with Telegram integration"""
    
    def __init__(self, telegram_chat, config, parent=None):
        super().__init__(parent)
        self.telegram_chat = telegram_chat
        self.config = config
        self.setup_ui()
        self.setup_telegram()
        
    def setup_ui(self):
        """Setup chat page UI"""
        # Main layout
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(20)
        
        # Chat area (left side)
        chat_widget = QWidget()
        chat_layout = QVBoxLayout(chat_widget)
        chat_layout.setSpacing(10)
        
        # Header
        header_layout = QHBoxLayout()
        
        title = QLabel("💬 Global Chat")
        title.setStyleSheet("""
            QLabel {
                color: #ffffff;
                font-size: 24px;
                font-weight: bold;
            }
        """)
        header_layout.addWidget(title)
        
        # Connection status
        self.status_label = QLabel("🔴 Offline")
        self.status_label.setStyleSheet("""
            QLabel {
                color: #FF5252;
                font-size: 14px;
                font-weight: bold;
            }
        """)
        header_layout.addWidget(self.status_label)
        
        header_layout.addStretch()
        
        # Connect button
        self.connect_button = QPushButton("Connect")
        self.connect_button.clicked.connect(self.toggle_connection)
        self.connect_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 8px 20px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #66BB6A;
            }
        """)
        header_layout.addWidget(self.connect_button)
        
        chat_layout.addLayout(header_layout)
        
        # Chat display
        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        self.chat_display.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e;
                color: #ffffff;
                border: 1px solid #333333;
                border-radius: 10px;
                padding: 10px;
                font-size: 13px;
            }
        """)
        chat_layout.addWidget(self.chat_display)
        
        # Input area
        input_layout = QHBoxLayout()
        
        self.message_input = QLineEdit()
        self.message_input.setPlaceholderText("Type a message...")
        self.message_input.returnPressed.connect(self.send_message)
        self.message_input.setEnabled(False)
        self.message_input.setStyleSheet("""
            QLineEdit {
                background-color: #2a2a2a;
                color: #ffffff;
                border: 1px solid #333333;
                border-radius: 20px;
                padding: 10px 15px;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 1px solid #00897B;
            }
        """)
        input_layout.addWidget(self.message_input)
        
        self.send_button = QPushButton("➤")
        self.send_button.clicked.connect(self.send_message)
        self.send_button.setEnabled(False)
        self.send_button.setFixedSize(40, 40)
        self.send_button.setStyleSheet("""
            QPushButton {
                background-color: #00897B;
                color: white;
                border: none;
                border-radius: 20px;
                font-size: 20px;
                font-weight: bold;
            }
            QPushButton:hover:enabled {
                background-color: #00A693;
            }
            QPushButton:disabled {
                background-color: #555555;
            }
        """)
        input_layout.addWidget(self.send_button)
        
        chat_layout.addLayout(input_layout)
        
        # Right sidebar
        sidebar_widget = QWidget()
        sidebar_widget.setFixedWidth(250)
        sidebar_layout = QVBoxLayout(sidebar_widget)
        sidebar_layout.setSpacing(15)
        
        # Chat info
        info_group = QFrame()
        info_group.setStyleSheet("""
            QFrame {
                background-color: #2a2a2a;
                border: 1px solid #333333;
                border-radius: 10px;
                padding: 15px;
            }
        """)
        info_layout = QVBoxLayout(info_group)
        
        info_title = QLabel("📊 Chat Info")
        info_title.setStyleSheet("""
            QLabel {
                color: #00897B;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        info_layout.addWidget(info_title)
        
        self.chat_name_label = QLabel("Chat: Not connected")
        self.chat_name_label.setStyleSheet("color: #b0b0b0; font-size: 12px;")
        info_layout.addWidget(self.chat_name_label)
        
        self.members_label = QLabel("Members: --")
        self.members_label.setStyleSheet("color: #b0b0b0; font-size: 12px;")
        info_layout.addWidget(self.members_label)
        
        self.messages_count_label = QLabel("Messages: 0")
        self.messages_count_label.setStyleSheet("color: #b0b0b0; font-size: 12px;")
        info_layout.addWidget(self.messages_count_label)
        
        sidebar_layout.addWidget(info_group)
        
        # User settings
        settings_group = QFrame()
        settings_group.setStyleSheet("""
            QFrame {
                background-color: #2a2a2a;
                border: 1px solid #333333;
                border-radius: 10px;
                padding: 15px;
            }
        """)
        settings_layout = QVBoxLayout(settings_group)
        
        settings_title = QLabel("⚙️ Chat Settings")
        settings_title.setStyleSheet("""
            QLabel {
                color: #00897B;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        settings_layout.addWidget(settings_title)
        
        # Username
        username_layout = QHBoxLayout()
        username_layout.addWidget(QLabel("Username:"))
        self.username_label = QLabel(self.config.get('chat.username', 'Anonymous'))
        self.username_label.setStyleSheet("color: #FFD700; font-weight: bold;")
        username_layout.addWidget(self.username_label)
        username_layout.addStretch()
        
        change_username_button = QPushButton("✏️")
        change_username_button.setFixedSize(30, 30)
        change_username_button.clicked.connect(self.change_username)
        username_layout.addWidget(change_username_button)
        
        settings_layout.addLayout(username_layout)
        
        sidebar_layout.addWidget(settings_group)
        
        # Online users (placeholder)
        users_group = QFrame()
        users_group.setStyleSheet("""
            QFrame {
                background-color: #2a2a2a;
                border: 1px solid #333333;
                border-radius: 10px;
                padding: 15px;
            }
        """)
        users_layout = QVBoxLayout(users_group)
        
        users_title = QLabel("👥 Active Users")
        users_title.setStyleSheet("""
            QLabel {
                color: #00897B;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        users_layout.addWidget(users_title)
        
        self.users_list = QListWidget()
        self.users_list.setMaximumHeight(200)
        self.users_list.setStyleSheet("""
            QListWidget {
                background-color: #1e1e1e;
                color: #b0b0b0;
                border: none;
            }
        """)
        users_layout.addWidget(self.users_list)
        
        sidebar_layout.addWidget(users_group)
        sidebar_layout.addStretch()
        
        # Add to main layout
        main_layout.addWidget(chat_widget, 1)
        main_layout.addWidget(sidebar_widget)
        
        # Timer for updates
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update_chat_info)
        self.update_timer.start(5000)  # Update every 5 seconds
        
    def setup_telegram(self):
        """Setup Telegram bot connection"""
        # Set message callback
        self.telegram_chat.set_message_callback(self.on_message_received)
        
        # Load message history
        self.load_message_history()
        
        # Check if bot is already connected
        if self.telegram_chat.is_connected():
            self.on_connected()
            
    def toggle_connection(self):
        """Toggle Telegram connection"""
        if not self.telegram_chat.is_connected():
            # Check if credentials are configured
            if not self.config.validate_telegram_config():
                QMessageBox.warning(
                    self, "Configuration Required",
                    "Please configure Telegram bot credentials in Settings."
                )
                return
            
            # Start connection
            self.telegram_chat.start()
            
            # Update UI
            self.on_connected()
        else:
            # Disconnect
            self.telegram_chat.stop()
            self.on_disconnected()
            
    def on_connected(self):
        """Handle successful connection"""
        self.status_label.setText("🟢 Online")
        self.status_label.setStyleSheet("""
            QLabel {
                color: #4CAF50;
                font-size: 14px;
                font-weight: bold;
            }
        """)
        
        self.connect_button.setText("Disconnect")
        self.connect_button.setStyleSheet("""
            QPushButton {
                background-color: #FF5252;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 8px 20px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FF6B6B;
            }
        """)
        
        self.message_input.setEnabled(True)
        self.send_button.setEnabled(True)
        
        self.add_system_message("Connected to Telegram chat!")
        
    def on_disconnected(self):
        """Handle disconnection"""
        self.status_label.setText("🔴 Offline")
        self.status_label.setStyleSheet("""
            QLabel {
                color: #FF5252;
                font-size: 14px;
                font-weight: bold;
            }
        """)
        
        self.connect_button.setText("Connect")
        self.connect_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 8px 20px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #66BB6A;
            }
        """)
        
        self.message_input.setEnabled(False)
        self.send_button.setEnabled(False)
        
        self.add_system_message("Disconnected from chat.")
        
    def send_message(self):
        """Send message to chat"""
        text = self.message_input.text().strip()
        if not text:
            return
            
        # Clear input
        self.message_input.clear()
        
        # Send via Telegram
        if self.telegram_chat.send_message_sync(text):
            # Add to display
            self.add_message({
                'username': self.config.get('chat.username', 'Anonymous'),
                'text': text,
                'timestamp': datetime.now().strftime('%H:%M:%S')
            }, is_own=True)
        else:
            self.add_system_message("Failed to send message!", error=True)
            
    def on_message_received(self, message_data: Dict):
        """Handle received message"""
        # Add to display
        self.add_message(message_data)
        
        # Show notification if enabled
        if self.config.get('chat.notifications_enabled', True):
            self.show_notification(message_data)
            
    def add_message(self, message_data: Dict, is_own: bool = False):
        """Add message to chat display"""
        timestamp = message_data.get('timestamp', datetime.now().strftime('%H:%M:%S'))
        username = message_data['username']
        text = message_data['text']
        
        # Format message
        cursor = self.chat_display.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        
        # Timestamp
        time_format = QTextCharFormat()
        time_format.setForeground(QColor("#666666"))
        cursor.insertText(f"[{timestamp}] ", time_format)
        
        # Username
        user_format = QTextCharFormat()
        user_format.setForeground(QColor("#00897B" if is_own else "#FFD700"))
        user_format.setFontWeight(QFont.Weight.Bold)
        cursor.insertText(f"{username}: ", user_format)
        
        # Message
        msg_format = QTextCharFormat()
        msg_format.setForeground(QColor("#ffffff"))
        cursor.insertText(f"{text}\n", msg_format)
        
        # Scroll to bottom
        self.chat_display.verticalScrollBar().setValue(
            self.chat_display.verticalScrollBar().maximum()
        )
        
        # Update message count
        current_count = int(self.messages_count_label.text().split(": ")[1])
        self.messages_count_label.setText(f"Messages: {current_count + 1}")
        
    def add_system_message(self, text: str, error: bool = False):
        """Add system message to chat"""
        cursor = self.chat_display.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        
        format = QTextCharFormat()
        format.setForeground(QColor("#FF5252" if error else "#00897B"))
        format.setFontItalic(True)
        
        cursor.insertText(f"[System] {text}\n", format)
        
        # Scroll to bottom
        self.chat_display.verticalScrollBar().setValue(
            self.chat_display.verticalScrollBar().maximum()
        )
        
    def load_message_history(self):
        """Load message history from database"""
        history = self.telegram_chat.get_message_history(limit=50)
        
        for msg in history:
            self.add_message({
                'username': msg['username'],
                'text': msg['message'],
                'timestamp': datetime.fromisoformat(msg['timestamp']).strftime('%H:%M:%S')
            }, is_own=msg['is_sent'])
            
    def change_username(self):
        """Change username"""
        new_username, ok = QInputDialog.getText(
            self, "Change Username",
            "Enter new username:",
            text=self.config.get('chat.username', 'Anonymous')
        )
        
        if ok and new_username:
            self.telegram_chat.update_username(new_username)
            self.username_label.setText(new_username)
            self.add_system_message(f"Username changed to: {new_username}")
            
    def update_chat_info(self):
        """Update chat information"""
        if not self.telegram_chat.is_connected():
            return
            
        # This would get actual chat info from Telegram
        # For now, just placeholder updates
        pass
        
    def show_notification(self, message_data: Dict):
        """Show desktop notification for new message"""
        # This would show a system notification
        # For now, just log it
        logger.info(f"New message from {message_data['username']}: {message_data['text']}")
