"""Game Library page"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QScrollArea, QPushButton,
    QLabel, QGridLayout, QFrame, QLineEdit, QMessageBox, QProgressBar,
    QComboBox, QFileDialog, QDialog, QDialogButtonBox, QFormLayout, QMenu
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer, QSize
from PyQt6.QtGui import QPixmap, QIcon, QPainter, QBrush, QColor
from typing import List, Dict
import os
from datetime import datetime
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class GameScanThread(QThread):
    """Thread for scanning games"""
    progress = pyqtSignal(int)
    status = pyqtSignal(str)
    finished_scan = pyqtSignal(list)
    
    def __init__(self, scanner):
        super().__init__()
        self.scanner = scanner
        
    def run(self):
        """Run the scan"""
        self.status.emit("Starting scan...")
        games = self.scanner.scan_all()
        self.finished_scan.emit(games)


class GameCard(QFrame):
    """Card widget for displaying game info"""
    
    clicked = pyqtSignal(dict)
    play_clicked = pyqtSignal(dict)
    favorite_toggled = pyqtSignal(dict, bool)
    remove_requested = pyqtSignal(dict)
    rename_requested = pyqtSignal(dict)
    
    def __init__(self, game_data: dict, parent=None):
        super().__init__(parent)
        self.game_data = game_data
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_context_menu)
        self.setup_ui()
        
    def setup_ui(self):
        """Setup game card UI"""
        self.setObjectName("game_card")
        self.setFixedSize(200, 280)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        
        # Main layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(5)
        
        # Cover image
        cover_label = QLabel()
        cover_label.setFixedSize(180, 180)
        cover_label.setScaledContents(True)
        cover_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Load cover image or use placeholder
        if self.game_data.get('cover_image') and os.path.exists(self.game_data['cover_image']):
            pixmap = QPixmap(self.game_data['cover_image'])
        else:
            # Create placeholder - only emoji
            pixmap = QPixmap(180, 180)
            pixmap.fill(QColor("#1a1a2e"))
            painter = QPainter(pixmap)
            painter.setPen(QColor("#00d4ff"))
            font = painter.font()
            font.setPointSize(48)
            painter.setFont(font)
            painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "🎮")
            painter.end()
        
        cover_label.setPixmap(pixmap)
        cover_label.setStyleSheet("""
            QLabel {
                border: 2px solid #333333;
                border-radius: 10px;
            }
        """)
        layout.addWidget(cover_label)
        
        # Game name
        name_label = QLabel(self.game_data['name'])
        name_label.setWordWrap(True)
        name_label.setMaximumHeight(40)
        name_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        name_label.setStyleSheet("""
            QLabel {
                color: #ffffff;
                font-size: 13px;
                font-weight: bold;
            }
        """)
        layout.addWidget(name_label)
        
        # Platform
        platform_label = QLabel(self.game_data.get('platform', 'Unknown'))
        platform_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        platform_label.setStyleSheet("""
            QLabel {
                color: #00897B;
                font-size: 11px;
            }
        """)
        layout.addWidget(platform_label)
        
        # Play button
        play_button = QPushButton("▶ Play")
        play_button.clicked.connect(lambda: self.play_clicked.emit(self.game_data))
        play_button.setStyleSheet("""
            QPushButton {
                background-color: #00897B;
                color: white;
                border: none;
                border-radius: 15px;
                padding: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #00A693;
            }
        """)
        layout.addWidget(play_button)
        
        # Card styling - MODERN DESIGN
        self.setStyleSheet("""
            #game_card {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 rgba(26, 26, 46, 0.9), stop:1 rgba(15, 52, 96, 0.8));
                border: 2px solid rgba(0, 212, 255, 0.3);
                border-radius: 20px;
            }
            #game_card:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 rgba(0, 212, 255, 0.2), stop:1 rgba(0, 150, 199, 0.3));
                border: 2px solid #00d4ff;
            }
        """)
        
    def mousePressEvent(self, event):
        """Handle mouse press"""
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.game_data)
    
    def show_context_menu(self, position):
        """Show context menu on right click"""
        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background-color: #2a2a2a;
                color: #ffffff;
                border: 1px solid #00897B;
                border-radius: 5px;
                padding: 5px;
            }
            QMenu::item {
                padding: 8px 20px;
                border-radius: 3px;
            }
            QMenu::item:selected {
                background-color: #00897B;
            }
        """)
        
        # Favorite action
        is_favorite = self.game_data.get('is_favorite', False)
        if is_favorite:
            fav_action = menu.addAction("⭐ Remove from Favorites")
            fav_action.triggered.connect(lambda: self.favorite_toggled.emit(self.game_data, False))
        else:
            fav_action = menu.addAction("☆ Add to Favorites")
            fav_action.triggered.connect(lambda: self.favorite_toggled.emit(self.game_data, True))
        
        menu.addSeparator()
        
        # Rename action
        rename_action = menu.addAction("✏️ Rename")
        rename_action.triggered.connect(lambda: self.rename_requested.emit(self.game_data))
        
        # Remove action
        remove_action = menu.addAction("🗑️ Remove from Library")
        remove_action.triggered.connect(lambda: self.remove_requested.emit(self.game_data))
        
        menu.exec(self.mapToGlobal(position))


class AddGameDialog(QDialog):
    """Dialog for manually adding a game"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        
    def setup_ui(self):
        """Setup dialog UI"""
        self.setWindowTitle("Add Game Manually")
        self.setModal(True)
        self.setFixedSize(500, 300)
        
        layout = QVBoxLayout(self)
        
        # Form layout
        form_layout = QFormLayout()
        
        # Game name
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Enter game name")
        form_layout.addRow("Game Name:", self.name_input)
        
        # Game path
        path_layout = QHBoxLayout()
        self.path_input = QLineEdit()
        self.path_input.setPlaceholderText("Select game folder")
        path_button = QPushButton("Browse...")
        path_button.clicked.connect(self.browse_path)
        path_layout.addWidget(self.path_input)
        path_layout.addWidget(path_button)
        form_layout.addRow("Game Path:", path_layout)
        
        # Executable
        exe_layout = QHBoxLayout()
        self.exe_input = QLineEdit()
        self.exe_input.setPlaceholderText("Select game executable")
        exe_button = QPushButton("Browse...")
        exe_button.clicked.connect(self.browse_exe)
        exe_layout.addWidget(self.exe_input)
        exe_layout.addWidget(exe_button)
        form_layout.addRow("Executable:", exe_layout)
        
        layout.addLayout(form_layout)
        
        # Buttons
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | 
            QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        
    def browse_path(self):
        """Browse for game folder"""
        path = QFileDialog.getExistingDirectory(self, "Select Game Folder")
        if path:
            self.path_input.setText(path)
            
    def browse_exe(self):
        """Browse for executable"""
        start_dir = self.path_input.text() if self.path_input.text() else ""
        exe, _ = QFileDialog.getOpenFileName(
            self, "Select Game Executable", 
            start_dir, "Executable Files (*.exe)"
        )
        if exe:
            self.exe_input.setText(exe)
            # Auto-fill name if empty
            if not self.name_input.text():
                import os
                game_name = os.path.splitext(os.path.basename(exe))[0]
                self.name_input.setText(game_name)
            
    def get_game_data(self) -> Dict:
        """Get entered game data"""
        return {
            'name': self.name_input.text(),
            'path': self.path_input.text(),
            'executable': self.exe_input.text()
        }


class LibraryPage(QWidget):
    """Game library page"""
    
    def __init__(self, game_scanner, db_manager, parent=None):
        super().__init__(parent)
        self.game_scanner = game_scanner
        self.db_manager = db_manager
        self.game_cards = []
        self.setup_ui()
        self.load_games()
        
    def setup_ui(self):
        """Setup library page UI"""
        # Main layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Header
        header_layout = QHBoxLayout()
        
        title = QLabel("🎮 Game Library")
        title.setStyleSheet("""
            QLabel {
                color: #ffffff;
                font-size: 24px;
                font-weight: bold;
            }
        """)
        header_layout.addWidget(title)
        
        header_layout.addStretch()
        
        # Search bar
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("🔍 Search games...")
        self.search_input.setMaximumWidth(250)
        self.search_input.textChanged.connect(self.filter_games)
        self.search_input.setStyleSheet("""
            QLineEdit {
                background-color: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 15px;
                padding: 8px 15px;
                color: #ffffff;
            }
        """)
        header_layout.addWidget(self.search_input)
        
        # Filter combo
        self.filter_combo = QComboBox()
        self.filter_combo.addItems(["All Games", "Steam", "Epic", "GOG", "Local", "Favorites"])
        self.filter_combo.currentTextChanged.connect(self.filter_games)
        self.filter_combo.setStyleSheet("""
            QComboBox {
                background-color: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 5px;
                padding: 8px;
                color: #ffffff;
                min-width: 120px;
            }
        """)
        header_layout.addWidget(self.filter_combo)
        
        # Action buttons
        scan_button = QPushButton("🔄 Scan for Games")
        scan_button.clicked.connect(self.scan_for_games)
        scan_button.setStyleSheet("""
            QPushButton {
                background-color: #00897B;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 10px 20px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #00A693;
            }
        """)
        header_layout.addWidget(scan_button)
        
        add_button = QPushButton("➕ Add Game")
        add_button.clicked.connect(self.add_game_manually)
        add_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 10px 20px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #5CBF60;
            }
        """)
        header_layout.addWidget(add_button)
        
        layout.addLayout(header_layout)
        
        # Progress bar (hidden by default)
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background-color: #333333;
                border: none;
                border-radius: 5px;
                text-align: center;
                color: white;
            }
            QProgressBar::chunk {
                background-color: #00897B;
                border-radius: 5px;
            }
        """)
        layout.addWidget(self.progress_bar)
        
        # Status label
        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: #b0b0b0; font-size: 12px;")
        layout.addWidget(self.status_label)
        
        # Games grid
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("""
            QScrollArea {
                background-color: transparent;
                border: none;
            }
            QScrollBar:vertical {
                background-color: #2a2a2a;
                width: 10px;
                border-radius: 5px;
            }
            QScrollBar::handle:vertical {
                background-color: #555555;
                border-radius: 5px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background-color: #00897B;
            }
        """)
        
        self.games_widget = QWidget()
        self.games_layout = QGridLayout(self.games_widget)
        self.games_layout.setSpacing(20)
        
        scroll_area.setWidget(self.games_widget)
        layout.addWidget(scroll_area)
        
    def load_games(self):
        """Load games from database"""
        try:
            from src.core.database import Game
            
            session = self.db_manager.get_session()
            games = session.query(Game).all()
            
            self.display_games([{
                'name': game.name,
                'path': game.path,
                'executable': game.executable,
                'platform': game.platform,
                'cover_image': game.cover_image,
                'total_playtime': game.total_playtime,
                'is_favorite': game.is_favorite
            } for game in games])
            
            self.status_label.setText(f"Found {len(games)} games in library")
            session.close()
            
        except Exception as e:
            logger.error(f"Error loading games: {e}")
            
    def display_games(self, games: List[Dict]):
        """Display game cards in grid"""
        # Clear existing cards
        for card in self.game_cards:
            card.deleteLater()
        self.game_cards.clear()
        
        # Add new cards
        row, col = 0, 0
        max_cols = 5
        
        for game_data in games:
            card = GameCard(game_data)
            card.clicked.connect(self.show_game_details)
            card.play_clicked.connect(self.launch_game)
            card.favorite_toggled.connect(self.toggle_favorite)
            card.remove_requested.connect(self.remove_game)
            card.rename_requested.connect(self.rename_game)
            
            self.games_layout.addWidget(card, row, col)
            self.game_cards.append(card)
            
            col += 1
            if col >= max_cols:
                col = 0
                row += 1
                
    def scan_for_games(self):
        """Start scanning for games"""
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)  # Indeterminate
        self.status_label.setText("Scanning for games...")
        
        # Create and start scan thread
        self.scan_thread = GameScanThread(self.game_scanner)
        self.scan_thread.finished_scan.connect(self.on_scan_complete)
        self.scan_thread.status.connect(self.status_label.setText)
        self.scan_thread.start()
        
    def on_scan_complete(self, games: List[Dict]):
        """Handle scan completion"""
        self.progress_bar.setVisible(False)
        
        # Save games to database
        from src.core.database import Game
        session = self.db_manager.get_session()
        
        added = 0
        for game_data in games:
            # Check if game already exists
            existing = session.query(Game).filter_by(path=game_data['path']).first()
            if not existing:
                game = Game(
                    name=game_data['name'],
                    path=game_data['path'],
                    executable=game_data.get('executable'),
                    platform=game_data.get('platform', 'Unknown'),
                    cover_image=game_data.get('cover_image'),
                    description=game_data.get('description', '')
                )
                session.add(game)
                added += 1
        
        session.commit()
        session.close()
        
        self.status_label.setText(f"Scan complete! Found {len(games)} games, {added} new")
        self.load_games()
        
    def add_game_manually(self):
        """Show dialog to add game manually"""
        dialog = AddGameDialog(self)
        if dialog.exec():
            game_data = dialog.get_game_data()
            if all(game_data.values()):
                # Add to scanner
                self.game_scanner.add_game_manually(
                    game_data['name'],
                    game_data['path'],
                    game_data['executable']
                )
                
                # Save to database
                from src.core.database import Game
                session = self.db_manager.get_session()
                
                game = Game(
                    name=game_data['name'],
                    path=game_data['path'],
                    executable=game_data['executable'],
                    platform='Manual'
                )
                session.add(game)
                session.commit()
                session.close()
                
                self.load_games()
                self.status_label.setText(f"Added {game_data['name']} to library")
                
    def filter_games(self):
        """Filter displayed games"""
        search_text = self.search_input.text().lower()
        filter_type = self.filter_combo.currentText()
        
        for card in self.game_cards:
            show = True
            
            # Search filter
            if search_text:
                if search_text not in card.game_data['name'].lower():
                    show = False
            
            # Platform filter
            if filter_type != "All Games":
                if filter_type == "Favorites":
                    if not card.game_data.get('is_favorite'):
                        show = False
                elif filter_type not in card.game_data.get('platform', ''):
                    show = False
            
            card.setVisible(show)
            
    def show_game_details(self, game_data: Dict):
        """Show detailed game information"""
        # This would show a detailed view/dialog
        logger.info(f"Showing details for: {game_data['name']}")
        
    def launch_game(self, game_data: Dict):
        """Launch a game"""
        import subprocess
        
        if game_data.get('executable') and os.path.exists(game_data['executable']):
            try:
                # Check if optimization should run
                try:
                    main_window = self.window()
                    if hasattr(main_window, 'config') and hasattr(main_window, 'optimizer'):
                        if main_window.config.get('optimization.auto_optimize_on_game_launch', False):
                            main_window.optimizer.optimize_for_gaming(game_data['executable'])
                except:
                    pass
                
                # Launch game
                subprocess.Popen(game_data['executable'])
                
                # Start tracking session
                self.start_game_session(game_data)
                
                self.status_label.setText(f"Launched {game_data['name']}")
                
            except Exception as e:
                logger.error(f"Error launching game: {e}")
                QMessageBox.critical(self, "Error", f"Failed to launch game: {e}")
        else:
            QMessageBox.warning(self, "Warning", "Game executable not found!")
            
    def start_game_session(self, game_data: Dict):
        """Start tracking a gaming session"""
        from src.core.database import Game, GameSession
        
        session = self.db_manager.get_session()
        game = session.query(Game).filter_by(path=game_data['path']).first()
        
        if game:
            game_session = GameSession(
                game_id=game.id,
                start_time=datetime.now()
            )
            session.add(game_session)
            session.commit()
        
        session.close()
    
    def toggle_favorite(self, game_data: Dict, is_favorite: bool):
        """Toggle game favorite status"""
        from src.core.database import Game
        
        try:
            session = self.db_manager.get_session()
            game = session.query(Game).filter_by(path=game_data['path']).first()
            
            if game:
                game.is_favorite = is_favorite
                session.commit()
                
                # Update UI
                game_data['is_favorite'] = is_favorite
                self.load_games()
                
                status = "added to" if is_favorite else "removed from"
                self.status_label.setText(f"{game_data['name']} {status} favorites")
            
            session.close()
            
        except Exception as e:
            logger.error(f"Error toggling favorite: {e}")
            QMessageBox.critical(self, "Error", f"Failed to update favorite: {e}")
    
    def remove_game(self, game_data: Dict):
        """Remove game from library"""
        from src.core.database import Game
        
        reply = QMessageBox.question(
            self,
            "Remove Game",
            f"Are you sure you want to remove '{game_data['name']}' from your library?\n\nThis will not delete the game files.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            try:
                session = self.db_manager.get_session()
                game = session.query(Game).filter_by(path=game_data['path']).first()
                
                if game:
                    session.delete(game)
                    session.commit()
                    
                    self.load_games()
                    self.status_label.setText(f"Removed {game_data['name']} from library")
                
                session.close()
                
            except Exception as e:
                logger.error(f"Error removing game: {e}")
                QMessageBox.critical(self, "Error", f"Failed to remove game: {e}")
    
    def rename_game(self, game_data: Dict):
        """Rename game"""
        from src.core.database import Game
        from PyQt6.QtWidgets import QInputDialog
        
        new_name, ok = QInputDialog.getText(
            self,
            "Rename Game",
            "Enter new name:",
            QLineEdit.EchoMode.Normal,
            game_data['name']
        )
        
        if ok and new_name and new_name != game_data['name']:
            try:
                session = self.db_manager.get_session()
                game = session.query(Game).filter_by(path=game_data['path']).first()
                
                if game:
                    game.name = new_name
                    session.commit()
                    
                    self.load_games()
                    self.status_label.setText(f"Renamed to '{new_name}'")
                
                session.close()
                
            except Exception as e:
                logger.error(f"Error renaming game: {e}")
                QMessageBox.critical(self, "Error", f"Failed to rename game: {e}")
