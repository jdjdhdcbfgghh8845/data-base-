"""Settings page"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QTabWidget, QLineEdit, QComboBox, QCheckBox, QSpinBox,
    QListWidget, QListWidgetItem, QGroupBox, QFileDialog,
    QColorDialog, QSlider, QTextEdit, QMessageBox, QInputDialog
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont
import json
from pathlib import Path
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class SettingsPage(QWidget):
    """Application settings page"""
    
    # Signals
    settings_changed = pyqtSignal()
    theme_changed = pyqtSignal(str)
    
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self.config = config
        self.setup_ui()
        self.load_settings()
        
    def setup_ui(self):
        """Setup settings page UI"""
        # Main layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Title
        title = QLabel("⚙️ Settings")
        title.setStyleSheet("""
            QLabel {
                color: #ffffff;
                font-size: 24px;
                font-weight: bold;
            }
        """)
        layout.addWidget(title)
        
        # Tab widget
        self.tab_widget = QTabWidget()
        self.tab_widget.setStyleSheet("""
            QTabWidget::pane {
                background-color: #2a2a2a;
                border: 1px solid #333333;
                border-radius: 10px;
            }
            QTabBar::tab {
                background-color: #333333;
                color: #b0b0b0;
                padding: 10px 20px;
                margin: 2px;
                border-radius: 5px;
            }
            QTabBar::tab:selected {
                background-color: #00897B;
                color: white;
            }
            QTabBar::tab:hover {
                background-color: #444444;
            }
        """)
        
        # Create tabs
        self.create_appearance_tab()
        self.create_optimization_tab()
        self.create_chat_tab()
        self.create_shortcuts_tab()
        
        layout.addWidget(self.tab_widget)
        
        # Bottom buttons
        bottom_layout = QHBoxLayout()
        bottom_layout.addStretch()
        
        # Save button
        save_button = QPushButton("💾 Save Settings")
        save_button.clicked.connect(self.save_settings)
        save_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 10px 20px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #66BB6A;
            }
        """)
        bottom_layout.addWidget(save_button)
        
        layout.addLayout(bottom_layout)
        
    def create_appearance_tab(self):
        """Create appearance settings tab"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Theme selection
        theme_group = QGroupBox("Theme")
        theme_layout = QVBoxLayout(theme_group)
        
        self.theme_combo = QComboBox()
        self.theme_combo.addItems([
            "dark_teal.xml", "dark_blue.xml", "dark_purple.xml",
            "dark_amber.xml", "dark_cyan.xml"
        ])
        theme_layout.addWidget(self.theme_combo)
        
        layout.addWidget(theme_group)
        
        # Font settings
        font_group = QGroupBox("Font")
        font_layout = QHBoxLayout(font_group)
        
        font_layout.addWidget(QLabel("Size:"))
        self.font_size = QSpinBox()
        self.font_size.setRange(8, 24)
        font_layout.addWidget(self.font_size)
        
        layout.addWidget(font_group)
        
        # Animations
        self.animations_check = QCheckBox("Enable animations")
        self.sound_effects_check = QCheckBox("Enable sound effects")
        layout.addWidget(self.animations_check)
        layout.addWidget(self.sound_effects_check)
        
        layout.addStretch()
        self.tab_widget.addTab(tab, "🎨 Appearance")
        
    def create_optimization_tab(self):
        """Create optimization settings tab"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Auto optimization
        self.auto_optimize_check = QCheckBox("Auto-optimize on game launch")
        layout.addWidget(self.auto_optimize_check)
        
        # RAM threshold
        ram_layout = QHBoxLayout()
        ram_layout.addWidget(QLabel("RAM cleanup threshold:"))
        self.ram_threshold = QSpinBox()
        self.ram_threshold.setRange(50, 95)
        self.ram_threshold.setSuffix("%")
        ram_layout.addWidget(self.ram_threshold)
        layout.addLayout(ram_layout)
        
        # Excluded processes
        exclude_group = QGroupBox("Excluded Processes")
        exclude_layout = QVBoxLayout(exclude_group)
        
        self.exclude_list = QListWidget()
        self.exclude_list.setMaximumHeight(150)
        
        exclude_buttons = QHBoxLayout()
        add_process_button = QPushButton("Add Process")
        add_process_button.clicked.connect(self.add_excluded_process)
        remove_process_button = QPushButton("Remove")
        remove_process_button.clicked.connect(self.remove_excluded_process)
        
        exclude_buttons.addWidget(add_process_button)
        exclude_buttons.addWidget(remove_process_button)
        
        exclude_layout.addWidget(self.exclude_list)
        exclude_layout.addLayout(exclude_buttons)
        
        layout.addWidget(exclude_group)
        layout.addStretch()
        
        self.tab_widget.addTab(tab, "⚡ Optimization")
        
    def create_chat_tab(self):
        """Create chat settings tab"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Telegram settings
        telegram_group = QGroupBox("Telegram Bot Configuration")
        telegram_layout = QVBoxLayout(telegram_group)
        
        # Bot token
        token_layout = QHBoxLayout()
        token_layout.addWidget(QLabel("Bot Token:"))
        self.bot_token = QLineEdit()
        self.bot_token.setEchoMode(QLineEdit.EchoMode.Password)
        token_layout.addWidget(self.bot_token)
        telegram_layout.addLayout(token_layout)
        
        # Chat ID
        chat_layout = QHBoxLayout()
        chat_layout.addWidget(QLabel("Chat ID:"))
        self.chat_id = QLineEdit()
        chat_layout.addWidget(self.chat_id)
        telegram_layout.addLayout(chat_layout)
        
        # Username
        username_layout = QHBoxLayout()
        username_layout.addWidget(QLabel("Username:"))
        self.username = QLineEdit()
        username_layout.addWidget(self.username)
        telegram_layout.addLayout(username_layout)
        
        layout.addWidget(telegram_group)
        
        # Test connection button
        test_button = QPushButton("🔌 Test Connection")
        test_button.clicked.connect(self.test_telegram_connection)
        layout.addWidget(test_button)
        
        layout.addStretch()
        
        self.tab_widget.addTab(tab, "💬 Chat")
        
    def create_shortcuts_tab(self):
        """Create keyboard shortcuts tab"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(20, 20, 20, 20)
        
        shortcuts_group = QGroupBox("Keyboard Shortcuts")
        shortcuts_layout = QVBoxLayout(shortcuts_group)
        
        # Shortcut inputs
        shortcuts = [
            ("Toggle Optimization", "toggle_optimization"),
            ("Launch Game", "launch_game"),
            ("Open Chat", "open_chat"),
            ("Quick Scan", "quick_scan")
        ]
        
        self.shortcut_inputs = {}
        
        for label, key in shortcuts:
            row_layout = QHBoxLayout()
            row_layout.addWidget(QLabel(f"{label}:"))
            
            input_field = QLineEdit()
            input_field.setPlaceholderText("Press keys...")
            self.shortcut_inputs[key] = input_field
            
            row_layout.addWidget(input_field)
            shortcuts_layout.addLayout(row_layout)
        
        layout.addWidget(shortcuts_group)
        layout.addStretch()
        
        self.tab_widget.addTab(tab, "⌨️ Shortcuts")
        
    def load_settings(self):
        """Load current settings into UI"""
        try:
            # Appearance
            self.theme_combo.setCurrentText(self.config.get('appearance.theme', 'dark_teal.xml'))
            self.font_size.setValue(self.config.get('appearance.font_size', 10))
            self.animations_check.setChecked(self.config.get('appearance.animations_enabled', True))
            self.sound_effects_check.setChecked(self.config.get('appearance.sound_effects', True))
            
            # Optimization
            self.auto_optimize_check.setChecked(self.config.get('optimization.auto_optimize_on_game_launch', True))
            self.ram_threshold.setValue(self.config.get('optimization.ram_cleanup_threshold', 80))
            
            # Load excluded processes
            excluded = self.config.get('optimization.excluded_processes', [])
            self.exclude_list.clear()
            self.exclude_list.addItems(excluded)
            
            # Chat
            self.bot_token.setText(self.config.get('chat.telegram_bot_token', ''))
            self.chat_id.setText(self.config.get('chat.telegram_chat_id', ''))
            self.username.setText(self.config.get('chat.username', ''))
            
            # Shortcuts
            shortcuts = self.config.get('shortcuts', {})
            for key, input_field in self.shortcut_inputs.items():
                input_field.setText(shortcuts.get(key, ''))
                
        except Exception as e:
            logger.error(f"Error loading settings: {e}")
            
    def save_settings(self):
        """Save settings to config"""
        try:
            # Appearance
            self.config.set('appearance.theme', self.theme_combo.currentText())
            self.config.set('appearance.font_size', self.font_size.value())
            self.config.set('appearance.animations_enabled', self.animations_check.isChecked())
            self.config.set('appearance.sound_effects', self.sound_effects_check.isChecked())
            
            # Optimization
            self.config.set('optimization.auto_optimize_on_game_launch', self.auto_optimize_check.isChecked())
            self.config.set('optimization.ram_cleanup_threshold', self.ram_threshold.value())
            
            # Excluded processes
            excluded = []
            for i in range(self.exclude_list.count()):
                excluded.append(self.exclude_list.item(i).text())
            self.config.set('optimization.excluded_processes', excluded)
            
            # Chat
            self.config.set('chat.telegram_bot_token', self.bot_token.text())
            self.config.set('chat.telegram_chat_id', self.chat_id.text())
            self.config.set('chat.username', self.username.text())
            
            # Shortcuts
            shortcuts = {}
            for key, input_field in self.shortcut_inputs.items():
                shortcuts[key] = input_field.text()
            self.config.set('shortcuts', shortcuts)
            
            # Save config
            self.config.save()
            
            QMessageBox.information(self, "Success", "Settings saved successfully!")
            self.settings_changed.emit()
            
        except Exception as e:
            logger.error(f"Error saving settings: {e}")
            QMessageBox.critical(self, "Error", f"Failed to save settings: {e}")
            
    def add_excluded_process(self):
        """Add process to exclusion list"""
        process, ok = QInputDialog.getText(
            self, "Add Process",
            "Enter process name (e.g., chrome.exe):"
        )
        
        if ok and process:
            self.exclude_list.addItem(process)
            
    def remove_excluded_process(self):
        """Remove selected process from exclusion list"""
        current = self.exclude_list.currentItem()
        if current:
            self.exclude_list.takeItem(self.exclude_list.row(current))
            
    def test_telegram_connection(self):
        """Test Telegram bot connection"""
        # This would test the connection
        QMessageBox.information(self, "Test", "Connection test will be implemented")
