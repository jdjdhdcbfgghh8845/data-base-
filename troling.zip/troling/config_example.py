# Пример конфигурационного файла
# Скопируйте этот файл в config.py и заполните своими данными

# Токен бота от @BotFather
BOT_TOKEN = "1234567890:ABCdefGHIjklMNOpqrsTUVwxyz"

# Список ID пользователей, которым разрешен доступ
# Получите свой ID у @userinfobot
ALLOWED_USERS = [
    123456789,  # Ваш ID
    # 987654321,  # ID друга (раскомментируйте при необходимости)
]

# Настройки безопасности
REQUIRE_PASSWORD = False  # Требовать пароль при входе
PASSWORD = "mysecretpass"  # Пароль (если REQUIRE_PASSWORD = True)

# Настройки уведомлений
NOTIFY_ON_START = True  # Уведомлять при запуске бота
NOTIFY_ON_COMMAND = True  # Уведомлять о каждой выполненной команде
