"""
Тест функции скриншотов - проверка работы из любой папки
"""

import os
import sys
import tempfile
import time

print("🧪 ТЕСТ СКРИНШОТОВ")
print("=" * 60)
print()

# Проверка текущей директории
print(f"📂 Текущая директория: {os.getcwd()}")
print(f"📄 Путь к скрипту: {os.path.abspath(__file__)}")
print()

# Проверка PIL
print("📦 Проверка библиотеки PIL (Pillow)...")
try:
    from PIL import ImageGrab
    print("✅ PIL установлен")
except ImportError:
    print("❌ PIL НЕ установлен!")
    print("   Установите: pip install Pillow")
    sys.exit(1)

print()
print("📸 Создание тестового скриншота...")

try:
    # Создаём скриншот
    screenshot = ImageGrab.grab()
    print(f"✅ Скриншот создан: {screenshot.size[0]}x{screenshot.size[1]} пикселей")
    
    # Получаем временную папку
    temp_dir = tempfile.gettempdir()
    print(f"📁 Временная папка: {temp_dir}")
    
    # Создаём путь к файлу
    screenshot_path = os.path.join(temp_dir, f"test_screenshot_{int(time.time())}.png")
    print(f"💾 Путь к файлу: {screenshot_path}")
    
    # Сохраняем
    screenshot.save(screenshot_path)
    print("✅ Скриншот сохранён")
    
    # Проверяем размер файла
    file_size = os.path.getsize(screenshot_path)
    print(f"📊 Размер файла: {file_size / 1024:.2f} KB")
    
    # Проверяем чтение
    with open(screenshot_path, 'rb') as f:
        data = f.read()
        print(f"✅ Файл читается: {len(data)} байт")
    
    # Удаляем тестовый файл
    os.remove(screenshot_path)
    print("✅ Файл удалён")
    
    print()
    print("=" * 60)
    print("🎉 ВСЕ ТЕСТЫ ПРОЙДЕНЫ!")
    print()
    print("✅ Скриншоты будут работать из:")
    print("   • Текущей папки")
    print("   • AppData")
    print("   • Program Files")
    print("   • Любого другого места")
    print()
    print("🚀 Можно запускать бота!")
    
except Exception as e:
    print()
    print("❌ ОШИБКА!")
    print(f"   {str(e)}")
    print()
    print("💡 Решение:")
    print("   1. Проверьте права доступа к TEMP папке")
    print("   2. Переустановите Pillow: pip install --upgrade Pillow")
    print("   3. Попробуйте перезапустить компьютер")
    sys.exit(1)
