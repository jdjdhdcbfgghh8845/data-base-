"""
Проверка системы перед запуском бота
"""

import sys
import platform

print("🔍 Проверка системы...")
print("=" * 50)

# Проверка Python версии
print(f"🐍 Python: {sys.version}")
if sys.version_info < (3, 8):
    print("❌ ОШИБКА: Требуется Python 3.8 или выше!")
    sys.exit(1)
else:
    print("✅ Версия Python подходит")

# Проверка ОС
print(f"💻 ОС: {platform.system()} {platform.release()}")
if platform.system() != "Windows":
    print("⚠️ ВНИМАНИЕ: Некоторые функции работают только на Windows!")
else:
    print("✅ Windows обнаружена")

print("\n📦 Проверка зависимостей...")
print("-" * 50)

required_modules = {
    'telegram': 'python-telegram-bot',
    'PIL': 'Pillow',
    'requests': 'requests',
    'psutil': 'psutil',
    'pyautogui': 'pyautogui',
}

optional_modules = {
    'openai': 'openai (опционально для AI)',
    'pyttsx3': 'pyttsx3 (опционально для голоса)',
}

missing = []
for module, package in required_modules.items():
    try:
        __import__(module)
        print(f"✅ {package}")
    except ImportError:
        print(f"❌ {package} - НЕ УСТАНОВЛЕН")
        missing.append(package)

# Проверка Windows-специфичных модулей
if platform.system() == "Windows":
    win_modules = {
        'pycaw': 'pycaw',
        'comtypes': 'comtypes',
        'winreg': 'встроенный',
    }
    
    for module, package in win_modules.items():
        try:
            __import__(module)
            print(f"✅ {package}")
        except ImportError:
            if package != 'встроенный':
                print(f"❌ {package} - НЕ УСТАНОВЛЕН")
                missing.append(package)

# Проверка опциональных модулей
print("\n📦 Проверка опциональных зависимостей...")
print("-" * 50)
for module, package in optional_modules.items():
    try:
        __import__(module)
        print(f"✅ {package}")
    except ImportError:
        print(f"⚠️ {package} - не установлен (не критично)")

# Тест скриншотов
print("\n📸 Проверка функции скриншотов...")
print("-" * 50)
try:
    from PIL import ImageGrab
    import tempfile
    import os
    
    # Пробуем создать скриншот
    screenshot = ImageGrab.grab()
    temp_dir = tempfile.gettempdir()
    test_path = os.path.join(temp_dir, "test_screenshot.png")
    screenshot.save(test_path)
    
    # Проверяем что файл создался
    if os.path.exists(test_path):
        file_size = os.path.getsize(test_path) / 1024
        print(f"✅ Скриншоты работают ({file_size:.1f} KB)")
        print(f"   Временная папка: {temp_dir}")
        os.remove(test_path)
    else:
        print("⚠️ Файл скриншота не создался")
except Exception as e:
    print(f"❌ Ошибка скриншотов: {str(e)[:50]}")

print("\n" + "=" * 50)

if missing:
    print(f"\n❌ Отсутствуют модули: {', '.join(missing)}")
    print("\n💡 Установите их командой:")
    print(f"   pip install {' '.join(missing)}")
    print("\nИли запустите: INSTALL.bat")
    sys.exit(1)
else:
    print("\n✅ Все зависимости установлены!")
    print("\n🚀 Система готова к запуску бота!")
    print("\n📝 Следующие шаги:")
    print("1. Настройте BOT_TOKEN в bot.py")
    print("2. Настройте GITHUB_BACKUP_URL в guardian.py (опционально)")
    print("3. Запустите: python bot.py")
